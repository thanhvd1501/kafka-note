# USER MANUAL

`Amatrium server version 1.0.0. Updated at: 07-03-2023`

## Table Of Contents

- [1. Category](#1-category-api)
- [2. Import Functions](#2-import-export-api)
- [3. User Management](#3-user-management-api)
- [4. Authentication](#4-authentication)
- [5. SSE Connection](#5-sse-connection)
- [6. Notification](#6-user-notification)
- [7. Prediction](#7)

`Context path: /api/v3`

## 1. Category API
### 1.1 Get all categories

- `GET : /category`

**Response:**
```json
[
    {
        "created_date": "2023-03-09T12:06:12.729+00:00",
        "id": "6409cbb4f42c9c370de52910",
        "name": "SDI Butler",
        "organization": "640ec04e4a937db07f76dc55",
        "materials": [
            {
                "id": "640b0a92a440ac66a8c9d190",
                "label": "06N47"
            },
            {
                "id": "640b0a92a440ac66a8c9d191",
                "label": "06N49"
            }
        ],
        "properties": [
            {
                "id": "642553db2850eb10e4d11bcd",
                "label": "el",
                "name": "Elongation",
                "unit": "%"
            },
            {
                "id": "642553db2850eb10e4d11bce",
                "label": "ts",
                "name": "Tensile Strength",
                "unit": "%"
            },
            {
                "id": "642553db2850eb10e4d11bcf",
                "label": "ys",
                "name": "Yield Strength",
                "unit": "%"
            }
        ]
    }
]
```

### 1.2 Get material details
- `GET: /material/{material_id}`

**Response:**
```json
{
    "created_date": "2023-03-10T10:46:39.775+00:00",
    "last_modified_date": "2023-03-10T10:46:39.775+00:00",
    "id": "640b0a92a440ac66a8c9d190",
    "label": "06N47",
    "compositions": [
        {
            "symbol": "c",
            "name": "Carbon",
            "min": 0.03,
            "max": 0.063,
            "unit": "%"
        },
        {
            "symbol": "mn",
            "name": "Manganese",
            "min": 0.653,
            "max": 0.771,
            "unit": "%"
        },
        {
            "symbol": "p",
            "name": "Phosphorus",
            "min": 0.006,
            "max": 0.0211,
            "unit": "%"
        },
        {
            "symbol": "s",
            "name": "Sulfur",
            "min": 4.0E-4,
            "max": 0.0075,
            "unit": "%"
        },
        {
            "symbol": "si",
            "name": "Silicon",
            "min": 0.012,
            "max": 0.069,
            "unit": "%"
        },
        {
            "symbol": "cu",
            "name": "Copper",
            "min": 0.07,
            "max": 0.152,
            "unit": "%"
        },
        {
            "symbol": "ni",
            "name": "Nickel",
            "min": 0.027,
            "max": 0.066,
            "unit": "%"
        },
        {
            "symbol": "cr",
            "name": "Chromium",
            "min": 0.033,
            "max": 0.124,
            "unit": "%"
        },
        {
            "symbol": "mo",
            "name": "Molybdenum",
            "min": 0.011,
            "max": 0.036,
            "unit": "%"
        },
        {
            "symbol": "al",
            "name": "Aluminium",
            "min": 0.015,
            "max": 0.047,
            "unit": "%"
        },
        {
            "symbol": "nb",
            "name": "Niobium",
            "min": 0.015,
            "max": 0.022,
            "unit": "%"
        },
        {
            "symbol": "ca",
            "name": "Calcium",
            "min": 0.001,
            "max": 0.0029,
            "unit": "%"
        },
        {
            "symbol": "n",
            "name": "Nitrogen",
            "min": 0.0052,
            "max": 0.0105,
            "unit": "%"
        },
        {
            "symbol": "ti",
            "name": "Titanium",
            "min": 0.0,
            "max": 0.002,
            "unit": "%"
        }
    ],
    "dimensions": [
        {
            "symbol": "thickness",
            "name": "Thickness",
            "min": 0.0579,
            "max": 0.1184,
            "unit": ""
        },
        {
            "symbol": "width",
            "name": "Width",
            "min": 41.13,
            "max": 57.99,
            "unit": ""
        }
    ],
    "processing": [
        {
            "symbol": "eff_ti",
            "name": "Effective Titanium",
            "min": 0.0,
            "max": 0.0,
            "unit": "°C"
        },
        {
            "symbol": "ct",
            "name": "Coiling Temperature",
            "min": 1157.01,
            "max": 1195.03,
            "unit": "°C"
        },
        {
            "symbol": "ft",
            "name": "Finishing Temperature",
            "min": 1612.65,
            "max": 1691.57,
            "unit": "°C"
        }
    ],
    "properties": [
        {
            "name": "Yield Strength",
            "min": 49323.0,
            "max": 68673.0,
            "unit": "psi"
        },
        {
            "name": "Tensile Strength",
            "min": 58123.0,
            "max": 77194.0,
            "unit": "psi"
        },
        {
            "name": "Elongation",
            "min": 17.0,
            "max": 36.0,
            "unit": "%"
        }
    ]
}
```

### 1.3 Request to retrain model
- `POST: /category/{category_id}/training-model`

**Response:**
```json
{
    "timestamp": 1681450524092,
    "data": "ocAZy9IfFC2gC9LJ2IZY2oSocwRikMRVGrKxeU4pxVJ63pmVursUMpuRBu20goWd"
}
```

### 1.4 Start retrain model
- `PUT: /category/{category_id}/training-model/start`

**Request Param:**
- `secret:` `(form-data)` The secret code to identify the training model request

**Response:**
```
- Http status: 200 if OK
- Http status: 400 if request do not allowed
```

### 1.5 Complete retrain model
- `PUT: /category/{category_id}/training-model/completed`

**Request Param:**
- `is_success:` `(form-data)` `true` means train model succeeded, `false` means error occurred

**Response:**
```
- Http status: 200 if OK
- Http status: 400 if request do not allowed
```


## 2. Import-Export API
### 2.1 Import compositions from .CSV
- `POST : /category/{category-id}/composition/import`

**Request Param:**
- `is_partial_import:` `(form-data)` true - partial import (update the exists or add new), false - full import (clear all then insert)
- `file:` `(form-data)` The csv file


**Response:**
```json
[
    {
        "created_by": "admin@amatrium.com",
        "created_date": "2023-03-24T07:31:04.778+00:00",
        "last_modified_date": "2023-03-28T10:56:16.651+00:00",
        "id": "641d51b838a9fd125cf30981",
        "symbol": "ti",
        "name": "Titanium",
        "unit": "%"
    },
    {
        "created_by": "admin@amatrium.com",
        "created_date": "2023-03-24T07:31:04.785+00:00",
        "last_modified_date": "2023-03-28T10:56:16.676+00:00",
        "id": "641d51b838a9fd125cf30982",
        "symbol": "n",
        "name": "Nitrogen",
        "unit": "%"
    }
]
```

### 2.2 Import properties from .CSV
- `POST : /category/{category-id}/property/import`

**Request Param:**
- `is_partial_import:` `(form-data)` true - partial import (update the exists or add new), false - full import (clear all then insert)
- `file:` `(form-data)` The csv file

**Response:**
```json
[
    {
        "created_by": "haivu0352@gmail.com",
        "created_date": "2023-03-28T10:58:03.179+00:00",
        "last_modified_date": "2023-03-28T10:58:03.179+00:00",
        "id": "6422c83b49fc351af295834f",
        "label": "el",
        "name": "Elongation",
        "unit": "%"
    },
    {
        "created_by": "haivu0352@gmail.com",
        "created_date": "2023-03-28T10:58:03.180+00:00",
        "last_modified_date": "2023-03-28T10:58:03.180+00:00",
        "id": "6422c83b49fc351af2958350",
        "label": "ts",
        "name": "Tensile Strength",
        "unit": "%"
    }
]
```

### 2.3 Import manufacturing records from .CSV
- `POST : /category/{category-id}/historical/import`

**Request Param:**
- `is_partial_import:` `(form-data)` true - partial import (add new manufacturing records for certain category), false - full import (clear all then insert manufacturing records for certain category)
- `file:` `(form-data)` The csv file

**Response:**
```
- 200 OK if the category is ready to import
- 400 if another importing task is not finished
```

## 3. User-Management API

### 3.1 Get user roles

- `GET: /user/role`

**Response:**
```json
[
    "ADMIN",
    "DATA_ENTRY",
    "USER"
]
```

### 3.2 Create new user
- `POST: /user`

**Request:**
```json
{
  "email": "email@test.com",
  "role": "USER",
  "name": "Egs"
}
```

**Response:**
```json
{
    "access_token": "token",
    "expires_in": 180,
    "refresh_token": "refresh",
    "refresh_expires_in": 180
}
```

### 3.3 Get all users
- `GET: /user`

**Response:**
```json
[
    {
        "id": "6413d2510b15187469464cc8",
        "email": "email@test.com",
        "role": "ADMIN",
        "name": "EGS",
        "organization": "640ec04e4a937db07f76dc55"
    },
    {
        "created_by": "admin@amatrium.com",
        "created_date": "2023-03-27T09:43:56.595+00:00",
        "last_modified_date": "2023-03-27T09:43:56.595+00:00",
        "id": "6421655cf14aab1a3999d229",
        "email": "son.nguyen@eastgate-software.com",
        "role": "ADMIN",
        "name": "Son Nguyen",
        "organization": "640ec04e4a937db07f76dc55"
    },
    {
        "created_by": "admin@amatrium.co",
        "created_date": "2023-03-27T09:50:17.681+00:00",
        "last_modified_date": "2023-03-28T03:50:15.299+00:00",
        "id": "642166d9106a473637e770df",
        "email": "email@test.com",
        "role": "USER",
        "name": "EGS",
        "organization": "640ec04e4a937db07f76dc55"
    }
]
```

### 3.4 Delete user
- `DELETE: /user/{user_Id}`

**Response:**
```json
true
```

- `GET: /user/{user_Id}` (Get detail data about user)

**Response:**
```json
{
    "id": "6413d2510b15187469464cc8",
    "email": "email@test.com",
    "role": "ADMIN",
    "name": "EGS",
    "organization": "640ec04e4a937db07f76dc55",
    "organization_name": "Alloy family"
}
```
### 3.5 Change password
- `PATCH: /user/{user_id}/change-password`

**Request body:**
```json
{
    "old_password": "Egs-12345@",
    "new_password": "Egs-45678@"
}
```

**Response:**
```json
true
```

### 3.6 Update role
- `PATCH: /user/{user_id}/role`

**Request body:**
- `role`: is role of user want update

**Response:**
```json
{
    "timestamp": 1681375877418,
    "data": true
}
```

## 4. Authentication

### 4.1 Login
- `POST: /auth/login`

**Request param:**
```json
{
    "username": "email@test.com",
    "password": "Egs-12345@"
}
```

**Response:**
```json
{
    "access_token": "token",
    "expires_in": 180,
    "refresh_token": "refresh",
    "refresh_expires_in": 180
}
```

### 4.2 Reset password (forgot pwd)
- `POST: /auth/reset-password/request`

**Request param:**
- `email`: is email of user want reset password

**Response:**
```json
{
    "timestamp": 1680679428887,
    "data": true
}
```
- `POST: /auth/reset-password`

**Request param:**
- `code`: is the code that was received in the email to reset password
- `email`: is email of user want reset password
- `password`: is new password of user

**Response:**
```json
{
    "timestamp": 1680679784945,
    "data": true
}
```
## 5. SSE Connection

### 5.1 Establish connection
- `GET: /sse/connection`

## 6. User Notification

### 6.1 Get user notification
- `GET: /notification`

**Response:**
```json
{
    "data": [
        {
            "created_date": "2023-04-10T10:12:06.405+00:00",
            "updated_by": "son.nguyen@eastgate-software.com",
            "last_modified_date": "2023-04-11T07:24:22.042+00:00",
            "id": "6433e0f68ec3df0a32bceff1",
            "severity": "INFO",
            "type": "IMPORTING",
            "message": {
                "en": "The manufacturing records was imported successfully for category SDI Butler"
            },
            "owner": "son.nguyen@eastgate-software.com",
            "is_read": false
        },
        {
            "created_date": "2023-04-11T06:48:13.643+00:00",
            "updated_by": "son.nguyen@eastgate-software.com",
            "last_modified_date": "2023-04-11T07:24:22.074+00:00",
            "id": "643502ad3674505c482c72fd",
            "severity": "INFO",
            "type": "IMPORTING",
            "message": {
                "en": "The manufacturing records was imported successfully for category SDI Butler Plus"
            },
            "owner": "son.nguyen@eastgate-software.com",
            "is_read": true
        }
    ],
    "num_of_unread": 1
}
```

### 6.2 Mark all as read
- Mark all the notification of the logged in user as read
- `PUT: /notification/mark-as-read`

## 7. Prediction
- This APIs will forward the request from client to AI service then return the response from AI-service to client

## 7.1 Distribution prediction
- POST: /prediction/distribution

```text
- Request body is required
- Http status 200 will be returned if prediction process is succeeded, otherwise return 400
```

## 7.2 Property prediction
- POST: /prediction/property

```text
- Request body is required
- Http status 200 will be returned if prediction process is succeeded, otherwise return 400
```
