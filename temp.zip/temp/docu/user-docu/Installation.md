# USER MANUAL

`Amatrium server version 1.0.0. Updated at: 07-03-2023`

## Table Of Contents

- [1. Introduction](#1-introduction)
- [2. Prerequisite](#2-prerequisite)
- [3. Installation](#3-installation)
    - [3.1. Update configuration](#31-update-configuration)
    - [3.2. Start the application](#32-start-the-application)
    - [3.3. Testing](#33-testing)

## 1. Introduction

This document describes step-by-step to deploy the application in the local using docker container

## 2. Prerequisite

The following libs/programs need to be installed and started: 
- JDK
- Maven
- Docker
- MongoDB server

## 3. Installation

### 3.1 Update configuration

Open the `src/main/resource/application.yml` then update the value of: 
- Database connection
- Email information
- The url of the web-ui in your environment (needed if you want to send email)

### 3.2 Start the application
- Run the command prompt and execute the following command

```cmd
./local-deploy.sh
```

- This command will start your application in the docker container

### 3.3 Testing

- Open the browser and go to `http://localhost:8000/api/v3/actuator/health/liveness`

![Health-Check](../.img/health-check.png)
