# Application name

## Description

A platform to answer complex materials questions quickly by bringing the right information to the people who need it

### Links

> Links to other documentations like architecture, user-docu or pages in one of the other projects in the group.

* [Architectural Overview](.img/architecture-overview.png)
* User Documentation
    - [Overview](user-docu/ApplicationOverview.md)
    - [Installation](user-docu/Installation.md)

## Responsible Teams

| **Role** | **Who** |
| --- | --- |
| Software Solution | Son Nguyen (son.nguyen@eastgate-software.com) |
| QA/BA | Kien Pham (kien.pham@eastgate-software.com) |
