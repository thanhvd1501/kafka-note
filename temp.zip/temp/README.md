# Overview

## Description

A platform to answer complex materials questions quickly by bringing the right information to the people who need it

### System Architecture

Overview of the application architecture:

![System-Architecture](./docu/.img/architecture-overview.png)

## Getting Started

`Realease version: 1.0.0`

### Dependencies

- JDK 17
- Spring Boot 3.0.3
- Securing using Spring OAuth2 and Keycloak
- QueryDSL 5.0.0
- Lombok
- Log4j2

### Package structure

- `config:` contains the config of the application (such as: security config, task executors config, keycloak config, etc.)
- `controller:` define all the ResAPIs that will be provided to outside
- `service:` where the business logic is implemented
- `entity:` the objects mapped with database table
- `dto:` the response objects used to return to client
- `exception:` the customization exception

### Installing

#### 1. Setting up local development environment

- Install JDK 17
- Install Apache Maven 3.6.3 (or higher)

#### 2. Build and run the application

- Go to the project directory and run the command
```text
mvn clean package
```

- After building completed, go to `/target` directory then run the command
```text
java -jar amatrium-1.0.0.jar
```

## Responsible Teams

| **Role** | **Who** |
| --- | --- |
| Software Solution | Son Nguyen (son.nguyen@eastgate-software.com) |
| QA/BA | Kien Pham (kien.pham@eastgate-software.com) |
