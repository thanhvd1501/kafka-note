#!/bin/bash

set -e

ECR_TAG=$1
if [ -z $1 ]
	then 
		ECR_TAG=0
fi

# Must match with helm-chart/Chart.yaml
CHART_NAME=amatrium-server
APP_PORT=8000
RELEASE_NAME=$CHART_NAME

# Define tag based on the latest code commit in your local (please execute git pull to ensure everything is up-to-date)
GIT_COMMIT=$(git log -1 --format=%h)
OLD_CONTAINER_ID=`docker container ls | grep "$CHART_NAME:*" | awk '{ print $1 }'`

./docker-build.sh

# Run the application as the docker container
## Stop the running container
if [ -n OLD_CONTAINER_ID ]
	then
		docker stop $OLD_CONTAINER_ID
		echo "Stopped the container $OLD_CONTAINER_ID"
		docker rm $OLD_CONTAINER_ID
		echo "Cleaned the old container"
		echo "."
		echo "."
		echo "."
fi
## Start the new container with new image
docker run -e "SPRING_PROFILES_ACTIVE=default" -d -p $APP_PORT:$APP_PORT $CHART_NAME:$GIT_COMMIT

# Remove the untagged images
docker rmi $(docker images -f "dangling=true" -q)
