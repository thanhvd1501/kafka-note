#!/bin/bash

set -e

# Must match with helm-chart/Chart.yaml
CHART_NAME=amatrium-server
APP_PORT=8000
RELEASE_NAME=$CHART_NAME
ECR_QA=612793934435.dkr.ecr.us-east-1.amazonaws.com
ECR_REPO_QA=amatrium-qa
ECR_PROD=781224683093.dkr.ecr.us-east-1.amazonaws.com
ECR_REPO_PROD=amatrium-cbmm-prod

# Enter the project name
ENVIRONMENT=""
while true
  do
      echo ""
	  read -p "--- Select the enviroment(qa/prod. Leave it empty to build docker image in your local only): " environment
	  ENVIRONMENT=`echo $environment | sed 's/ *$//g'`
	  break
done

if [ -n "$ENVIRONMENT" ] && [ "$ENVIRONMENT" != "qa" -a "$ENVIRONMENT" != "prod" ]
  then
    echo "The env $ENVIRONMENT is not allowed. Please select 'qa' or 'prod'. (Leave it empty to build docker image in your local only)"
	exit 1
fi

# Build project
mvn clean package -Dmaven.test.skip
rc=$?
if [[ $rc -ne 0 ]] ; then
  echo 'Failed to build the application'; exit $rc
fi

# Define tag based on the latest code commit in your local (please execute git pull to ensure everything is up-to-date)
GIT_COMMIT=$(git log -1 --format=%h)

# Create docker image
echo "."
echo "."
echo "."
# Retrieve the id of old container before build the new tag
OLD_CONTAINER_ID=`docker container ls | grep "$CHART_NAME:*" | awk '{ print $1 }'`
echo "Old local container: $OLD_CONTAINER_ID"
echo ""
echo "--- Build the new docker image: ---"
echo "docker build --no-cache -f Dockerfile -t $CHART_NAME:$GIT_COMMIT --build-arg server_port=$APP_PORT ."
echo ""
docker build --no-cache -f Dockerfile -t $CHART_NAME:$GIT_COMMIT --build-arg server_port=$APP_PORT .

# Push the image to ECR
if [ -n $ENVIRONMENT ]
	then
		echo ""
		echo "--- Push docker image to docker registry in $ENVIRONMENT environment ---"
	    ECR=$ECR_QA
		ECR_REPO=$ECR_REPO_QA
		if [ $ENVIRONMENT == "prod" ]
		  then
		    ECR=$ECR_PROD
		    ECR_REPO=$ECR_REPO_PROD
	    fi
		
		aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin $ECR
		docker tag $CHART_NAME:$GIT_COMMIT $ECR/$ECR_REPO:latest
		docker push $ECR/$ECR_REPO:latest
		
		# Logout docker
        docker logout
fi

echo ""
echo "--- Completed! ---"
