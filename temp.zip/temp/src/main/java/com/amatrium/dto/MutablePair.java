package com.amatrium.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @param <F>     type of first thing
 * @param <S>type of second thing
 */
@Data
@AllArgsConstructor
public class MutablePair<F, S> {
    private F first;
    private S second;
}
