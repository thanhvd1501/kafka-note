package com.amatrium.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
public class AuditorDto implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("created_by")
    private String createdBy;

    @JsonProperty("created_date")
    private Date createdDate;

    @JsonProperty("updated_by")
    private String updatedBy;

    @JsonProperty("last_modified_date")
    private Date lastModifiedDate;

}
