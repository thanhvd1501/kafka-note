package com.amatrium.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class NotificationDto extends AuditorDto {

    @JsonProperty("id")
    private String id;

    @JsonProperty("severity")
    private String severity;

    @JsonProperty("type")
    private String type;

    //Key saves the "en", value save "language"
    @JsonProperty("message")
    private Map<String, String> message;

    // it should be username/email
    @JsonProperty("owner")
    private String owner;

    @JsonProperty("is_read")
    private Boolean isRead;
}
