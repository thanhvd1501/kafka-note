package com.amatrium.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BaseErrorDto {

    @JsonProperty("timestamp")
    protected Date timestamp;

    @JsonProperty("error_message")
    protected String errorMessage;
}
