package com.amatrium.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class BaseResponseDto<T> {

    @JsonProperty("timestamp")
    protected Long timestamp;

    @JsonProperty("data")
    protected T data;

    public BaseResponseDto(T data) {
        this.data = data;
        this.timestamp = System.currentTimeMillis();
    }
}
