package com.amatrium.cache;

import com.amatrium.domaintype.FunctionType;
import com.amatrium.domaintype.StateType;
import com.amatrium.entity.FunctionState;
import com.amatrium.exception.InternalException;
import com.amatrium.repository.FunctionStateRepository;
import com.amatrium.repository.predicate.FunctionStatePredicate;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.locks.StampedLock;

@Component
@Slf4j
public class ProcessingTaskManagerImpl implements ProcessingTaskManager {

    private static final String MSG_INVALID_CATEGORY = "Invalid category id";

    private final StampedLock categoryLock = new StampedLock();

    @Autowired
    private FunctionStateRepository functionStateRepo;

    @Override
    public void lockCategoryForImporting(String categoryId) throws InternalException {
        lockCategory(categoryId, FunctionType.IMPORT);
    }

    @Override
    public void lockCategoryForTrainingModel(String categoryId) throws InternalException {
        lockCategory(categoryId, FunctionType.RETRAIN);
    }

    @Override
    public boolean unlockCategory(String categoryId, StateType state) {
        if (categoryId == null) {
            return false;
        }

        if (state == null) {
            state = StateType.COMPLETED;
        }

        if (!state.equals(StateType.COMPLETED) && !state.equals(StateType.FAILED)) {
            log.error("Function state is not valid: " + state);
            return false;
        }

        long stamp = categoryLock.writeLock();
        try {
            Predicate predicate = new FunctionStatePredicate()
                    .categoryId(categoryId)
                    .stateIn(List.of(StateType.NEW, StateType.IN_PROGRESS))
                    .getCondition();

            List<FunctionState> functionStateList = functionStateRepo.find(predicate);
            if (functionStateList.isEmpty()) {
                log.error("No task is running for the category " + categoryId);
                return false;
            }
            for (FunctionState functionState : functionStateList) {
                functionState.setState(state.name());
                functionStateRepo.save(functionState);
            }
            return true;
        } finally {
            categoryLock.unlock(stamp);
        }
    }

    @Override
    public boolean isCategoryLocked(String categoryId) throws InternalException {
        if (categoryId == null) {
            throw new InternalException(MSG_INVALID_CATEGORY);
        }

        long stamp = categoryLock.readLock();
        try {
            Predicate predicate = new FunctionStatePredicate()
                    .categoryId(categoryId)
                    .stateIn(List.of(StateType.NEW, StateType.IN_PROGRESS))
                    .getCondition();

            List<FunctionState> functionStateList = functionStateRepo.find(predicate);

            return !functionStateList.isEmpty();
        } finally {
            categoryLock.unlock(stamp);
        }
    }

    private void lockCategory(String categoryId, FunctionType type) throws InternalException {
        if (categoryId == null) {
            throw new InternalException(MSG_INVALID_CATEGORY);
        }

        long stamp = categoryLock.writeLock();
        try {
            Predicate predicate = new FunctionStatePredicate()
                    .categoryId(categoryId)
                    .stateIn(List.of(StateType.NEW, StateType.IN_PROGRESS))
                    .getCondition();
            List<FunctionState> functionStateList = functionStateRepo.find(predicate);
            if (!functionStateList.isEmpty()) {
                throw new InternalException(String.format("The category %s is already locked to executing %s", categoryId, functionStateList.get(0).getType()));
            }

            FunctionState functionState = FunctionState.builder()
                    .categoryId(categoryId)
                    .type(type.name())
                    .state(FunctionType.IMPORT.equals(type) ? StateType.IN_PROGRESS.name() : StateType.NEW.name())
                    .build();
            functionStateRepo.save(functionState);
        } finally {
            categoryLock.unlock(stamp);
        }
    }
}
