package com.amatrium.cache;

import com.amatrium.domaintype.StateType;
import com.amatrium.exception.InternalException;

public interface ProcessingTaskManager {

    /**
     * Lock the category to start executing import
     *
     * @param categoryId
     * @throws InternalException
     */
    void lockCategoryForImporting(String categoryId) throws InternalException;

    /**
     * Lock the category to start executing training model
     *
     * @param categoryId
     * @throws InternalException
     */
    void lockCategoryForTrainingModel(String categoryId) throws InternalException;

    /**
     * @param categoryId
     * @param state COMPLETED or FAILED
     * @return
     */
    boolean unlockCategory(String categoryId, StateType state);

    /**
     * Check if category is locked for a task processing
     *
     * @param categoryId
     * @return
     * @throws InternalException
     */
    boolean isCategoryLocked(String categoryId) throws InternalException;
}
