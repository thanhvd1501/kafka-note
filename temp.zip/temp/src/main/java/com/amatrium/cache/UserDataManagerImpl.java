package com.amatrium.cache;

import com.amatrium.config.ApplicationConfig;
import com.amatrium.exception.InternalException;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.internal.bytebuddy.utility.RandomString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.StampedLock;

@Component
@Slf4j
public class UserDataManagerImpl implements UserDataManager {

    private static final int SECRET_LENGTH = 64;

    private final StampedLock resetPwdLock = new StampedLock();

    private final StampedLock blacklistLock = new StampedLock();

    private final Map<String, Map<String, Long>> resetPwdCodeMapping = new HashMap<>();

    /**
     * Map from user to the timestamp (Access token was created before this time will be expired)
     */
    private final Map<String, Long> blacklistTokenMapping = new HashMap<>();

    @Autowired
    private ApplicationConfig appConfig;

    @Override
    public String generateUserSecret(String user) throws InternalException {
        if (!StringUtils.hasText(user)) {
            throw new InternalException("Invalid user");
        }

        // generate a secret code
        String secret = RandomString.make(SECRET_LENGTH);
        long stamp = resetPwdLock.writeLock();
        try {
            resetPwdCodeMapping.computeIfAbsent(user, c -> new HashMap<>());
            resetPwdCodeMapping.get(user).put(secret, System.currentTimeMillis());
        } finally {
            resetPwdLock.unlock(stamp);
        }

        return secret;
    }

    @Override
    public boolean verifyUserSecret(String user, String code) {
        if (!StringUtils.hasText(user)) {
            return false;
        }

        long stamp = resetPwdLock.readLock();
        try {
            Map<String, Long> secretCodes = resetPwdCodeMapping.getOrDefault(user, Map.of());
            Long createdTime = secretCodes.get(code);

            return createdTime != null && (createdTime - System.currentTimeMillis()) < appConfig.getSecretCodeLifespan() * 60 * 1000L;
        } finally {
            resetPwdLock.unlock(stamp);
        }
    }

    @Override
    public void clean(String user, Long beforeTime) {
        long stamp = resetPwdLock.writeLock();
        try {
            // clean all data
            if (user == null && beforeTime == null) {
                log.info("Clean all the reset password code");
                resetPwdCodeMapping.clear();
                return;
            }

            // clean all the code of a certain user
            if (beforeTime == null) {
                resetPwdCodeMapping.remove(user);
                log.info("Clean all the reset password code of the user " + user);
                return;
            }

            // clean the expired code only of all users
            if (user == null) {
                resetPwdCodeMapping.values().forEach(m -> {
                    m.entrySet().removeIf(e -> e.getValue() <= beforeTime);
                });
            } else {
                // otherwise, remove the expiration code of a certain user
                Map<String, Long> userCode = resetPwdCodeMapping.get(user);
                userCode.entrySet().removeIf(e -> e.getValue() <= beforeTime);
            }
        } finally {
            resetPwdLock.unlock(stamp);
        }
    }

    @Override
    public void markAccessExpired(String user, Long issuedBefore) throws InternalException {
        if (!StringUtils.hasText(user)) {
            throw new InternalException("Invalid user");
        }

        long stamp = blacklistLock.writeLock();
        try {
            blacklistTokenMapping.put(user, issuedBefore);
        } finally {
            blacklistLock.unlock(stamp);
        }
    }

    @Override
    public void cleanExpirationCache(Long beforeTime) {
        long stamp = blacklistLock.writeLock();
        try {
            for (String key : blacklistTokenMapping.keySet()) {
                if (blacklistTokenMapping.get(key) <= beforeTime) {
                    blacklistTokenMapping.remove(key);
                }
            }
        } finally {
            blacklistLock.unlock(stamp);
        }

    }

    @Override
    public boolean verifyIssueTime(String user, Date issueTime) {
        if (user == null || issueTime == null) {
            return false;
        }

        long stamp = blacklistLock.readLock();
        try {
            if (blacklistTokenMapping.containsKey(user) && issueTime.getTime() <= blacklistTokenMapping.get(user)) {
                return false;
            }
        } finally {
            blacklistLock.unlock(stamp);
        }
        return true;
    }

}
