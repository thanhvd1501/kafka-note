package com.amatrium.cache;

import com.amatrium.exception.InternalException;

import java.util.Date;

public interface UserDataManager {

    /**
     * Store the secret code when user request to reset the pwd
     *
     * @param user
     * @return the secret code
     * @throws InternalException
     */
    String generateUserSecret(String user) throws InternalException;

    /**
     * Verify if the secret code is valid to reset code
     *
     * @param user
     * @param code
     * @return
     */
    boolean verifyUserSecret(String user, String code);

    /**
     * Clean the expiration secret
     *
     * @param user       the specific user. Null means all users
     * @param beforeTime the expiration time. Null mean all the time
     */
    void clean(String user, Long beforeTime);

    /**
     * Store timestamp when change role of user
     *
     * @param user
     * @param issuedBefore
     */
    void markAccessExpired(String user, Long issuedBefore) throws InternalException;

    /**
     * Clean expiration cache
     *
     * @param beforeTime
     */
    void cleanExpirationCache(Long beforeTime);

    /**
     * Verify issueTime of user
     *
     * @param user
     * @param issueTime
     */
    boolean verifyIssueTime(String user, Date issueTime);
}
