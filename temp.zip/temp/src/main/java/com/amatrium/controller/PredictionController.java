package com.amatrium.controller;

import com.amatrium.domaintype.PredictionType;
import com.amatrium.exception.InternalException;
import com.amatrium.service.CategoryService;
import com.nimbusds.jose.shaded.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PredictionController implements PredictionResource {

    @Autowired
    private CategoryService categoryService;

    @Override
    public ResponseEntity<Object> predictDistribution(Object jsonObject) throws InternalException {
        return ResponseEntity.ok(categoryService.predict(PredictionType.DISTRIBUTION, jsonObject));
    }

    @Override
    public ResponseEntity<Object> predictProperty(JsonObject request) throws InternalException {
        return ResponseEntity.ok(categoryService.predict(PredictionType.PROPERTY, request));
    }
}
