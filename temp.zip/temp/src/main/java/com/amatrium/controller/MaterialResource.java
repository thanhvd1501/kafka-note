package com.amatrium.controller;

import com.amatrium.dto.MaterialDto;
import com.amatrium.exception.InternalException;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@RequestMapping(MaterialResource.MATERIAL_RESOURCE)
public interface MaterialResource {

    String MATERIAL_RESOURCE = "/material";

    @GetMapping("/{material_id}")
    ResponseEntity<MaterialDto> getMaterials(@PathVariable("material_id") String materialId) throws InternalException;

    @RolesAllowed({"ADMIN", "DATA_ENTRY"})
    @PostMapping("/import")
    ResponseEntity<Void> importMaterial(
            @RequestParam(value = "category_id") String categoryId,
            @RequestParam(value = "is_partial_import", required = false, defaultValue = "true") boolean isPartialImport,
            @RequestParam(value = "file") MultipartFile file
    ) throws InternalException;
}