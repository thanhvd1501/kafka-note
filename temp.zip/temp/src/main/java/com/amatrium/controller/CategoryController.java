package com.amatrium.controller;

import com.amatrium.dto.BaseResponseDto;
import com.amatrium.dto.CategoryDto;
import com.amatrium.dto.ExportDataResponseDto;
import com.amatrium.exception.InternalException;
import com.amatrium.service.CategoryService;
import com.amatrium.service.ImportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
public class CategoryController implements CategoryResource {

    @Autowired
    private CategoryService svc;

    @Autowired
    private ImportService importService;

    @Override
    public ResponseEntity<List<CategoryDto>> getCategories(String text) throws InternalException {
        return ResponseEntity.ok(svc.search(text));
    }

    @Override
    public ResponseEntity<Void> importManufacturingRecord(String categoryId, boolean isPartialImport, MultipartFile file) throws InternalException {
        importService.importManufacturingRecord(categoryId, isPartialImport, file);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<Resource> exportData(String categoryId, String material) throws InternalException {
        ExportDataResponseDto response = importService.exportToCsv(categoryId, material);
        ByteArrayResource resource = new ByteArrayResource(response.getData().getBytes());
        HttpHeaders httpHeaders = new HttpHeaders();
        String fileName = StringUtils.hasText(material) ? response.getCategoryName() + "_" + material : response.getCategoryName();
        String attachmentName = String.format("attachment;filename=%s.csv", fileName.trim().replaceAll("\\s+", "_"));
        httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION, attachmentName);
        httpHeaders.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);

        return ResponseEntity.ok()
                .headers(httpHeaders)
                .contentLength(resource.contentLength())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }

    @Override
    public ResponseEntity<BaseResponseDto<String>> requestRetrainModel(String categoryId) throws InternalException {
        String secret = svc.requestTrainingModel(categoryId);
        return ResponseEntity.ok(new BaseResponseDto<>(secret));
    }

    @Override
    public ResponseEntity<Void> startTrainingModel(String categoryId, String secret) throws InternalException {
        svc.startTrainingModel(categoryId, secret);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<Void> completeTrainingModel(String categoryId, boolean isSuccess) throws InternalException {
        svc.completeTrainingModel(categoryId, isSuccess);
        return ResponseEntity.ok().build();
    }
}
