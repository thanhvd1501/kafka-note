package com.amatrium.controller;

import com.amatrium.notification.sse.IdentifiableSseEmitter;
import com.amatrium.notification.sse.SseManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;

@RestController
@Slf4j
public class SseController implements SseResource {

    @Autowired
    private SseManager sseManager;

    @Override
    public SseEmitter establishConnection() {
        IdentifiableSseEmitter emitter = sseManager.establish();

        SseEmitter.SseEventBuilder eventBuilder = SseEmitter.event().name(SseManager.CONNECTION_ID)
                .data(emitter.getId());
        try {
            emitter.send(eventBuilder);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }

        return emitter;
    }
}
