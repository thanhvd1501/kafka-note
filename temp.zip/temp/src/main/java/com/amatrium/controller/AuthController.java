package com.amatrium.controller;

import com.amatrium.dto.BaseResponseDto;
import com.amatrium.dto.LoginRequestDto;
import com.amatrium.dto.TokenPairDto;
import com.amatrium.exception.InternalException;
import com.amatrium.exception.UnauthorizedException;
import com.amatrium.security.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController implements AuthResource {

    @Autowired
    private AuthService authService;

    @Override
    public ResponseEntity<TokenPairDto> login(LoginRequestDto credentials) throws UnauthorizedException {
        return ResponseEntity.ok(authService.login(credentials.getUsername(), credentials.getPassword()));
    }

    @Override
    public ResponseEntity<BaseResponseDto<Boolean>> sendResetPasswordEmail(String email) throws InternalException {
        return ResponseEntity.ok(new BaseResponseDto<>(System.currentTimeMillis(), authService.sendResetPasswordEmail(email)));
    }

    @Override
    public ResponseEntity<BaseResponseDto<Boolean>> resetUserPassword(String code, String email, String password) throws InternalException {
        return ResponseEntity.ok(new BaseResponseDto<>(System.currentTimeMillis(), authService.resetUserPassword(code, email, password)));
    }
}
