package com.amatrium.controller;

import com.amatrium.dto.BaseResponseDto;
import com.amatrium.dto.LoginRequestDto;
import com.amatrium.dto.TokenPairDto;
import com.amatrium.exception.InternalException;
import com.amatrium.exception.UnauthorizedException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequestMapping(AuthResource.AUTH_RESOURCE)
public interface AuthResource {

    String AUTH_RESOURCE = "/auth";

    @PostMapping("/login")
    ResponseEntity<TokenPairDto> login(@RequestBody LoginRequestDto credentials) throws UnauthorizedException;

    @PostMapping("/reset-password/request")
    ResponseEntity<BaseResponseDto<Boolean>> sendResetPasswordEmail(@RequestParam(value = "email") String email) throws InternalException;

    @PostMapping("/reset-password")
    ResponseEntity<BaseResponseDto<Boolean>> resetUserPassword(
            @RequestParam("code") String code,
            @RequestParam("email") String email,
            @RequestParam("password") String password) throws InternalException;
}
