package com.amatrium.controller;

import com.amatrium.dto.BaseResponseDto;
import com.amatrium.dto.ChangePasswordRequestDto;
import com.amatrium.dto.UserDto;
import com.amatrium.exception.InternalException;
import com.amatrium.service.UsersManagementService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UsersManagementController implements UsersManagementResource {
    private final UsersManagementService userManagementService;

    public UsersManagementController(UsersManagementService userManagementService) {
        this.userManagementService = userManagementService;
    }

    @Override
    public ResponseEntity<List<UserDto>> getAllUsers() {
        return ResponseEntity.ok(userManagementService.getAllUsers());
    }

    @Override
    public ResponseEntity<UserDto> getUserById(String userId) throws InternalException {
        return ResponseEntity.ok(userManagementService.getUserDetails(userId));
    }

    @Override
    public ResponseEntity<UserDto> createNewUser(UserDto userInfo) throws InternalException {
        return ResponseEntity.ok(userManagementService.createNewUser(userInfo));
    }

    @Override
    public ResponseEntity<BaseResponseDto<Boolean>> deleteUser(String userId) throws InternalException {
        return ResponseEntity.ok(new BaseResponseDto<>(System.currentTimeMillis(), userManagementService.deleteUser(userId)));
    }

    @Override
    public ResponseEntity<List<String>> getUserRole() {
        return ResponseEntity.ok(userManagementService.getAllUserRole());
    }

    @Override
    public ResponseEntity<BaseResponseDto<Boolean>> changePassword(String userId, ChangePasswordRequestDto request) throws InternalException {
        return ResponseEntity.ok(new BaseResponseDto<>(System.currentTimeMillis(), userManagementService.changePassword(userId, request.getOldPassword(), request.getNewPassword())));
    }

    @Override
    public ResponseEntity<BaseResponseDto<Boolean>> updateUserRole(String userId, String role) throws InternalException {
        return ResponseEntity.ok(new BaseResponseDto<>(System.currentTimeMillis(), userManagementService.updateUserRole(userId, role)));
    }
}
