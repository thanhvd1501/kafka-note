package com.amatrium.controller;

import com.amatrium.dto.NotificationListDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequestMapping(NotificationResource.NOTIFICATION_RESOURCE)
public interface NotificationResource {

    String NOTIFICATION_RESOURCE = "/notification";

    @GetMapping()
    ResponseEntity<NotificationListDto> getUserNotification(
            @RequestParam(value = "isRead", required = false) Boolean isRead
    );

    @PutMapping("/mark-as-read")
    ResponseEntity<Void> markAllAsRead();
}