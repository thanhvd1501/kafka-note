package com.amatrium.controller;

import com.amatrium.dto.BaseResponseDto;
import com.amatrium.dto.CategoryDto;
import com.amatrium.exception.InternalException;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RequestMapping(CategoryResource.CATEGORY_RESOURCE)
public interface CategoryResource {
    String CATEGORY_RESOURCE = "/category";

    @GetMapping
    ResponseEntity<List<CategoryDto>> getCategories(
            @RequestParam(value = "text", required = false) String text
    ) throws InternalException;

    @RolesAllowed({"ADMIN", "DATA_ENTRY"})
    @PostMapping("/{category_id}/historical/import")
    ResponseEntity<Void> importManufacturingRecord(
            @PathVariable(value = "category_id") String categoryId,
            @RequestParam(value = "is_partial_import", required = false, defaultValue = "true") boolean isPartialImport,
            @RequestParam(value = "file") MultipartFile file
    ) throws InternalException;

    @RolesAllowed({"ADMIN", "DATA_ENTRY"})
    @GetMapping("/{category_id}/historical/export")
    ResponseEntity<Resource> exportData(
            @PathVariable(value = "category_id") String categoryId,
            @RequestParam(value = "material", required = false) String material
    ) throws InternalException;

    @RolesAllowed({"ADMIN", "DATA_ENTRY"})
    @PostMapping("/{category_id}/training-model")
    ResponseEntity<BaseResponseDto<String>> requestRetrainModel(@PathVariable(value = "category_id") String categoryId) throws InternalException;

    /**
     * This API is public (access token is not required)
     *
     * @param categoryId
     * @param secret
     * @return
     * @throws InternalException
     */
    @PutMapping("/{category_id}/training-model/start")
    ResponseEntity<Void> startTrainingModel(
            @PathVariable(value = "category_id") String categoryId,
            @RequestParam(value = "secret") String secret) throws InternalException;

    /**
     * This API is public (access token is not required)
     *
     * @param categoryId
     * @param isSuccess
     * @return
     * @throws InternalException
     */
    @PutMapping("/{category_id}/training-model/completed")
    ResponseEntity<Void> completeTrainingModel(
            @PathVariable(value = "category_id") String categoryId,
            @RequestParam(value = "is_success") boolean isSuccess) throws InternalException;

}
