package com.amatrium.controller;

import com.amatrium.dto.BaseResponseDto;
import com.amatrium.dto.ChangePasswordRequestDto;
import com.amatrium.dto.UserDto;
import com.amatrium.exception.InternalException;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@RequestMapping(UsersManagementResource.USER_RESOURCE)
public interface UsersManagementResource {
    String USER_RESOURCE = "/user";

    @GetMapping
    ResponseEntity<List<UserDto>> getAllUsers();

    @GetMapping("/{user_id}")
    ResponseEntity<UserDto> getUserById(
            @PathVariable(value = "user_id") String userId
    ) throws InternalException;

    @GetMapping("/role")
    ResponseEntity<List<String>> getUserRole();

    @RolesAllowed({"SUPER_ADMIN", "ADMIN"})
    @PostMapping
    ResponseEntity<UserDto> createNewUser(
            @RequestBody UserDto userInfo
    ) throws InternalException;

    @RolesAllowed({"SUPER_ADMIN", "ADMIN"})
    @DeleteMapping("/{user_id}")
    ResponseEntity<BaseResponseDto<Boolean>> deleteUser(
            @PathVariable(value = "user_id") String userId
    ) throws InternalException;

    @PatchMapping("/{user_id}/change-password")
    ResponseEntity<BaseResponseDto<Boolean>> changePassword(
            @PathVariable(value = "user_id") String userId,
            @RequestBody ChangePasswordRequestDto request
    ) throws InternalException;

    @RolesAllowed({"ADMIN"})
    @PatchMapping("/{user_id}/role")
    ResponseEntity<BaseResponseDto<Boolean>> updateUserRole(
            @PathVariable(value = "user_id") String userId,
            @RequestParam(value = "role") String role
    ) throws InternalException;
}
