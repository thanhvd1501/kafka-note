package com.amatrium.controller;

import com.amatrium.dto.NotificationListDto;
import com.amatrium.service.NotificationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NotificationController implements NotificationResource {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @Override
    public ResponseEntity<NotificationListDto> getUserNotification(Boolean isRead) {
        return ResponseEntity.ok(notificationService.getUserNotification(isRead));
    }

    @Override
    public ResponseEntity<Void> markAllAsRead() {
        notificationService.markAllAsRead();
        return ResponseEntity.ok().build();
    }
}