package com.amatrium.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@RequestMapping(SseResource.SSE_RESOURCE)
public interface SseResource {

    String SSE_RESOURCE = "/sse";

    @GetMapping("connection")
    SseEmitter establishConnection();
}
