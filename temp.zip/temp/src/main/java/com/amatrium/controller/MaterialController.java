package com.amatrium.controller;

import com.amatrium.dto.MaterialDto;
import com.amatrium.exception.InternalException;
import com.amatrium.service.MaterialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class MaterialController implements MaterialResource {

    @Autowired
    private MaterialService service;

    @Override
    public ResponseEntity<MaterialDto> getMaterials(String materialId) throws InternalException {
        return ResponseEntity.ok(service.getMaterialById(materialId));
    }

    @Override
    public ResponseEntity<Void> importMaterial(String categoryId, boolean isPartialImport, MultipartFile file) throws InternalException {
        service.importMaterials(categoryId, isPartialImport, file);
        return ResponseEntity.ok().build();
    }
}
