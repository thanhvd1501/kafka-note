package com.amatrium.controller;

import com.amatrium.exception.InternalException;
import com.nimbusds.jose.shaded.gson.JsonObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping(PredictionResource.PREDICTION_RESOURCE)
public interface PredictionResource {

    String PREDICTION_RESOURCE = "/prediction";

    @Deprecated
    @PostMapping("/distribution")
    ResponseEntity<Object> predictDistribution(@RequestBody Object jsonObject) throws InternalException;

    @Deprecated
    @PostMapping("/property")
    ResponseEntity<Object> predictProperty(@RequestBody JsonObject request) throws InternalException;
}
