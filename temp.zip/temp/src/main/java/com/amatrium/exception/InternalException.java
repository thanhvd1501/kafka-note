package com.amatrium.exception;

/**
 * @author Son Nguyen
 */
public class InternalException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public InternalException(String msg) {
        super(msg);
    }

    public InternalException(String msg, Throwable t) {
        super(msg, t);
    }

}
