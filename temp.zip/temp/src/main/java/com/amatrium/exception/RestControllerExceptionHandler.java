package com.amatrium.exception;

import com.amatrium.constant.I18nConstant;
import com.amatrium.dto.BaseErrorDto;
import com.amatrium.service.I18nMessageService;
import jakarta.xml.bind.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * @authow Son Nguyen
 */
@ControllerAdvice
@Slf4j
public class RestControllerExceptionHandler extends ResponseEntityExceptionHandler {

    @Autowired
    private I18nMessageService i18nMessageService;

    /**
     * Handle the Access Denied Exception
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(UnauthorizedException.class)
    public final ResponseEntity<Object> handleUnauthorizedException(UnauthorizedException ex) {
        log.error("", ex);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    /**
     * Handle the Access Denied Exception
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(AccessDeniedException.class)
    public final ResponseEntity<Object> handleAccessDeniedException(AccessDeniedException ex) {
        log.error("", ex);
        String msg = i18nMessageService.translate(I18nConstant.ERR_PERMISSION_DENIED);
        BaseErrorDto baseErrorDto = new BaseErrorDto(new Timestamp(System.currentTimeMillis()), msg);

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(baseErrorDto);
    }

    /**
     * Handle the Multipart Exception
     *
     * @param ex
     * @return
     */
    @ExceptionHandler({
            MultipartException.class,
            ValidationException.class,
            InternalException.class,
            AspectException.class
    })
    public ResponseEntity<Object> handleMultipartException(Exception ex) {
        log.error("", ex);
        BaseErrorDto error = BaseErrorDto.builder()
                .timestamp(new Date())
                .errorMessage(ex.getMessage())
                .build();

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }

    /**
     * Handle the Internal Server Error
     *
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> handleException(Exception e) {
        log.error("", e);
        BaseErrorDto error = BaseErrorDto.builder()
                .timestamp(new Date())
                .errorMessage("Server Error")
                .build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                                                  HttpHeaders headers,
                                                                  HttpStatusCode status,
                                                                  WebRequest request) {
        log.error("", ex);
        List<String> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .toList();
        String errorMsg = String.format("Value of the argument(s) \"%s\" is invalid", StringUtils.collectionToCommaDelimitedString(errors));
        BaseErrorDto error = BaseErrorDto.builder()
                .timestamp(new Date())
                .errorMessage(errorMsg)
                .build();
        return ResponseEntity.badRequest().body(error);
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex,
                                                                          HttpHeaders headers,
                                                                          HttpStatusCode status,
                                                                          WebRequest request) {
        log.error("", ex);
        BaseErrorDto error = BaseErrorDto.builder()
                .timestamp(new Date())
                .errorMessage(ex.getMessage())
                .build();
        return ResponseEntity.badRequest().body(error);
    }

}
