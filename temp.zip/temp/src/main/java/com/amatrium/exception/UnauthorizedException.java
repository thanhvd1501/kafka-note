package com.amatrium.exception;

/**
 * @author Son Nguyen
 */
public class UnauthorizedException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public UnauthorizedException(String msg) {
        super(msg);
    }

    public UnauthorizedException(String msg, Throwable t) {
        super(msg, t);
    }

}
