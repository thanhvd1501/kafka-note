package com.amatrium.exception;

/**
 * @author Son Nguyen
 */
public class AspectException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public AspectException(String msg) {
        super(msg);
    }

    public AspectException(String msg, Throwable t) {
        super(msg, t);
    }

}
