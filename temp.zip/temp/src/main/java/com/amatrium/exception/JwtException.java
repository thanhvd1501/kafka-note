package com.amatrium.exception;

/**
 *
 */
public class JwtException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public JwtException(String msg) {
        super(msg);
    }
}
