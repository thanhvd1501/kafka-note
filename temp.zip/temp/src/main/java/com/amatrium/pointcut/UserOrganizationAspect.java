package com.amatrium.pointcut;

import com.amatrium.domaintype.UserRole;
import com.amatrium.exception.AspectException;
import com.amatrium.util.SecurityUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

@Aspect
@Component
@Slf4j
public class UserOrganizationAspect {

    @Before("@annotation(OrganizationClaimRequired)")
    public void verifyUserOrganization() {
        Optional<String> currentUserOpt = SecurityUtil.getCurrentUsername();
        String organization = SecurityUtil.getUserOrganization();
        List<UserRole> userRoles = SecurityUtil.getAuthorities();

        if (!StringUtils.hasText(organization) &&
                !userRoles.contains(UserRole.SUPER_ADMIN)) {
            String currentUser = currentUserOpt.isEmpty() ? null : currentUserOpt.get();
            log.error(String.format("The user '%s' is not belong to any organization", currentUser));
            // it's required the add criteria filter of organization for non-super_admin
            throw new AspectException("User does not belong to any organization");
        }
    }
}
