package com.amatrium.util;

/**
 * @author Son Nguyen
 */
public final class PaginationUtil {

    private PaginationUtil() {
    }

    // Pagination
    public static final class Pagination {
        private Pagination() {
        }

        public static final int DEFAULT_PAGE = 0;

        public static final int DEFAULT_SIZE = 10;

        public static final int DEFAULT_MAX_SIZE = 100;

        /**
         * Resolve page number
         *
         * @param page
         * @return
         */
        public static int resolvePage(Integer page) {
            if (page == null || page < 0) {
                return DEFAULT_PAGE;
            }

            return page;
        }

        /**
         * Resolve number of elements of each page
         *
         * @param size
         * @return
         */
        public static int resolveSize(Integer size) {
            if (size == null || size < 0) {
                return DEFAULT_SIZE;
            }
            if (size > DEFAULT_MAX_SIZE) {
                return DEFAULT_MAX_SIZE;
            }

            return size;
        }
    }

    // Sorting
    public static final class Sorting {

        private Sorting() {
        }

        public static final String ASC = "ascend";

        public static final String DESC = "descend";

    }
}
