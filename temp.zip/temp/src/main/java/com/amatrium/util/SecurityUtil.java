package com.amatrium.util;

import com.amatrium.domaintype.UserRole;
import com.amatrium.security.Principal;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;

import java.security.SecureRandom;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * @author Son Nguyen
 */
public final class SecurityUtil {

    private SecurityUtil() {
    }

    /**
     * Resolve token from request
     *
     * @param request
     * @return
     */
    public static String resolveToken(HttpServletRequest request) {
        String bearerToken = null;
        String authentication = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (StringUtils.hasText(authentication) && authentication.startsWith("Bearer ")) {
            bearerToken = authentication.substring(7);
        }

        return bearerToken;
    }

    /**
     * Get the current logged in  user
     *
     * @return current username if user has logged. Otherwise return {@link Optional#empty()}
     */
    public static Optional<String> getCurrentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || authentication.getPrincipal() == null) {
            return Optional.empty();
        }

        // Resolve username depend on type of principal.
        Object principal = authentication.getPrincipal();
        if (principal instanceof Principal) {
            return Optional.of(((Principal) principal).getUsername());
        } else {
            return Optional.empty();
        }
    }

    /**
     * Get the current logged in  user
     *
     * @return current username if user has logged. Otherwise return {@link Optional#empty()}
     */
    public static String getUserOrganization() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || authentication.getPrincipal() == null) {
            return null;
        }

        // Resolve username depend on type of principal.
        Object principal = authentication.getPrincipal();
        if (principal instanceof Principal) {
            return ((Principal) principal).getOrganization();
        } else {
            return null;
        }
    }

    /**
     * Get the user roles
     *
     * @return
     */
    @SuppressWarnings("unchecked")
    public static List<UserRole> getAuthorities() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || authentication.getAuthorities() == null) {
            return Collections.emptyList();
        }

        return authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .map(UserRole::valueOf)
                .toList();
    }

    public static String generateRandomPassword() {
        char[] POSSIBLE_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:'\",<.>/?".toCharArray();
        SecureRandom RANDOM = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            int index = RANDOM.nextInt(POSSIBLE_CHARS.length);
            char c = POSSIBLE_CHARS[index];
            sb.append(c);
        }

        return sb.toString();
    }

}
