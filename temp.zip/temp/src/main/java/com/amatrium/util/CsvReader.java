package com.amatrium.util;

import com.amatrium.dto.MutablePair;
import com.amatrium.entity.ManufacturingRecord;
import com.amatrium.exception.InternalException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

@Slf4j
public final class CsvReader {

    // FEFF because this is the Unicode char represented by the UTF-8 byte order mark UTF8ToAnsiUtils(EF BB BF).
    public static final String UTF8_BOM = "\uFEFF";

    private static final String ERROR_READ_FILE = "Could not read the content of the input file";

    public static final String COMMA_DELIMITER = ",";

    public static final String CSV_CONTENT_TYPE = "text/csv";

    public static final List<String> VALID_LABEL_HEADER = List.of("label", "grade");

    private CsvReader() {
    }

    /**
     * Read the csv file then return the raw data of each line (array of string)
     *
     * @param multipartFile        (required) the input file
     * @param containHeaderAtFirst (optional) If true, skip the first line
     * @param validation           (optional) used to validate the input before creating the object
     * @return List of objects
     * @throws InternalException when any error was occurred
     */
    public static List<String[]> readCsvData(MultipartFile multipartFile,
                                             boolean containHeaderAtFirst,
                                             Function<String[], Boolean> validation) throws InternalException {
        return readCsvData(multipartFile, containHeaderAtFirst, validation, t -> t);
    }

    /**
     * @param multipartFile        the input file
     * @param containHeaderAtFirst (optional) If true, skip the first line
     * @param validation           (optional) used to validate the input before creating the object
     * @param converter            set the values of each line to the object
     * @param <T>                  the target object
     * @return List of objects
     * @throws InternalException when any error was occurred
     */
    public static <T> List<T> readCsvData(MultipartFile multipartFile,
                                          boolean containHeaderAtFirst,
                                          Function<String[], Boolean> validation,
                                          Function<String[], T> converter) throws InternalException {
        if (multipartFile == null || !CsvReader.CSV_CONTENT_TYPE.equals(multipartFile.getContentType())) {
            throw new InternalException("The content type is incorrect. It should be " + CSV_CONTENT_TYPE);
        }

        try {
            return readCsvData(multipartFile.getBytes(), containHeaderAtFirst, validation, converter);
        } catch (IOException e) {
            log.error("", e);
            throw new InternalException(ERROR_READ_FILE);
        }
    }

    /**
     * @param input                the byte array of the content
     * @param containHeaderAtFirst (optional) If true, skip the first line
     * @param validation           (optional) used to validate the input before creating the object
     * @param converter            set the values of each line to the object
     * @param <T>                  the target object
     * @return List of objects
     * @throws InternalException when any error was occurred
     */
    public static <T> List<T> readCsvData(byte[] input,
                                          boolean containHeaderAtFirst,
                                          Function<String[], Boolean> validation,
                                          Function<String[], T> converter) throws InternalException {
        List<T> ret = new ArrayList<>();

        InputStream is = new ByteArrayInputStream(input);
        int lineNumber = 0;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNumber += 1;
                if (isEmptyLine(line) || (lineNumber == 1 && containHeaderAtFirst)) {
                    continue;
                }

                String[] values = removeUtf8BOM(line).split(COMMA_DELIMITER);
                if (validation != null && !validation.apply(values)) {
                    throw new InternalException(String.format("Invalid data at line %d (The data type is incorrect or it can not be empty)", lineNumber));
                }

                T t = converter.apply(values);
                if (t != null) {
                    ret.add(t);
                }
            }
        } catch (IOException e) {
            log.error("", e);
            throw new InternalException("Failed to read the CSV file");
        }

        return ret;
    }

    /**
     * Read historical data from CSV file
     *
     * @param categoryId
     * @param bytes
     * @param requiredSymbols
     * @return
     * @throws InternalException
     */
    public static List<ManufacturingRecord> readManufacturingRecord(
            String categoryId,
            byte[] bytes,
            List<String> requiredSymbols) throws InternalException {
        List<ManufacturingRecord> ret = new ArrayList<>();
        try (InputStream is = new ByteArrayInputStream(bytes);
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            // read the first line as the header
            String line = br.readLine();
            List<String> headers = generateHeaders(Arrays.asList(removeUtf8BOM(line).split(COMMA_DELIMITER)));
            validateHeader(headers, requiredSymbols);

            int lineNumber = 1;
            while ((line = br.readLine()) != null) {
                lineNumber += 1;

                if (isEmptyLine(line)) {
                    continue;
                }

                String[] values = removeUtf8BOM(line).split(COMMA_DELIMITER);
                if (!StringUtils.hasText(values[0])) {
                    throw new InternalException(String.format("Invalid data at line %d. The first data is required as the label name", lineNumber));
                }

                ret.add(createManufacturingRecord(categoryId, headers, values));
            }

            return ret;
        } catch (IOException e) {
            log.error("", e);
            throw new InternalException(ERROR_READ_FILE);
        }
    }

    private static ManufacturingRecord createManufacturingRecord(String categoryId, List<String> headers, String[] values) {
        Map<String, Object> attributes = new LinkedHashMap<>();
        for (int i = 0; i < values.length; i++) {
            if (i >= headers.size()) {
                break;
            }

            String key = headers.get(i);
            if (StringUtils.hasText(key)) {
                try {
                    attributes.put(key, Double.parseDouble(values[i].trim()));
                } catch (Exception e) {
                    attributes.put(key, values[i].trim());
                }
            }
        }

        return ManufacturingRecord.builder()
                .name(values[0].trim()) // always use the first value as the label name
                .attributes(attributes)
                .categoryId(categoryId)
                .build();
    }

    /**
     * @param bytes           content of the input file
     * @param requiredSymbols list of the symbols that are required for the category
     * @return
     * @throws InternalException
     */
    public static Map<String, Map<String, MutablePair<Double, Double>>> readMaterialRecord(byte[] bytes, List<String> requiredSymbols) throws InternalException {
        Map<String, Map<String, MutablePair<Double, Double>>> ret = new HashMap<>();
        try (InputStream is = new ByteArrayInputStream(bytes);
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {

            // Read the list of header
            String line = br.readLine();
            List<String> headers = getMaterialHeaders(line);
            validateHeader(headers, requiredSymbols);

            // parsing data from the file content
            int lineNumber = 2; // the content should start from 2nd line
            while ((line = br.readLine()) != null) {
                lineNumber += 1;
                String[] values = getMaterialDataFromLine(line);
                if (values.length == 0) {
                    continue;
                }

                String label = values[0].trim();
                if (!ret.containsKey(label)) {
                    ret.put(label, new HashMap<>());
                }
                Map<String, MutablePair<Double, Double>> symbolRecordMap = ret.get(label);

                int dataLength = Math.min(values.length, headers.size());
                for (int i = 0; i < dataLength; i++) {
                    String symbol = headers.get(i);
                    if (!requiredSymbols.contains(symbol)) {
                        // No need to get the data of the redundant (undefined) symbol
                        continue;
                    }

                    Double value = parseCompositionValue(values[i]);
                    if (value == null) {
                        throw new InternalException(String.format(
                                "Value of '%s' is '%s' but not a numeric (at line %d)",
                                symbol, values[i], lineNumber));
                    }

                    if (symbolRecordMap.containsKey(symbol)) {
                        MutablePair<Double, Double> pair = symbolRecordMap.get(symbol);
                        // update min value
                        if (pair.getFirst() > value) {
                            pair.setFirst(value);
                        }

                        // update max value
                        if (pair.getSecond() < value) {
                            pair.setSecond(value);
                        }
                    } else {
                        symbolRecordMap.put(symbol, new MutablePair<>(value, value));
                    }
                }
            }
        } catch (IOException e) {
            log.error("", e);
            throw new InternalException(ERROR_READ_FILE);
        }

        return ret;
    }

    private static List<String> getMaterialHeaders(String line) throws InternalException {
        if (isEmptyLine(line)) {
            throw new InternalException("The first row of the header could not be empty!");
        }

        return generateHeaders(Arrays.asList(removeUtf8BOM(line).split(COMMA_DELIMITER)));
    }

    private static void validateHeader(List<String> header, List<String> requiredSymbol) throws InternalException {
        Set<String> missingSymbols = new HashSet<>();
        for (String symbol : requiredSymbol) {
            if (!header.contains(symbol)) {
                missingSymbols.add(symbol);
            }
        }

        if (!missingSymbols.isEmpty()) {
            throw new InternalException(String.format("The information of %s are required from the input file", missingSymbols));
        }
    }

    private static String[] getMaterialDataFromLine(String line) {
        if (isEmptyLine(line)) {
            return new String[0];
        }
        String[] values = removeUtf8BOM(line).split(COMMA_DELIMITER);
        // first item is required for the label
        return StringUtils.hasText(values[0].trim()) ? values : new String[0];
    }

    private static Double parseCompositionValue(String strValue) {
        try {
            return StringUtils.hasText(strValue) ? Double.parseDouble(strValue.trim()) : 0.0;
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
    }

    /**
     * Check if the input line is empty
     */
    private static boolean isEmptyLine(String line) {
        // blank line
        if (!StringUtils.hasText(line)) {
            return true;
        }

        // check if line only contains the delimiter (all values is empty)
        String pattern = line.replace(COMMA_DELIMITER, "");
        return "".equals(pattern.trim());
    }

    /**
     * Convert the string in 'camel Case' to 'under_score'
     *
     * @param headers
     * @return
     */
    private static List<String> generateHeaders(List<String> headers) {
        List<String> ret = new ArrayList<>();
        for (String h : headers) {
            String headerAttr = h.trim().replaceAll("\\s+", "_").toLowerCase();
            if (VALID_LABEL_HEADER.contains(headerAttr)) {
                // use "label" as the header in common to make data consistency
                ret.add("label");
            } else {
                ret.add(headerAttr);
            }
        }

        return ret;
    }

    private static String removeUtf8BOM(String line) {
        // remove UTF-8 BOM
        if (line.startsWith(UTF8_BOM)) {
            line = line.substring(1);
        }

        return line;
    }
}
