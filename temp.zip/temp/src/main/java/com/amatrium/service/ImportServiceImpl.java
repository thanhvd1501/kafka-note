package com.amatrium.service;

import com.amatrium.cache.ProcessingTaskManager;
import com.amatrium.constant.I18nConstant;
import com.amatrium.domaintype.NotificationType;
import com.amatrium.domaintype.Severity;
import com.amatrium.domaintype.StateType;
import com.amatrium.dto.ExportDataResponseDto;
import com.amatrium.dto.NotificationDto;
import com.amatrium.entity.Category;
import com.amatrium.entity.Composition;
import com.amatrium.entity.ManufacturingRecord;
import com.amatrium.entity.Property;
import com.amatrium.exception.InternalException;
import com.amatrium.notification.sse.SseChannel;
import com.amatrium.notification.sse.SseEvent;
import com.amatrium.notification.sse.SseManager;
import com.amatrium.repository.CategoryRepository;
import com.amatrium.repository.ManufacturingRecordRepository;
import com.amatrium.repository.predicate.ManufacturingRecordPredicate;
import com.amatrium.util.CsvReader;
import com.amatrium.util.SecurityUtil;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.task.DelegatingSecurityContextAsyncTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
public class ImportServiceImpl implements ImportService {

    @Autowired
    private DelegatingSecurityContextAsyncTaskExecutor executor;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private I18nMessageService i18nMessageService;

    @Autowired
    private CategoryRepository categoryRepo;

    @Autowired
    private ManufacturingRecordRepository manufacturingRecordRepo;

    @Autowired
    private ProcessingTaskManager processingTaskManager;

    @Autowired
    private SseManager sseManager;

    @Value("${amatrium.limitation.historical-record:7000}")
    private long historicalLimitation;

    @Override
    public void importManufacturingRecord(String categoryId, boolean isPartialImport, MultipartFile file) throws InternalException {
        if (file == null || !CsvReader.CSV_CONTENT_TYPE.equals(file.getContentType())) {
            throw new InternalException("The content type is incorrect. It should be " + CsvReader.CSV_CONTENT_TYPE);
        }

        Optional<Category> category = categoryRepo.findById(categoryId);
        if (category.isEmpty()) {
            log.error("Category was not found by id " + categoryId);
            throw new InternalException("Category is no longer available in the system");
        }

        if (processingTaskManager.isCategoryLocked(categoryId)) {
            throw new InternalException(String.format("Could not import data for category %s when it is being retrained/imported in the background", category.get().getName()));
        }

        // lock the category to avoid multiple import at the same time
        processingTaskManager.lockCategoryForImporting(categoryId);
        // executing import asynchronously
        try {
            final byte[] bytes = file.getBytes();
            executor.execute(() -> doImportManufacturingRecords(category.get(), isPartialImport, bytes));
        } catch (IOException e) {
            log.info("Failed to read the content of file", e);
            processingTaskManager.unlockCategory(categoryId, StateType.FAILED);
            throw new InternalException("Could not read the file");
        }
    }

    @Override
    public ExportDataResponseDto exportToCsv(String categoryId, String material) throws InternalException {
        if (!StringUtils.hasText(categoryId)) {
            throw new InternalException("Invalid category");
        }

        Optional<Category> categoryOpt = categoryRepo.findById(categoryId);
        if (categoryOpt.isEmpty()) {
            log.error("Category was not found by id " + categoryId);
            throw new InternalException("Category is no longer available in the system");
        }

        StringBuilder strBuilder = new StringBuilder();

        List<String> headers = new ArrayList<>();
        headers.add(CsvReader.VALID_LABEL_HEADER.get(0));
        Category category = categoryOpt.get();
        List<Composition> compositions = category.getCompositions();
        if (compositions != null) {
            for (Composition composition : category.getCompositions()) {
                headers.add(composition.getSymbol());
            }
        }

        if (category.getProcessing() != null) {
            for (Composition processing : category.getProcessing()) {
                headers.add(processing.getSymbol());
            }
        }

        if (category.getProperties() != null) {
            for (Property property : category.getProperties()) {
                headers.add(property.getLabel());
            }
        }

        // adding the headers
        strBuilder.append(StringUtils.collectionToDelimitedString(headers, CsvReader.COMMA_DELIMITER));
        strBuilder.append(System.lineSeparator());

        Predicate predicate = new ManufacturingRecordPredicate()
                .categoryId(categoryId)
                .materialName(material)
                .getCondition();
        List<ManufacturingRecord> records = manufacturingRecordRepo.find(predicate);

        for (ManufacturingRecord record : records) {
            Map<String, Object> attributes = record.getAttributes();
            if (attributes == null || attributes.isEmpty()) {
                continue;
            }

            for (int i = 0; i < headers.size(); i++) {
                String header = headers.get(i);
                if (attributes.containsKey(header)) {
                    strBuilder.append(attributes.get(header));
                } else {
                    strBuilder.append(" ");
                }

                if (i < (headers.size() - 1)) {
                    strBuilder.append(CsvReader.COMMA_DELIMITER);
                }
            }

            strBuilder.append(System.lineSeparator());
        }

        return ExportDataResponseDto.builder()
                .categoryName(category.getName())
                .data(strBuilder.toString().replaceFirst(CsvReader.VALID_LABEL_HEADER.get(0), CsvReader.VALID_LABEL_HEADER.get(1)))
                .build();
    }

    private void doImportManufacturingRecords(Category category,
                                              boolean isPartialImport,
                                              byte[] bytes) {
        log.info("Starting import manufacturing records of category " + category.getName());
        List<String> requiredSymbols = new ArrayList<>();
        List<Composition> compositions = category.getCompositions();
        if (compositions != null) {
            requiredSymbols.addAll(compositions.stream().map(Composition::getSymbol).toList());
        }

        // init the processing from predefined in category
        List<Composition> processing = category.getProcessing();
        if (processing != null) {
            requiredSymbols.addAll(processing.stream().map(Composition::getSymbol).toList());
        }

        Optional<String> userOpt = SecurityUtil.getCurrentUsername();
        String user = userOpt.isEmpty() ? "unknown" : userOpt.get();
        try {
            List<ManufacturingRecord> manufacturingRecordList = CsvReader.readManufacturingRecord(category.getId(), bytes, requiredSymbols);
            if (manufacturingRecordList.isEmpty()) {
                // send SSE message
                NotificationDto notificationDto = NotificationDto.builder()
                        .severity(Severity.ERROR.name())
                        .type(NotificationType.IMPORTING.name())
                        .message(i18nMessageService.translateMessage(I18nConstant.MSG_IMPORT_NO_DATA, List.of(category.getName())))
                        .build();
                // notify all users of the organization
                notificationService.createNotification(notificationDto);
                sseManager.broadcastEventInAsync(SseChannel.USERS, new SseEvent<>(List.of(user), notificationDto));
                return;
            }

            if (!isPartialImport) {
                log.info("Full-import mode is requested. Clean the old records of category " + category.getId());
                manufacturingRecordRepo.deleteAllByCategoryId(category.getId());
            }

            manufacturingRecordRepo.saveAll(manufacturingRecordList);

            // send SSE message
            NotificationDto notificationDto = NotificationDto.builder()
                    .severity(Severity.INFO.name())
                    .type(NotificationType.IMPORTING.name())
                    .message(i18nMessageService.translateMessage(I18nConstant.MSG_IMPORT_HISTORICAL_SUCCESS, List.of(category.getName(), user)))
                    .build();
            // notify all users of the organization
            notificationService.createOrganizationNotification(SecurityUtil.getUserOrganization(), notificationDto);
            sseManager.broadcastEventInAsync(SseChannel.ORGANIZATION, new SseEvent<>(SecurityUtil.getUserOrganization(), notificationDto));
            log.info(String.format("Import manufacturing records of category %s completed", category.getId()));

            processingTaskManager.unlockCategory(category.getId(), StateType.COMPLETED);

            Predicate categoryPredicate = new ManufacturingRecordPredicate().categoryId(category.getId()).getCondition();
            long totalRecords = manufacturingRecordRepo.count(categoryPredicate);
            if (totalRecords >= historicalLimitation) {
                NotificationDto warningDto = NotificationDto.builder()
                        .severity(Severity.INFO.name())
                        .type(NotificationType.IMPORTING.name())
                        .message(i18nMessageService.translateMessage(I18nConstant.MSG_DATA_REACHES_LIMIT, List.of(category.getName())))
                        .build();
                notificationService.createOrganizationNotification(SecurityUtil.getUserOrganization(), warningDto);
                sseManager.broadcastEventInAsync(SseChannel.ORGANIZATION, new SseEvent<>(SecurityUtil.getUserOrganization(), warningDto));
            }
        } catch (Exception e) {
            log.error("Failed to import manufacturing records", e);
            // send notification
            NotificationDto notificationDto = NotificationDto.builder()
                    .owner(user)
                    .severity(Severity.ERROR.name())
                    .type(NotificationType.IMPORTING.name())
                    .message(i18nMessageService.translateMessage(I18nConstant.MSG_IMPORT_HISTORICAL_FAILURE, List.of(e.getMessage())))
                    .build();

            // notify the user that tried to import
            notificationService.createNotification(notificationDto);
            sseManager.broadcastEventInAsync(SseChannel.USERS, new SseEvent<>(List.of(user), notificationDto));
            processingTaskManager.unlockCategory(category.getId(), StateType.FAILED);
        }
    }
}
