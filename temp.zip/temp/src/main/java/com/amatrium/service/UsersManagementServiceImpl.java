package com.amatrium.service;

import com.amatrium.cache.UserDataManager;
import com.amatrium.config.ApplicationConfig;
import com.amatrium.domaintype.UserRole;
import com.amatrium.dto.UserDto;
import com.amatrium.entity.Organization;
import com.amatrium.entity.User;
import com.amatrium.exception.InternalException;
import com.amatrium.mapper.UserMapper;
import com.amatrium.notification.Constants;
import com.amatrium.notification.MessengerService;
import com.amatrium.notification.message.EmailMessage;
import com.amatrium.pointcut.OrganizationClaimRequired;
import com.amatrium.repository.NotificationRepository;
import com.amatrium.repository.OrganizationRepository;
import com.amatrium.repository.UserRepository;
import com.amatrium.repository.predicate.UserPredicate;
import com.amatrium.util.RegexValidationUtil;
import com.amatrium.util.SecurityUtil;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
public class UsersManagementServiceImpl implements UsersManagementService {

    public final String COULD_NOT_FOUND_USER_IN_ORGZ_SERVER = "Could not found the user_id '%s' in the organization '%s'";

    public final String COULD_NOT_FOUND_USER_IN_ORGZ_CLIENT = "The user do not exist in your organization";

    @Autowired
    private ApplicationConfig applicationConfig;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private MessengerService emailService;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private I18nMessageService i18nMessageService;

    @Autowired
    private UserDataManager userDataManager;

    @Override
    @OrganizationClaimRequired
    public List<UserDto> getAllUsers() {
        String organization = SecurityUtil.getUserOrganization();
        Predicate condition = new UserPredicate()
                .organization(organization)
                .getCondition();
        List<User> users = userRepository.find(condition);

        String signedInUser = SecurityUtil.getCurrentUsername().isEmpty() ? null : SecurityUtil.getCurrentUsername().get();
        List<UserDto> ret = new ArrayList<>();
        for (User user : users) {
            if (user.getEmail().equals(signedInUser)) {
                // always return the signed in user at the beginning of list
                ret.add(0, userMapper.toDto(user));
            } else {
                ret.add(userMapper.toDto(user));
            }
        }

        return ret;
    }

    @Override
    @OrganizationClaimRequired
    public UserDto getUserDetails(String userId) throws InternalException {
        String organizationId = SecurityUtil.getUserOrganization();
        Predicate condition = new UserPredicate()
                .id(List.of(userId))
                .organization(organizationId)
                .getCondition();
        List<User> users = userRepository.find(condition);

        if (users.isEmpty()) {
            log.error(String.format(COULD_NOT_FOUND_USER_IN_ORGZ_SERVER, userId, organizationId));
            throw new InternalException(COULD_NOT_FOUND_USER_IN_ORGZ_CLIENT);
        }
        User user = users.get(0);
        UserDto ret = userMapper.toDto(user);

        if (StringUtils.hasText(user.getOrganization())) {
            Optional<Organization> organization = organizationRepository.findById(user.getOrganization());
            organization.ifPresent(value -> ret.setOrganizationName(value.getName()));
        }

        return ret;
    }

    @Override
    public UserDto createNewUser(UserDto userInfo) throws InternalException {
        // 1. Validate the input
        if (userInfo == null) {
            throw new InternalException("Invalid user info");
        }

        if (!RegexValidationUtil.verifyEmail(userInfo.getEmail())) {
            throw new InternalException("The format of your email seems to be incorrect");
        }

        try {
            UserRole userRole = UserRole.valueOf(userInfo.getRole());
            if (userRole == UserRole.SUPER_ADMIN) {
                throw new InternalException("The input role was not allowed");
            }
        } catch (Exception e) {
            throw new InternalException(String.format("User role '%s' is invalid", userInfo.getRole()));
        }

        if (ObjectUtils.isEmpty(userInfo.getName().trim())) {
            throw new InternalException("Name is required");
        }

        List<UserRole> userRoles = SecurityUtil.getAuthorities();
        String organizationId;
        if (userRoles.contains(UserRole.SUPER_ADMIN)) {
            // only super admin can assign user to a specific organization
            organizationId = userInfo.getOrganization();
        } else {
            // other admin can create user in their organization
            organizationId = SecurityUtil.getUserOrganization();
        }

        if (ObjectUtils.isEmpty(organizationId)) {
            throw new InternalException("User must belong to an organization");
        }

        Optional<Organization> organization = organizationRepository.findById(organizationId);
        if (organization.isEmpty()) {
            throw new InternalException("Your organization is no longer available");
        }

        // Check if the email is already exists in system
        Predicate userPredicate = new UserPredicate()
                .email(userInfo.getEmail())
                .getCondition();
        List<User> listUser = userRepository.find(userPredicate);

        if (listUser == null || listUser.isEmpty()) {
            // 2. Save the user
            String temporaryPassword = SecurityUtil.generateRandomPassword();
            User user = User.builder()
                    .name(userInfo.getName().trim())
                    .email(userInfo.getEmail().trim())
                    .role(userInfo.getRole().trim())
                    .organization(organizationId)
                    .password(passwordEncoder.encode(temporaryPassword.trim()))
                    .build();
            User savedUser = userRepository.save(user);

            // send an invitation email to the new user
            sendInviteEmail(savedUser, temporaryPassword);

            return userMapper.toDto(savedUser);
        } else {
            throw new InternalException(String.format("The email '%s' is already exists", userInfo.getEmail()));
        }
    }

    @Override
    @OrganizationClaimRequired
    public boolean deleteUser(String userId) throws InternalException {
        String organizationId = SecurityUtil.getUserOrganization();
        Predicate condition = new UserPredicate()
                .id(List.of(userId))
                .organization(organizationId)
                .getCondition();
        List<User> users = userRepository.find(condition);

        if (users.isEmpty()) {
            log.error(String.format(COULD_NOT_FOUND_USER_IN_ORGZ_SERVER, userId, organizationId));
            throw new InternalException(COULD_NOT_FOUND_USER_IN_ORGZ_CLIENT);
        }

        userRepository.delete(users.get(0));

        //mark access expired
        userDataManager.markAccessExpired(users.get(0).getEmail(), System.currentTimeMillis());

        return true;
    }

    @Override
    public boolean changePassword(String userId, String oldPassword, String newPassword) throws InternalException {
        if (newPassword == null || newPassword.isEmpty()) {
            throw new InternalException("Invalid new password");
        }

        if (!RegexValidationUtil.isValidPassword(newPassword)) {
            throw new InternalException("Password must be minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character in #?!@$%^&*");
        }

        //get user from Repository
        String organizationId = SecurityUtil.getUserOrganization();
        Predicate condition = new UserPredicate()
                .id(List.of(userId))
                .organization(organizationId)
                .getCondition();
        List<User> users = userRepository.find(condition);

        Optional<String> currentUser = SecurityUtil.getCurrentUsername();
        if (users.isEmpty()) {
            log.error(String.format(COULD_NOT_FOUND_USER_IN_ORGZ_SERVER, userId, organizationId));
            throw new InternalException(COULD_NOT_FOUND_USER_IN_ORGZ_CLIENT);
        }

        User user = users.get(0);
        if (currentUser.isEmpty() || !currentUser.get().equals(user.getEmail())) {
            throw new InternalException("Could not allow to change the password of another user");
        }

        //Verify old/new pwd from client
        if (passwordEncoder.matches(oldPassword, user.getPassword())) {
            user.setPassword(passwordEncoder.encode(newPassword));
            User savedUser = userRepository.save(user);

            // send an email user when change password
            sendPasswordChangeNotification(savedUser);

            return true;
        } else {
            throw new InternalException("The old password is incorrect");
        }
    }

    @Override
    @OrganizationClaimRequired
    public boolean updateUserRole(String userId, String role) throws InternalException {
        if (!StringUtils.hasText(userId) || !StringUtils.hasText(role)) {
            throw new InternalException("Invalid input");
        }

        String organizationId = SecurityUtil.getUserOrganization();
        Predicate condition = new UserPredicate()
                .id(List.of(userId))
                .organization(organizationId)
                .getCondition();
        List<User> users = userRepository.find(condition);

        if (users.isEmpty()) {
            log.error(String.format(COULD_NOT_FOUND_USER_IN_ORGZ_SERVER, userId, organizationId));
            throw new InternalException(COULD_NOT_FOUND_USER_IN_ORGZ_CLIENT);
        }

        User user = users.get(0);
        if (SecurityUtil.getCurrentUsername().isPresent() && user.getEmail().equals(SecurityUtil.getCurrentUsername().get())) {
            throw new InternalException("Not allowed to update your own role");
        }

        user.setRole(role);
        userRepository.save(user);

        //mark access expired
        userDataManager.markAccessExpired(user.getEmail(), System.currentTimeMillis());
        return true;
    }

    @Override
    public List<String> getAllUserRole() {
        return UserRole.getUserRoles()
                .stream()
                .map(Enum::name)
                .toList();
    }

    private void sendInviteEmail(User user, String temporaryPassword) {
        Map<String, String> emailArgs = new HashMap<>();
        emailArgs.put(Constants.ARG_WEB_UI_ENDPOINT, applicationConfig.getWebEndpoint());
        emailArgs.put(Constants.ARG_USER_NAME, user.getName());
        emailArgs.put(Constants.ARG_USER_PWD, temporaryPassword);

        EmailMessage emailInfo = EmailMessage.builder()
                .template(Constants.TEMPLATE_EMAIL_INVITE_USER)
                .receiver(user.getEmail())
                .subject(i18nMessageService.translate("email.invitation.subject", Locale.getDefault(), List.of(user.getName())))
                .arguments(emailArgs)
                .build();
        emailService.sendMessageInAsync(emailInfo);
        log.info("Sent invitation email to " + user.getEmail());
    }

    private void sendPasswordChangeNotification(User user) {
        Map<String, String> emailArgs = new HashMap<>();
        emailArgs.put(Constants.ARG_WEB_UI_ENDPOINT, applicationConfig.getWebEndpoint());
        emailArgs.put(Constants.ARG_USER_NAME, user.getName());

        EmailMessage emailInfo = EmailMessage.builder()
                .template(Constants.TEMPLATE_EMAIL_PASSWORD_CHANGE)
                .receiver(user.getEmail())
                .subject(i18nMessageService.translate("email.password-change.subject"))
                .arguments(emailArgs)
                .build();

        emailService.sendMessageInAsync(emailInfo);
        log.info("Sent password change notification email to " + user.getEmail());
    }
}
