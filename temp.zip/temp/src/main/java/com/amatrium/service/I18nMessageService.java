package com.amatrium.service;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public interface I18nMessageService {

    /**
     * Get the messages in all the supported languages
     *
     * @param key  key of the message in properties file
     * @param args - list of the arguments
     * @return map from supported locale to translated message
     */
    Map<String, String> translateMessage(String key, List<String> args);

    /**
     * Translate the message
     *
     * @param key - key of the message in properties file
     * @return translated message
     */
    String translate(String key);

    /**
     * Translate the message
     *
     * @param key    - key of  the message in properties file
     * @param locale - locale from client
     * @return translated message
     */
    String translate(String key, Locale locale);

    /**
     * Translate the message
     *
     * @param key    - key of the message in properties file
     * @param locale - locale from client
     * @param params - list of the arguments
     * @return translated message
     */
    String translate(String key, Locale locale, List<String> params);

}
