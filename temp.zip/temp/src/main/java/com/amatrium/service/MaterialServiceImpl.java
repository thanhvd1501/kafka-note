package com.amatrium.service;

import com.amatrium.cache.ProcessingTaskManager;
import com.amatrium.constant.I18nConstant;
import com.amatrium.domaintype.NotificationType;
import com.amatrium.domaintype.Severity;
import com.amatrium.domaintype.StateType;
import com.amatrium.dto.MaterialDto;
import com.amatrium.dto.MutablePair;
import com.amatrium.dto.NotificationDto;
import com.amatrium.entity.Category;
import com.amatrium.entity.CategoryMaterial;
import com.amatrium.entity.Composition;
import com.amatrium.entity.Material;
import com.amatrium.entity.MaterialComposition;
import com.amatrium.entity.Organization;
import com.amatrium.exception.InternalException;
import com.amatrium.mapper.MaterialMapper;
import com.amatrium.notification.sse.SseChannel;
import com.amatrium.notification.sse.SseEvent;
import com.amatrium.notification.sse.SseManager;
import com.amatrium.repository.CategoryRepository;
import com.amatrium.repository.MaterialRepository;
import com.amatrium.repository.OrganizationRepository;
import com.amatrium.repository.predicate.MaterialPredicate;
import com.amatrium.util.CsvReader;
import com.amatrium.util.SecurityUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.task.DelegatingSecurityContextAsyncTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MaterialServiceImpl implements MaterialService {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private I18nMessageService i18nMessageService;

    @Autowired
    private MaterialMapper mapper;

    @Autowired
    private MaterialRepository materialRepo;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProcessingTaskManager processingTaskManager;

    @Autowired
    private DelegatingSecurityContextAsyncTaskExecutor executor;

    @Autowired
    private SseManager sseManager;

    @Override
    public MaterialDto getMaterialById(String materialId) throws InternalException {
        if (!StringUtils.hasText(materialId)) {
            throw new InternalException("Material ID must be not null/empty");
        }
        return mapper.toDto(
                materialRepo.findById(materialId)
                        .orElseThrow(() -> new InternalException("No material was found by id " + materialId)));
    }

    @Override
    public void importMaterials(String categoryId, boolean isPartialImport, MultipartFile multipartFile) throws InternalException {
        if (multipartFile == null || !CsvReader.CSV_CONTENT_TYPE.equals(multipartFile.getContentType())) {
            throw new InternalException("The content type is incorrect. It should be " + CsvReader.CSV_CONTENT_TYPE);
        }

        Optional<Category> categoryOpt = categoryRepository.findById(categoryId);
        if (categoryOpt.isEmpty()) {
            log.error("No category was found by id " + categoryId);
            throw new InternalException("Category is no longer available in the system");
        }

        Category category = categoryOpt.get();
        if ((category.getCompositions() == null || category.getCompositions().isEmpty()) &&
                (category.getProcessing() == null || category.getProcessing().isEmpty())) {
            String msg = String.format("The composition of category %s has not been defined", category.getName());
            throw new InternalException(msg);
        }

        if (processingTaskManager.isCategoryLocked(categoryId)) {
            throw new InternalException(String.format("Could not import material for category %s when it is being retrained/imported in the background", category.getName()));
        }

        // lock the category to avoid multiple import at the same time
        processingTaskManager.lockCategoryForImporting(categoryId);
        try {
            final byte[] bytes = multipartFile.getBytes();
            executor.execute(() -> executeImportMaterial(category, isPartialImport, bytes));
        } catch (IOException e) {
            log.info("Failed to read the content of file", e);
            processingTaskManager.unlockCategory(categoryId, StateType.FAILED);
            throw new InternalException("Could not read the file");
        }

    }

    private void executeImportMaterial(Category category,
                                       boolean isPartialImport,
                                       byte[] bytes) {
        Optional<String> userOpt = SecurityUtil.getCurrentUsername();
        String user = userOpt.isEmpty() ? "unknown" : userOpt.get();
        try {
            // 1. Pre-execution: Get the composition information
            // Retrieve the organization glossary
            Optional<Organization> organizationOpt = organizationRepository.findById(category.getOrganization());
            Map<String, String> glossary = organizationOpt.isPresent() ? organizationOpt.get().getGlossary() : Collections.emptyMap();

            List<String> compositionSymbols = new ArrayList<>();

            // init the composition from predefined in category
            Map<String, MaterialComposition> compositionMap = new LinkedHashMap<>();
            List<Composition> compositions = category.getCompositions();
            if (compositions != null) {
                compositionMap = compositions.stream().collect(Collectors.toMap(Composition::getSymbol, c -> {
                    String symbol = c.getSymbol();
                    compositionSymbols.add(symbol);
                    return MaterialComposition.builder()
                            .symbol(symbol)
                            .name(glossary.getOrDefault(symbol, symbol))
                            .min(0.0)
                            .max(0.0)
                            .unit(c.getUnit())
                            .build();
                }));
            }

            // init the processing from predefined in category
            Map<String, MaterialComposition> processingMap = new LinkedHashMap<>();
            List<Composition> processing = category.getProcessing();
            if (processing != null) {
                processingMap = processing.stream().collect(Collectors.toMap(Composition::getSymbol, p -> {
                    String symbol = p.getSymbol();
                    compositionSymbols.add(symbol);
                    return MaterialComposition.builder()
                            .symbol(symbol)
                            .name(glossary.getOrDefault(symbol, symbol))
                            .min(0.0)
                            .max(0.0)
                            .unit(p.getUnit())
                            .build();
                }));
            }

            // 2. Read the CSV
            // map from the label to a another map (from symbol to its pair(min, max))
            Map<String, Map<String, MutablePair<Double, Double>>> importedMaterial = CsvReader.readMaterialRecord(bytes, compositionSymbols);
            if (importedMaterial.isEmpty()) {
                log.info("No material was found from imported file");
            }

            // 3. Save the material
            List<Material> savingMaterials = new ArrayList<>();
            if (isPartialImport) {
                for (Map.Entry<String, Map<String, MutablePair<Double, Double>>> entry : importedMaterial.entrySet()) {
                    String label = entry.getKey();
                    Map<String, MutablePair<Double, Double>> importedCompositionMap = entry.getValue();

                    Material material = materialRepo.findByLabel(label);
                    if (material == null) {
                        material = Material.builder()
                                .categoryId(category.getId())
                                .compositions(createMaterialComposition(compositionMap, importedCompositionMap))
                                .processing(createMaterialComposition(processingMap, importedCompositionMap))
                                .label(label)
                                .build();
                    }
                    savingMaterials.add(material);
                }
            } else {
                log.info(String.format("Clear the old material data of category %s is requested", category.getName()));
                materialRepo.deleteAllByCategoryId(category.getId());

                for (Map.Entry<String, Map<String, MutablePair<Double, Double>>> entry : importedMaterial.entrySet()) {
                    String label = entry.getKey();
                    Map<String, MutablePair<Double, Double>> symbolRecord = entry.getValue();

                    Material material = Material.builder()
                            .categoryId(category.getId())
                            .label(label)
                            .compositions(createMaterialComposition(compositionMap, symbolRecord))
                            .processing(createMaterialComposition(processingMap, symbolRecord))
                            .build();
                    savingMaterials.add(material);
                }
            }
            materialRepo.saveAll(savingMaterials);

            // 4. Update material info in category
            List<Material> materials = materialRepo.find(new MaterialPredicate().category(category.getId()).getCondition());
            List<CategoryMaterial> categoryMaterials = materials.stream()
                    .map(m -> new CategoryMaterial(m.getId(), m.getLabel()))
                    .toList();
            category.setMaterials(categoryMaterials);
            categoryRepository.save(category);

            // 5. Send the notification
            // send SSE message
            NotificationDto notificationDto = NotificationDto.builder()
                    .severity(Severity.INFO.name())
                    .type(NotificationType.IMPORTING.name())
                    .message(i18nMessageService.translateMessage(
                            I18nConstant.MSG_IMPORT_MATERIAL_SUCCESS,
                            List.of(String.valueOf(savingMaterials.size()), category.getName(), user)))
                    .build();
            notificationService.createOrganizationNotification(SecurityUtil.getUserOrganization(), notificationDto);
            sseManager.broadcastEventInAsync(SseChannel.ORGANIZATION, new SseEvent<>(SecurityUtil.getUserOrganization(), notificationDto));
            log.info(savingMaterials.size() + " materials are imported successfully");

            processingTaskManager.unlockCategory(category.getId(), StateType.COMPLETED);
        } catch (InternalException e) {
            log.error("Failed to import the CSV file", e);
            // send notification
            NotificationDto notificationDto = NotificationDto.builder()
                    .severity(Severity.ERROR.name())
                    .type(NotificationType.IMPORTING.name())
                    .message(i18nMessageService.translateMessage(
                            I18nConstant.MSG_IMPORT_MATERIAL_FAILURE,
                            List.of(category.getName(), e.getMessage())))
                    .build();

            // notify the user that tried to import
            notificationService.createNotification(notificationDto);
            sseManager.broadcastEventInAsync(SseChannel.USERS, new SseEvent<>(List.of(user), notificationDto));

            processingTaskManager.unlockCategory(category.getId(), StateType.FAILED);
        }
    }

    /**
     * @param predefinedInfo The information of composition that predefined in the category (map from symbol to details info)
     * @param importedData   The imported data from client (map from symbol to details info)
     * @return List of material composition
     */
    private List<MaterialComposition> createMaterialComposition(Map<String, MaterialComposition> predefinedInfo,
                                                                Map<String, MutablePair<Double, Double>> importedData) {
        List<MaterialComposition> ret = new ArrayList<>();

        for (Map.Entry<String, MaterialComposition> compositionEntry : predefinedInfo.entrySet()) {
            String symbol = compositionEntry.getKey();
            if (importedData.containsKey(symbol)) {
                MaterialComposition composition = new MaterialComposition(compositionEntry.getValue());
                MutablePair<Double, Double> minMaxValue = importedData.get(symbol);
                composition.setMin(minMaxValue.getFirst());
                composition.setMax(minMaxValue.getSecond());

                ret.add(composition);
            }
        }

        return ret;
    }
}
