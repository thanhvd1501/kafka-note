package com.amatrium.service;

import com.amatrium.dto.OrganizationDto;
import com.amatrium.entity.Organization;
import com.amatrium.mapper.OrganizationMapper;
import com.amatrium.repository.OrganizationRepository;
import com.amatrium.repository.predicate.OrganizationPredicate;
import com.querydsl.core.types.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrganizationServiceImpl implements OrganizationService {

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private OrganizationMapper organizationMapper;

    @Override
    public List<OrganizationDto> findAll() {
        List<Organization> organizations = organizationRepository.findAll();

        return organizationMapper.toDtoList(organizations);
    }

    @Override
    public List<OrganizationDto> findOrganization(String name) {
        Predicate predicate = new OrganizationPredicate()
                .name(name)
                .getCondition();

        List<Organization> organizations = organizationRepository.find(predicate);
        return organizationMapper.toDtoList(organizations);
    }
}
