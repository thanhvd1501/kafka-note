package com.amatrium.service;

import com.amatrium.config.AsyncTaskConfig;
import com.amatrium.dto.NotificationDto;
import com.amatrium.dto.NotificationListDto;
import org.springframework.scheduling.annotation.Async;

import java.util.Date;

public interface NotificationService {

    @Async(AsyncTaskConfig.BEAN_ASYNC_EXECUTOR)
    void createOrganizationNotification(String organization, NotificationDto notification);

    @Async(AsyncTaskConfig.BEAN_ASYNC_EXECUTOR)
    void createNotification(NotificationDto notification);

    NotificationListDto getUserNotification(Boolean isRead);

    boolean deleteNotification(String user, Boolean isRead, Date beforeDate);

    /**
     * mark of notification of the logged in user as read
     */
    void markAllAsRead();
}