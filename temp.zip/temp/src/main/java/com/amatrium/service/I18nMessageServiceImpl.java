package com.amatrium.service;

import com.amatrium.domaintype.SupportedLocale;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
@Slf4j
public class I18nMessageServiceImpl implements I18nMessageService {

    @Autowired
    private MessageSource messageSource;

    @Override
    public Map<String, String> translateMessage(String key, List<String> args) {
        if (!StringUtils.hasText(key)) {
            return Collections.emptyMap();
        }

        Map<String, String> ret = new HashMap<>();
        for (SupportedLocale locale : SupportedLocale.values()) {
            ret.put(locale.getCode(), getMessage(key, locale.getLocale(), args));
        }

        return ret;
    }

    @Override
    public String translate(String key) {
        return getMessage(key, null, null);
    }

    @Override
    public String translate(String key, Locale locale) {
        return getMessage(key, locale, null);
    }

    @Override
    public String translate(String key, Locale locale, List<String> args) {
        return getMessage(key, locale, args);
    }

    private String getMessage(String key, Locale locale, List<String> args) {
        Object[] objArgs = (args == null || args.isEmpty()) ? null : args.toArray(new Object[0]);

        try {
            return messageSource.getMessage(key, objArgs, key, locale == null ? Locale.getDefault() : locale);
        } catch (NoSuchMessageException ex) {
            log.error("Could not found any translation of " + key);
            return key;
        }
    }

}
