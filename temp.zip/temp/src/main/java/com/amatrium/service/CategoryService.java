package com.amatrium.service;

import com.amatrium.domaintype.PredictionType;
import com.amatrium.dto.CategoryDto;
import com.amatrium.exception.InternalException;
import org.bson.json.JsonObject;

import java.util.List;

public interface CategoryService {

    /**
     * @param text
     * @return list of all categories by pagination
     */

    List<CategoryDto> search(String text) throws InternalException;

    /**
     * Initialize a new request to allow user can start retrain the model
     *
     * @param categoryId
     * @return a secret key
     * @throws InternalException if could not allowed to retrain model
     */
    String requestTrainingModel(String categoryId) throws InternalException;

    /**
     * Check if secret of the training-model request is valid. If so, change the state to IN PROGRESS
     *
     * @param category
     * @param secret
     * @return
     * @throws InternalException if the secret key is invalid
     */
    boolean startTrainingModel(String category, String secret) throws InternalException;

    /**
     * @param categoryId
     * @param isSuccess
     * @throws InternalException
     */
    void completeTrainingModel(String categoryId, boolean isSuccess) throws InternalException;

    /**
     *
     * @param type
     * @param request
     * @return
     * @throws InternalException
     */
    Object predict(PredictionType type, Object request) throws InternalException;
}
