package com.amatrium.service;

import com.amatrium.dto.OrganizationDto;

import java.util.List;

public interface OrganizationService {

    /**
     * Find all
     * @return
     */
    List<OrganizationDto> findAll();

    /**
     * Find the organization by name
     * @param name
     * @return
     */
    List<OrganizationDto> findOrganization(String name);
}
