package com.amatrium.service;

import com.amatrium.dto.MaterialDto;
import com.amatrium.exception.InternalException;
import org.springframework.web.multipart.MultipartFile;

public interface MaterialService {
    /**
     * Find the material by id
     *
     * @param materialId
     * @return MaterialDto
     */
    MaterialDto getMaterialById(String materialId) throws InternalException;

    /**
     * import the material csv
     *
     * @param categoryId
     * @param isPartialImport
     * @param file
     */
    void importMaterials(String categoryId, boolean isPartialImport, MultipartFile file) throws InternalException;
}
