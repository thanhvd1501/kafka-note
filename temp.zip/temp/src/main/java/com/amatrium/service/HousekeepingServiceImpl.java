package com.amatrium.service;

import com.amatrium.cache.UserDataManager;
import com.amatrium.config.ApplicationConfig;
import com.amatrium.config.JwtConfig;
import com.amatrium.constant.I18nConstant;
import com.amatrium.domaintype.Severity;
import com.amatrium.domaintype.StateType;
import com.amatrium.dto.NotificationDto;
import com.amatrium.entity.Category;
import com.amatrium.entity.FunctionState;
import com.amatrium.notification.sse.SseChannel;
import com.amatrium.notification.sse.SseEvent;
import com.amatrium.notification.sse.SseManager;
import com.amatrium.repository.CategoryRepository;
import com.amatrium.repository.FunctionStateRepository;
import com.amatrium.repository.predicate.FunctionStatePredicate;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class HousekeepingServiceImpl implements HousekeepingService {

    @Autowired
    private ApplicationConfig applicationConfig;

    @Autowired
    private UserDataManager userDataManager;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private FunctionStateRepository functionStateRepository;

    @Autowired
    private SseManager sseManager;

    @Autowired
    private I18nMessageService i18nMessageService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private JwtConfig jwtConfig;

    /**
     *
     */
    @Override
    public void cleanUserSecretCode() {
        long currentTime = System.currentTimeMillis();
        int resetPwdCodeLifespan = applicationConfig.getSecretCodeLifespan();

        // clean the expiration reset password code after "resetPwdCodeLifespan" minutes
        long expirationTime = currentTime - resetPwdCodeLifespan * 60 * 1000L;
        userDataManager.clean(null, expirationTime);
    }

    @Override
    public void cleanNotification(Date beforeDate) {
        // delete all old notification
        notificationService.deleteNotification(null, null, beforeDate);
    }

    /**
     * set fail for all progress reach time out
     */
    @Override
    public void markFunctionStateTimeout(Date beforeDate) {
        Predicate predicate = new FunctionStatePredicate()
                .beforeDate(beforeDate)
                .stateIn(List.of(StateType.NEW, StateType.IN_PROGRESS))
                .getCondition();
        List<FunctionState> functionStateList = functionStateRepository.find(predicate);

        if (functionStateList.isEmpty()) {
            return;
        }
        for (FunctionState functionState : functionStateList) {
            functionState.setState(StateType.FAILED.name());

            // notify all users of the organization
            Optional<Category> categoryOpt = categoryRepository.findById(functionState.getCategoryId());
            if (categoryOpt.isEmpty()) {
                log.info(String.format("The Category %s is not found", functionState.getCategoryId()));
                continue;
            }
            String organization = categoryOpt.get().getOrganization();

            // send SSE message
            NotificationDto notificationDto = NotificationDto.builder()
                    .severity(Severity.ERROR.name())
                    .type(functionState.getType())
                    .message(i18nMessageService.translateMessage(
                            I18nConstant.MSG_FUNCTION_STATE_TIME_OUT, List.of(functionState.getType(), categoryOpt.get().getName())))
                    .build();
            notificationService.createOrganizationNotification(organization, notificationDto);
            sseManager.broadcastEventInAsync(SseChannel.ORGANIZATION, new SseEvent<>(organization, notificationDto));
            log.info(String.format("Progress %s reached time out", functionState.getCategoryId()));
        }

        functionStateRepository.saveAll(functionStateList);
    }

    /**
     * clean the expired records
     */
    @Override
    public void cleanFunctionState(Date beforeDate) {
        Predicate predicate = new FunctionStatePredicate()
                .beforeDate(beforeDate)
                .getCondition();
        List<FunctionState> functionStateList = functionStateRepository.find(predicate);

        if (functionStateList.isEmpty()) {
            return;
        }
        functionStateRepository.deleteAll(functionStateList);
    }

    @Override
    public void cleanExpirationCache() {
        long beforeTime = System.currentTimeMillis() - jwtConfig.getAccessTokenLifespan() * 60 * 1000L;
        userDataManager.cleanExpirationCache(beforeTime);
    }
}
