package com.amatrium.service;

import com.amatrium.dto.UserDto;
import com.amatrium.exception.InternalException;

import java.util.List;

/**
 * @author Anh Hoang
 */
public interface UsersManagementService {

    List<UserDto> getAllUsers();

    UserDto getUserDetails(String userId) throws InternalException;

    List<String> getAllUserRole();

    UserDto createNewUser(UserDto userInfo) throws InternalException;

    boolean deleteUser(String userId) throws InternalException;

    boolean changePassword(String userId, String oldPassword, String newPassword) throws InternalException;

    boolean updateUserRole(String userId, String role) throws InternalException;
}
