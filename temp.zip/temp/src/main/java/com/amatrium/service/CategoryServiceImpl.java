package com.amatrium.service;

import com.amatrium.cache.ProcessingTaskManager;
import com.amatrium.cache.UserDataManager;
import com.amatrium.config.ApplicationConfig;
import com.amatrium.constant.I18nConstant;
import com.amatrium.domaintype.FunctionType;
import com.amatrium.domaintype.NotificationType;
import com.amatrium.domaintype.PredictionType;
import com.amatrium.domaintype.Severity;
import com.amatrium.domaintype.StateType;
import com.amatrium.dto.CategoryDto;
import com.amatrium.dto.NotificationDto;
import com.amatrium.entity.Category;
import com.amatrium.entity.FunctionState;
import com.amatrium.exception.InternalException;
import com.amatrium.mapper.CategoryMapper;
import com.amatrium.mapper.CompositionMapper;
import com.amatrium.mapper.PropertyMappper;
import com.amatrium.notification.sse.SseChannel;
import com.amatrium.notification.sse.SseEvent;
import com.amatrium.notification.sse.SseManager;
import com.amatrium.pointcut.OrganizationClaimRequired;
import com.amatrium.repository.CategoryRepository;
import com.amatrium.repository.FunctionStateRepository;
import com.amatrium.repository.ManufacturingRecordRepository;
import com.amatrium.repository.predicate.CategoryPredicate;
import com.amatrium.repository.predicate.FunctionStatePredicate;
import com.amatrium.repository.predicate.ManufacturingRecordPredicate;
import com.amatrium.util.SecurityUtil;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.bson.json.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;


@Service
@Slf4j
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private ApplicationConfig applicationConfig;

    @Autowired
    private SseManager sseManager;

    @Autowired
    private I18nMessageService i18nMessageService;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private ProcessingTaskManager processingTaskManager;

    @Autowired
    private UserDataManager userDataManager;

    @Autowired
    private CategoryRepository categoryRepo;

    @Autowired
    private ManufacturingRecordRepository manufacturingRecordRepository;

    @Autowired
    private FunctionStateRepository functionStateRepository;

    @Autowired
    private CategoryMapper categoryMapper;

    @Autowired
    private CompositionMapper compositionMapper;

    @Autowired
    private PropertyMappper propertyMappper;

    @Override
    @OrganizationClaimRequired
    public List<CategoryDto> search(String text) {
        String organization = SecurityUtil.getUserOrganization();
        Predicate predicate = new CategoryPredicate()
                .text(text)
                .organization(organization)
                .getCondition();
        List<Category> listCategory = categoryRepo.find(predicate);

        return categoryMapper.toDtoList(listCategory);
    }

    @Override
    public String requestTrainingModel(String categoryId) throws InternalException {
        // Verify input
        Optional<Category> categoryOpt = categoryRepo.findById(categoryId);
        if (categoryOpt.isEmpty() || !categoryOpt.get().getOrganization().equals(SecurityUtil.getUserOrganization())) {
            throw new InternalException("The category is no longer available");
        }
        Category category = categoryOpt.get();

        Optional<String> loggedInUser = SecurityUtil.getCurrentUsername();
        if (loggedInUser.isEmpty()) {
            throw new InternalException("User is unknown");
        }

        // Check if any progress related to category is running
        if (processingTaskManager.isCategoryLocked(categoryId)) {
            throw new InternalException(String.format("Could not retrain the model for category %s when it is being retrained/imported in the background", category.getName()));
        }

        ManufacturingRecordPredicate predicate = new ManufacturingRecordPredicate().categoryId(categoryId);
        long numberOfHistoricalData = manufacturingRecordRepository.count(predicate.getCondition());
        if (numberOfHistoricalData <= 0) {
            throw new InternalException(String.format("The historical data of category %s must be imported before retraining", category.getName()));
        }

        // lock the category to avoid multiple retrain at the same time for the same category
        processingTaskManager.lockCategoryForTrainingModel(categoryId);

        // send notification to all users of organization
        NotificationDto notificationDto;
        notificationDto = NotificationDto.builder()
                .severity(Severity.INFO.name())
                .type(NotificationType.MODEL_TRAINING.name())
                .message(i18nMessageService.translateMessage(I18nConstant.MSG_RETRAIN_START, List.of(loggedInUser.get(), category.getName())))
                .build();
        sseManager.broadcastEventInAsync(SseChannel.ORGANIZATION, new SseEvent<>(category.getOrganization(), notificationDto));
        notificationService.createOrganizationNotification(category.getOrganization(), notificationDto);

        // generate a secret key for the user
        return userDataManager.generateUserSecret(loggedInUser.get());
    }

    @Override
    public boolean startTrainingModel(String categoryId, String secret) throws InternalException {
        // verify input
        if (!StringUtils.hasText(categoryId) && !StringUtils.hasText(secret)) {
            throw new InternalException("Invalid category or secret");
        }

        Optional<Category> categoryOpt = categoryRepo.findById(categoryId);
        if (categoryOpt.isEmpty()) {
            throw new InternalException("The category is no longer available");
        }

        // Find the running progress related to category
        Predicate predicate = new FunctionStatePredicate()
                .categoryId(categoryId)
                .type(FunctionType.RETRAIN)
                .stateIn(List.of(StateType.NEW))
                .getCondition();
        List<FunctionState> processingFunctionState = functionStateRepository.find(predicate);
        if (processingFunctionState.isEmpty()) {
            throw new InternalException(String.format("The request to retrain model for category %s seems to be expired", categoryOpt.get().getName()));
        }

        // Verify the secret
        FunctionState functionState = processingFunctionState.get(0);
        boolean isValidSecret = userDataManager.verifyUserSecret(functionState.getCreatedBy(), secret);
        if (isValidSecret) {
            functionState.setState(StateType.IN_PROGRESS.name());
            functionStateRepository.save(functionState);
            return true;
        } else {
            throw new InternalException("Invalid secret");
        }
    }

    @Override
    public void completeTrainingModel(String categoryId, boolean isSuccess) throws InternalException {
        if (!StringUtils.hasText(categoryId)) {
            return;
        }

        Optional<Category> category = categoryRepo.findById(categoryId);
        if (category.isEmpty()) {
            throw new InternalException("No category was found by id " + categoryId);
        }

        // unlock the category and finish the progress
        processingTaskManager.unlockCategory(categoryId, isSuccess ? StateType.COMPLETED : StateType.FAILED);

        NotificationDto notificationDto;
        if (isSuccess) {
            log.info(String.format("Retrain process of category %s completed", category.get().getName()));
            notificationDto = NotificationDto.builder()
                    .severity(Severity.INFO.name())
                    .type(NotificationType.MODEL_TRAINING.name())
                    .message(i18nMessageService.translateMessage(I18nConstant.MSG_RETRAIN_SUCCESS, List.of(category.get().getName())))
                    .build();
        } else {
            log.error(String.format("Failed to retrain of category %s", category.get().getName()));
            notificationDto = NotificationDto.builder()
                    .severity(Severity.ERROR.name())
                    .type(NotificationType.MODEL_TRAINING.name())
                    .message(i18nMessageService.translateMessage(I18nConstant.MSG_RETRAIN_FAILURE, List.of(category.get().getName())))
                    .build();
        }

        sseManager.broadcastEventInAsync(SseChannel.ORGANIZATION, new SseEvent<>(category.get().getOrganization(), notificationDto));
        notificationService.createOrganizationNotification(category.get().getOrganization(), notificationDto);
    }

    @Override
    public Object predict(PredictionType type, Object request) throws InternalException {
        if (request == null) {
            throw new InternalException("The input could not be null");
        }

        String endpoint = null;
        if (PredictionType.DISTRIBUTION.equals(type)) {
            endpoint = applicationConfig.getDistributionPredictionEndpoint();
        } else if (PredictionType.PROPERTY.equals(type)) {
            endpoint = applicationConfig.getPropertyPredictionEndpoint();
        }

        if (!StringUtils.hasText(endpoint)) {
            throw new InternalException("The endpoint of prediction is not available");
        }

        WebClient webClient = WebClient.builder()
                .baseUrl(endpoint)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();

        Object predictionResult = webClient.post()
                .body(Mono.just(request), Object.class)
                .retrieve()
                .bodyToMono(Object.class)
                .doOnError(t -> log.error("Failed to predict: " + t.getMessage()))
                .onErrorReturn(new InternalException("Prediction process has been failed"))
                .block();

        if (predictionResult instanceof InternalException) {
            throw (InternalException) predictionResult;
        } else {
            return predictionResult;
        }
    }
}
