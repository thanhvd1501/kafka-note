package com.amatrium.service;

import com.amatrium.dto.ExportDataResponseDto;
import com.amatrium.exception.InternalException;
import org.springframework.web.multipart.MultipartFile;

public interface ImportService {
    /**
     * Import the manufacturing records of a certain category
     *
     * @param categoryId
     * @param isPartialImport
     * @param file
     * @return
     * @throws InternalException
     */
    void importManufacturingRecord(String categoryId, boolean isPartialImport, MultipartFile file) throws InternalException;

    /**
     *
     * @param categoryId
     * @return
     */
    ExportDataResponseDto exportToCsv(String categoryId, String material) throws InternalException;
}
