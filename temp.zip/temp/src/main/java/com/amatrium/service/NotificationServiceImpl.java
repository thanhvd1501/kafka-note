package com.amatrium.service;

import com.amatrium.dto.NotificationDto;
import com.amatrium.dto.NotificationListDto;
import com.amatrium.entity.Notification;
import com.amatrium.entity.User;
import com.amatrium.mapper.NotificationMapper;
import com.amatrium.repository.NotificationRepository;
import com.amatrium.repository.UserRepository;
import com.amatrium.repository.predicate.NotificationPredicate;
import com.amatrium.repository.predicate.UserPredicate;
import com.amatrium.util.SecurityUtil;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private NotificationMapper notificationMapper;

    @Override
    public void createOrganizationNotification(String organizationId, NotificationDto notification) {
        if (!StringUtils.hasText(organizationId) || notification == null) {
            log.error("Invalid input");
            return;
        }

        UserPredicate userPredicate = new UserPredicate().organization(organizationId);
        List<User> users = userRepository.find(userPredicate.getCondition());
        if (users.isEmpty()) {
            log.error("No user was found in organization " + organizationId);
            return;
        }

        List<Notification> notifications = new ArrayList<>();
        for (User user : users) {
            Notification userNotification = Notification.builder()
                    .owner(user.getEmail())
                    .severity(notification.getSeverity())
                    .type(notification.getType())
                    .message(notification.getMessage())
                    .isRead(false)
                    .build();
            notifications.add(userNotification);
        }

        notificationRepository.saveAll(notifications);
    }

    @Override
    public void createNotification(NotificationDto notificationInfo) {
        String owner = notificationInfo.getOwner();
        if (StringUtils.hasText(owner)) {
            // Save the Notification
            Notification notification = Notification.builder()
                    .type(notificationInfo.getType().trim())
                    .severity(notificationInfo.getSeverity().trim())
                    .message(notificationInfo.getMessage())
                    .owner(owner.trim())
                    .isRead(false)
                    .build();

            notificationRepository.save(notification);
        }
    }

    @Override
    public NotificationListDto getUserNotification(Boolean isRead) {
        NotificationListDto ret = NotificationListDto.builder()
                .data(new ArrayList<>())
                .build();

        Optional<String> currentUser = SecurityUtil.getCurrentUsername();
        if (currentUser.isEmpty()) {
            return ret;
        }

        Predicate condition = new NotificationPredicate()
                .owner(currentUser.get())
                .isRead(isRead)
                .getCondition();

        Page<Notification> userNotiList = notificationRepository.
                findAll(condition, PageRequest.of(0, 50, Sort.by(Sort.Direction.DESC, "createdDate")));
        int numOfUnread = 0;
        for (Notification notification : userNotiList) {
            ret.getData().add(notificationMapper.toDto(notification));
            if (notification.getIsRead() == null || !notification.getIsRead()) {
                numOfUnread += 1;
            }
        }
        ret.setNumOfUnread(numOfUnread);

        return ret;
    }

    @Override
    public boolean deleteNotification(String userId, Boolean isRead, Date beforeDate) {
        Predicate condition = new NotificationPredicate()
                .isRead(isRead)
                .beforeDate(beforeDate)
                .getCondition();

        List<Notification> notifications = notificationRepository.find(condition);

        if (notifications == null || notifications.isEmpty()) {
            log.error(String.format("Could not found the id '%s'", userId));
            return false;
        }

        notificationRepository.deleteAll(notifications);
        return true;
    }

    @Override
    public void markAllAsRead() {
        Optional<String> currentUser = SecurityUtil.getCurrentUsername();
        if (currentUser.isEmpty()) {
            return;
        }

        Predicate condition = new NotificationPredicate()
                .isRead(false)
                .owner(currentUser.get())
                .getCondition();
        List<Notification> notifications = notificationRepository.find(condition);
        for (Notification n : notifications) {
            n.setIsRead(true);
        }

        notificationRepository.saveAll(notifications);
    }
}