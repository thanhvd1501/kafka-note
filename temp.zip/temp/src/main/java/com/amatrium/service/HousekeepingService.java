package com.amatrium.service;

import lombok.NonNull;

import java.util.Date;

public interface HousekeepingService {

    /**
     * clean the expired code when user send the request for reset password
     */
    void cleanUserSecretCode();

    /**
     * Clean the notification of all users that were created from a period of days ago
     */
    void cleanNotification(@NonNull Date beforeDate);

    /**
     * set fail for all progress reach time out
     */
    void markFunctionStateTimeout(@NonNull Date beforeDate);

    /**
     * clean the expired records
     */
    void cleanFunctionState(@NonNull Date beforeDate);

    /**
     * clean the expiration cache
     */
    void cleanExpirationCache();
}
