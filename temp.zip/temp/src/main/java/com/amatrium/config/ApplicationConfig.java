package com.amatrium.config;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.thymeleaf.templateresolver.ITemplateResolver;

/**
 * This configuration contains th project specific config and the bean provider
 */
@Configuration
@Getter
@Slf4j
public class ApplicationConfig {

    /**
     * Lifespan in minute
     */
    @Value("${amatrium.cache.user.secret-code-lifespan:30}")
    private int secretCodeLifespan;

    /**
     * Lifespan in minute
     */
    @Value("${amatrium.function-state.task.time-out:30}")
    private int functionStateTimeout;

    @Value("${amatrium.distribution-prediction-endpoint:}")
    public String distributionPredictionEndpoint;

    @Value("${amatrium.property-prediction-endpoint:}")
    public String propertyPredictionEndpoint;

    @Value("${amatrium.web-endpoint:}")
    public String webEndpoint;

    /**
     * Lifespan in day
     */
    @Value("${amatrium.cache.user.notification-lifespan:30}")
    private int notificationLifespan;

    /**
     * Lifespan in day
     */
    @Value("${amatrium.function-state.task.lifespan:7}")
    private int functionStateLifespan;

    @Autowired
    private MessageSource messageSource;

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    public MongoTemplate mongoTemplate(MongoDatabaseFactory databaseFactory) {
        MongoTemplate mongoTemplate = new MongoTemplate(databaseFactory);
        MappingMongoConverter converter = (MappingMongoConverter) mongoTemplate.getConverter();
        converter.setTypeMapper(new DefaultMongoTypeMapper(null));
        return mongoTemplate;
    }

    @Bean
    public SpringTemplateEngine thymeleafTemplateEngine() {
        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
        templateEngine.setTemplateResolver(thymeleafTemplateResolver());
        templateEngine.setTemplateEngineMessageSource(messageSource);
        return templateEngine;
    }

    @Bean
    public ITemplateResolver thymeleafTemplateResolver() {
        ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
        templateResolver.setPrefix("templates/");
        templateResolver.setSuffix(".html");
        templateResolver.setTemplateMode("HTML");
        templateResolver.setCharacterEncoding("UTF-8");
        return templateResolver;
    }

}
