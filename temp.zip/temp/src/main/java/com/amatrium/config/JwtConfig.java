package com.amatrium.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class JwtConfig {

    @Value("${spring.security.properties.signing-key}")
    private String signingKey;

    /**
     * lifespan in minute
     */
    @Value("${spring.security.properties.access-token-lifespan:30}")
    private long accessTokenLifespan;

    /**
     * lifespan in minute
     */
    @Value("${spring.security.properties.refresh-token-lifespan:30}")
    private long refreshTokenLifespan;

}
