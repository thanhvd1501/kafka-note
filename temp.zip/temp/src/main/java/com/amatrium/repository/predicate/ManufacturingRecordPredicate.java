package com.amatrium.repository.predicate;

import com.amatrium.entity.QManufacturingRecord;
import com.querydsl.core.BooleanBuilder;
import lombok.Getter;
import org.springframework.util.StringUtils;

@Getter
public class ManufacturingRecordPredicate {

    private final BooleanBuilder condition = new BooleanBuilder();

    private static final QManufacturingRecord qManufacturingRecord = QManufacturingRecord.manufacturingRecord;

    /**
     * Find historical data by categoryId
     *
     * @param categoryId
     * @return
     */
    public ManufacturingRecordPredicate categoryId(String categoryId) {
        if (StringUtils.hasText(categoryId)) {
            condition.and(qManufacturingRecord.categoryId.eq(categoryId));
        }
        return this;
    }

    /**
     * Find historical data by material name
     *
     * @param name
     * @return
     */
    public ManufacturingRecordPredicate materialName(String name) {
        if (StringUtils.hasText(name)) {
            condition.and(qManufacturingRecord.name.eq(name));
        }

        return this;
    }
}
