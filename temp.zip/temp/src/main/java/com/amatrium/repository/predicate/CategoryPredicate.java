package com.amatrium.repository.predicate;

import com.amatrium.entity.QCategory;
import com.querydsl.core.BooleanBuilder;
import lombok.Getter;
import org.springframework.util.StringUtils;

@Getter
public class CategoryPredicate {

    private final BooleanBuilder condition = new BooleanBuilder();

    private static final QCategory qCategory = QCategory.category;

    /**
     * Add filter criteria by text
     *
     * @param text
     * @return
     */
    public CategoryPredicate text(String text) {
        if (StringUtils.hasText(text)) {
            String textPattern = "%" + text.trim().toLowerCase() + "%";
            condition.and(qCategory.name.likeIgnoreCase(textPattern));
        }

        return this;
    }

    /**
     * Add filter criteria by organization
     *
     * @param organization
     * @return
     */
    public CategoryPredicate organization(String organization) {
        if (organization != null) {
            condition.and(qCategory.organization.eq(organization));
        }

        return this;
    }
}
