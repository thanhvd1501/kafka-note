package com.amatrium.repository.predicate;

import com.amatrium.entity.QNotification;
import com.querydsl.core.BooleanBuilder;
import lombok.Getter;

import java.util.Date;

@Getter
public class NotificationPredicate {

    private final BooleanBuilder condition = new BooleanBuilder();

    private static final QNotification qNotification = QNotification.notification;

    public NotificationPredicate owner(String owner) {
        if (!owner.isEmpty()) {
            condition.and(qNotification.owner.in(owner));
        }

        return this;
    }

    public NotificationPredicate isRead(Boolean isRead) {
        if (isRead != null) {
            condition.and(qNotification.isRead.eq(isRead));
        }

        return this;
    }

    public NotificationPredicate beforeDate(Date beforeDate) {
        if (beforeDate != null) {
            condition.and(qNotification.createdDate.before(beforeDate));
        }

        return this;
    }
}