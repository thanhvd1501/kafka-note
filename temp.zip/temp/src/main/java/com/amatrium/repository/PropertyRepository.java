package com.amatrium.repository;

import com.amatrium.entity.Property;
import org.springframework.stereotype.Repository;

@Repository
public interface PropertyRepository extends BaseRepository<Property, String> {

    /**
     * Find property by label
     *
     * @param label
     * @return
     */
    Property findByLabel(String label);
}
