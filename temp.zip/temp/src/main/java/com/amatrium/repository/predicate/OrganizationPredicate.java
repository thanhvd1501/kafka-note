package com.amatrium.repository.predicate;

import com.amatrium.entity.QOrganization;
import com.querydsl.core.BooleanBuilder;
import lombok.Getter;
import lombok.NonNull;
import org.springframework.util.StringUtils;

import java.util.List;

@Getter
public class OrganizationPredicate {

    private final BooleanBuilder condition = new BooleanBuilder();
    private static final QOrganization qOrganization = QOrganization.organization;

    /**
     * Add filter criteria by id list
     *
     * @param ids
     * @return
     */
    public OrganizationPredicate ids(@NonNull List<String> ids) {
        if (!ids.isEmpty()) {
            condition.and(qOrganization.id.in(ids));
        }

        return this;
    }

    /**
     * Add filter criteria by name
     *
     * @param name
     * @return
     */
    public OrganizationPredicate name(@NonNull String name) {
        if (StringUtils.hasText(name)) {
            condition.and(qOrganization.name.eq(name));
        }

        return this;
    }

}
