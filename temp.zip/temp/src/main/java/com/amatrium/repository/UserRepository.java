package com.amatrium.repository;

import com.amatrium.entity.User;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends BaseRepository<User, String> {

    /**
     * Find user by email
     *
     * @param email
     * @return
     */
    User findByEmail(String email);
}
