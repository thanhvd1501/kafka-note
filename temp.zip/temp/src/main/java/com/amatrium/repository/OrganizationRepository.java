package com.amatrium.repository;

import com.amatrium.entity.Organization;
import org.springframework.stereotype.Repository;

@Repository
public interface OrganizationRepository extends BaseRepository<Organization, String> {
}