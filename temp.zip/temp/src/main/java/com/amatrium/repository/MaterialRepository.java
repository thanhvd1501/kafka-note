package com.amatrium.repository;

import com.amatrium.entity.Material;
import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.Query;

public interface MaterialRepository extends BaseRepository<Material, String> {

    @Query
    Material findByLabel(String label);

    @DeleteQuery
    void deleteAllByCategoryId(String categoryId);
}
