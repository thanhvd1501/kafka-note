package com.amatrium.repository;

import com.amatrium.entity.ManufacturingRecord;
import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.stereotype.Repository;

@Repository
public interface ManufacturingRecordRepository extends BaseRepository<ManufacturingRecord, String> {
    @DeleteQuery
    void deleteAllByCategoryId(String categoryId);
}
