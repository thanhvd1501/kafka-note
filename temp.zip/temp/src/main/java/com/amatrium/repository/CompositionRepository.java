package com.amatrium.repository;

import com.amatrium.entity.Composition;
import org.springframework.stereotype.Repository;

@Repository
public interface CompositionRepository extends BaseRepository<Composition, String> {
    /**
     * Find composition by symbol
     *
     * @param symbol
     * @return
     */
    Composition findBySymbol(String symbol);
}
