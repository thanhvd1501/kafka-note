package com.amatrium.repository.predicate;

import com.amatrium.domaintype.FunctionType;
import com.amatrium.domaintype.StateType;
import com.amatrium.entity.QFunctionState;
import com.querydsl.core.BooleanBuilder;
import lombok.Getter;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;

@Getter
public class FunctionStatePredicate {

    private final BooleanBuilder condition = new BooleanBuilder();

    private static final QFunctionState qFunctionState = QFunctionState.functionState;

    /**
     * Find FunctionState by categoryId
     *
     * @param categoryId
     * @return
     */
    public FunctionStatePredicate categoryId(String categoryId) {
        if (StringUtils.hasText(categoryId)) {
            condition.and(qFunctionState.categoryId.eq(categoryId));
        }
        return this;
    }

    /**
     * @param type
     * @return
     */
    public FunctionStatePredicate type(FunctionType type) {
        if (type != null) {
            condition.and(qFunctionState.type.eq(type.name()));
        }

        return this;
    }

    /**
     * Find FunctionState by state
     *
     * @param states
     * @return
     */
    public FunctionStatePredicate stateIn(List<StateType> states) {
        if (!states.isEmpty()) {
            condition.and(qFunctionState.state.in(states.stream().map(StateType::name).toList()));
        }

        return this;
    }

    /**
     * Find FunctionStates that has last updated at before input date
     *
     * @param date
     * @return
     */
    public FunctionStatePredicate beforeDate(Date date) {
        if (date != null) {
            condition.andAnyOf(
                    qFunctionState.lastModifiedDate.isNull(),
                    qFunctionState.lastModifiedDate.before(date));
        }
        return this;
    }
}
