package com.amatrium.repository;

import com.amatrium.entity.FunctionState;
import org.springframework.stereotype.Repository;

@Repository
public interface FunctionStateRepository extends BaseRepository<FunctionState, String> {
}


