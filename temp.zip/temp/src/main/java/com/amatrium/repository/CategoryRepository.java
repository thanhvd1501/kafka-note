package com.amatrium.repository;

import com.amatrium.entity.Category;

public interface CategoryRepository extends BaseRepository<Category, String> {
}
