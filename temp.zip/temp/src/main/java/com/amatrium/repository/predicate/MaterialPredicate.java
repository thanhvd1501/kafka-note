package com.amatrium.repository.predicate;

import com.amatrium.entity.QMaterial;
import com.querydsl.core.BooleanBuilder;
import lombok.Getter;
import org.springframework.util.StringUtils;

import java.util.Collection;

@Getter
public class MaterialPredicate {

    private final BooleanBuilder condition = new BooleanBuilder();

    private final QMaterial qMaterial = QMaterial.material;

    /**
     * Add filter criteria by category id
     *
     * @param categoryId
     * @return
     */
    public MaterialPredicate category(String categoryId) {
        if (StringUtils.hasText(categoryId)) {
            condition.and(qMaterial.categoryId.eq(categoryId));
        }

        return this;
    }

    /**
     * @param labels
     * @return
     */
    public MaterialPredicate labels(Collection<String> labels) {
        if (labels != null && !labels.isEmpty()) {
            condition.and(qMaterial.label.in(labels));
        }

        return this;
    }
}
