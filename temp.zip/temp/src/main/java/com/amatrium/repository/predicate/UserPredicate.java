package com.amatrium.repository.predicate;

import com.amatrium.entity.QUser;
import com.querydsl.core.BooleanBuilder;
import lombok.Getter;
import org.springframework.util.StringUtils;

import java.util.List;

@Getter
public class UserPredicate {

    private final BooleanBuilder condition = new BooleanBuilder();

    private static final QUser qUser = QUser.user;

    /**
     * Add filter criteria by id list
     *
     * @param ids
     * @return
     */
    public UserPredicate id(List<String> ids) {
        if (!ids.isEmpty()) {
            condition.and(qUser.id.in(ids));
        }

        return this;
    }

    /**
     * Add filter criteria by name
     *
     * @param name
     * @return
     */
    public UserPredicate name(String name) {
        if (StringUtils.hasText(name)) {
            String textPattern = "%" + name.trim().toLowerCase() + "%";
            condition.and(qUser.name.likeIgnoreCase(textPattern));
        }

        return this;
    }

    /**
     * Add filter criteria by email
     *
     * @param email
     * @return
     */
    public UserPredicate email(String email) {
        if (StringUtils.hasText(email)) {
            condition.and(qUser.email.eq(email));
        }

        return this;
    }

    /**
     * Filter by organization
     *
     * @param organization
     * @return
     */
    public UserPredicate organization(String organization) {
        if (StringUtils.hasText(organization)) {
            condition.and(qUser.organization.eq(organization));
        }

        return this;
    }

    /**
     * Add filter criteria by role
     *
     * @param role
     * @return
     */
    public UserPredicate role(String role) {
        if (StringUtils.hasText(role)) {
            condition.and(qUser.role.eq(role));
        }

        return this;
    }
}
