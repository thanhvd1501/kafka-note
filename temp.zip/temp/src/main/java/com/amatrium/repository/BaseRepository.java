package com.amatrium.repository;

import com.querydsl.core.types.Predicate;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.List;

/**
 * @param <E>  Entity type
 * @param <ID> The data type of the entity identifier
 */
@NoRepositoryBean
public interface BaseRepository<E, ID> extends MongoRepository<E, ID>, QuerydslPredicateExecutor<E> {

    default List<E> find(Predicate predicate) {
        return (List<E>) findAll(predicate);
    }
}