package com.amatrium.notification.sse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SseEvent<T> {

    /**
     * The identifier of a sub-set listeners in the channel.
     * It should be null if channel is SYSTEM, the organization_id if channel is ORGANIZATION or list of users that should receive the message
     */
    private Object receiverIdent;

    /**
     * The message content of the event
     */
    private T message;

}
