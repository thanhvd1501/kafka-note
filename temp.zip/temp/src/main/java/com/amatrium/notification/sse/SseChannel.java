package com.amatrium.notification.sse;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Define the SSE channel to distinguish which message should be sent to client
 */
@Getter
@AllArgsConstructor
public enum SseChannel {

    /**
     * The system channel for delivering general messages from the system
     */
    SYSTEM(1, "system"),

    /**
     * The private channel for the clients in the same organization
     */
    ORGANIZATION(10, "organization"),

    /**
     * The private channel for a sub-set of the users
     */
    USERS(20, "users");

    private int id;

    private String name;

    private static final Map<String, SseChannel> mapping = new HashMap<>();

    static {
        for (SseChannel type : values()) {
            mapping.put(type.getName(), type);
        }
    }

    public static SseChannel resolve(String value) {
        if (StringUtils.hasText(value)) {
            return mapping.get(value);
        }

        return null;
    }
}
