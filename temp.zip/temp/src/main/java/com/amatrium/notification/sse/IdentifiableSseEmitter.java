package com.amatrium.notification.sse;

import lombok.Getter;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Objects;

@Getter
public class IdentifiableSseEmitter extends SseEmitter {

    private final String id;

    public IdentifiableSseEmitter(String id) {
        Objects.requireNonNull(id);
        this.id = id;
    }

    /**
     * @param id
     * @param timeout the timeout value in milliseconds
     */
    public IdentifiableSseEmitter(String id, Long timeout) {
        super(timeout);
        Objects.requireNonNull(id);
        this.id = id;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof IdentifiableSseEmitter)) {
            return false;
        }

        IdentifiableSseEmitter other = (IdentifiableSseEmitter) obj;
        return Objects.equals(id, other.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return id;
    }
}
