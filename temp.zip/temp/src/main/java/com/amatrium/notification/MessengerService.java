package com.amatrium.notification;

import com.amatrium.config.AsyncTaskConfig;
import com.amatrium.notification.message.BaseMessage;
import org.springframework.scheduling.annotation.Async;

public interface MessengerService {

    @Async(AsyncTaskConfig.BEAN_ASYNC_EXECUTOR)
    void sendMessageInAsync(BaseMessage messageInfo);
}

