package com.amatrium.notification;

import com.amatrium.config.ApplicationConfig;
import com.amatrium.notification.message.BaseMessage;
import com.amatrium.notification.message.EmailMessage;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.nio.charset.StandardCharsets;
import java.util.Map;

@Service
@Slf4j
public class EmailServiceImpl implements MessengerService {

    @Value("${spring.mail.from-address:noreply@amatrium.com}")
    private String fromAddress;

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private SpringTemplateEngine templateEngine;

    @Autowired
    private ApplicationConfig applicationConfig;

    @Override
    public void sendMessageInAsync(BaseMessage messageInfo) {
        if (!(messageInfo instanceof EmailMessage)) {
            log.error("Invalid type of message");
            return;
        }

        EmailMessage email = (EmailMessage) messageInfo;
        Map<String, String> args = email.getArguments();
        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, StandardCharsets.UTF_8.name());
            helper.setFrom(fromAddress);
            helper.setSubject(email.getSubject());
            helper.setTo(email.getReceiver());

            Context context = new Context();
            for (Map.Entry<String, String> varEntry : args.entrySet()) {
                context.setVariable(varEntry.getKey(), varEntry.getValue());
            }
            context.setVariable(Constants.ARG_WEB_UI_ENDPOINT, applicationConfig.getWebEndpoint());

            String html = templateEngine.process(email.getTemplate(), context);
            helper.setText(html, true);

            javaMailSender.send(mimeMessage);
        } catch (MessagingException messagingException) {
            log.error("Failed to send the email", messagingException);
        }
    }
}
