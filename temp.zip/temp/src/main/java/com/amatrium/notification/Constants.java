package com.amatrium.notification;

public final class Constants {

    private Constants() {
    }

    public static final String TEMPLATE_EMAIL_INVITE_USER = "inviteUser.html";

    public static final String TEMPLATE_EMAIL_RESET_PASSWORD = "resetPasswordForm.html";

    public static final String TEMPLATE_EMAIL_PASSWORD_CHANGE = "changePassword.html";

    public static final String ARG_WEB_UI_ENDPOINT = "ARG_WEB_UI_ENDPOINT";

    public static final String ARG_USER_NAME = "ARG_USER_NAME";

    public static final String ARG_USER_EMAIL = "ARG_USER_EMAIL";

    public static final String ARG_USER_PWD = "ARG_USER_PWD";

    public static final String ARG_CODE_TO_RESET_PASSWORD = "ARG_CODE_TO_RESET_PASSWORD";

    public static final String ARG_EXPIRATION_TIME = "ARG_EXPIRATION_TIME";

}
