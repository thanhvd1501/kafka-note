package com.amatrium.notification.sse;

import com.amatrium.config.AsyncTaskConfig;
import org.springframework.scheduling.annotation.Async;

/**
 * SSE connection manager
 */
public interface SseManager {

    final String CONNECTION_ID = "connection_id";

    /**
     * Establish new SSE connection
     *
     * @return
     */
    IdentifiableSseEmitter establish();

    /**
     * Send the event message to clients in asynchronous
     *
     * @param channel
     * @param event
     */
    @Async(AsyncTaskConfig.BEAN_ASYNC_EXECUTOR)
    void broadcastEventInAsync(SseChannel channel, SseEvent<?> event);
}
