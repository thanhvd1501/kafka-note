package com.amatrium.notification.sse;

import com.amatrium.util.SecurityUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class SseManagerImpl implements SseManager {

    @Value("${sse.timeout-minutes:120}")
    private int sseTimeOutMinutes;

    /**
     * username(or email) -> IdentifiableSseEmitter
     */
    private final Map<String, Set<IdentifiableSseEmitter>> allEmitters = new ConcurrentHashMap<>();

    /**
     * organization id -> set of IdentifiableSseEmitters (connections to clients)
     */
    private final Map<String, Set<IdentifiableSseEmitter>> orgzEmitters = new ConcurrentHashMap<>();

    @Override
    public IdentifiableSseEmitter establish() {
        final IdentifiableSseEmitter emitter = new IdentifiableSseEmitter(
                UUID.randomUUID().toString(),
                sseTimeOutMinutes * 60 * 1000L);

        emitter.onCompletion(() -> {
            log.debug("SSE-Emitter.onCompletion: clear connections");
            clearConnection(emitter);
        });

        emitter.onTimeout(() -> {
            log.debug("SSE-Emitter.onTimeout: clear connections");
            emitter.complete();
            clearConnection(emitter);
        });

        emitter.onError(e -> {
            log.debug("SSE-Emitter.onError: clear connections");
            clearConnection(emitter);
        });

        Optional<String> currentUser = SecurityUtil.getCurrentUsername();
        if (currentUser.isPresent()) {
            allEmitters.computeIfAbsent(currentUser.get(), m -> new HashSet<>());
            allEmitters.get(currentUser.get()).add(emitter);
        } else {
            log.warn("The registered user is unknown");
        }

        String organization = SecurityUtil.getUserOrganization();
        if (StringUtils.hasText(organization)) {
            orgzEmitters.computeIfAbsent(organization, m -> new HashSet<>());
            orgzEmitters.get(organization).add(emitter);
        }

        return emitter;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void broadcastEventInAsync(SseChannel channel, SseEvent<?> event) {
        if (event == null) {
            return;
        }

        List<IdentifiableSseEmitter> emitters = new ArrayList<>();
        // send the system message to all emitters
        Object identity = event.getReceiverIdent();
        switch (channel) {
            case SYSTEM -> {
                // send message of the system to all emitters
                for (Set<IdentifiableSseEmitter> emitterSet : allEmitters.values()) {
                    emitters.addAll(emitterSet);
                }
            }
            case ORGANIZATION -> {
                // send message of the system to the emitters of a organization
                String organizationId = identity == null ? null : identity.toString();
                emitters.addAll(orgzEmitters.getOrDefault(organizationId, Set.of()));
            }
            case USERS -> {
                List<String> users = identity == null ? Collections.emptyList() : (List<String>) identity;
                for (String user : users) {
                    emitters.addAll(allEmitters.getOrDefault(user, Set.of()));
                }
            }
            default -> {
                log.error(String.format("No SSE handler for channel %s", channel));
                return;
            }
        }

        // Initialize SSE event
        SseEmitter.SseEventBuilder eventBuilder = SseEmitter.event()
                .id(UUID.randomUUID().toString())
                .name(channel.getName())
                .data(event.getMessage());
        // Send the event to listeners
        emitters.forEach(emitter -> {
            try {
                emitter.send(eventBuilder);
            } catch (Exception e) {
                log.warn("Failed to send SSE msg: " + e.getMessage());
            }
        });
    }

    private void clearConnection(IdentifiableSseEmitter emitter) {
        allEmitters.values().forEach(e -> e.remove(emitter));
        orgzEmitters.values().forEach(e -> e.remove(emitter));
    }
}
