package com.amatrium.mapper;

import com.amatrium.dto.OrganizationDto;
import com.amatrium.entity.Organization;
import org.springframework.stereotype.Service;

@Service
public class OrganizationMapper extends AbstractMapper<Organization, OrganizationDto> {

    @Override
    public Class<OrganizationDto> getDtoClass() {
        return OrganizationDto.class;
    }
}
