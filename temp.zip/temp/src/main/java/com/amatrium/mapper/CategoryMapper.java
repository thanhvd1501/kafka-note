package com.amatrium.mapper;

import com.amatrium.dto.CategoryDto;
import com.amatrium.entity.Category;
import org.springframework.stereotype.Service;

@Service
public class CategoryMapper extends AbstractMapper<Category, CategoryDto> {
    @Override
    public Class<CategoryDto> getDtoClass() {
        return CategoryDto.class;
    }
}
