package com.amatrium.mapper;

import com.amatrium.dto.PropertyDto;
import com.amatrium.entity.Property;
import org.springframework.stereotype.Service;

@Service
public class PropertyMappper extends AbstractMapper<Property, PropertyDto> {
    @Override
    public Class<PropertyDto> getDtoClass() {
        return PropertyDto.class;
    }
}
