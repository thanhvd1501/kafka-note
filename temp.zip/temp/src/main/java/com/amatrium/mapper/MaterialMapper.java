package com.amatrium.mapper;

import com.amatrium.dto.MaterialDto;
import com.amatrium.entity.Material;
import org.springframework.stereotype.Service;

@Service
public class MaterialMapper extends AbstractMapper<Material, MaterialDto> {
    @Override
    public Class<MaterialDto> getDtoClass() {
        return MaterialDto.class;
    }
}
