package com.amatrium.mapper;

import com.amatrium.dto.UserDto;
import com.amatrium.entity.User;
import org.springframework.stereotype.Service;

@Service
public class UserMapper extends AbstractMapper<User, UserDto> {
    @Override
    public Class<UserDto> getDtoClass() {
        return UserDto.class;
    }
}
