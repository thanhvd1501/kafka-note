package com.amatrium.mapper;

import com.amatrium.dto.CompositionDto;
import com.amatrium.entity.Composition;
import org.springframework.stereotype.Service;

@Service
public class CompositionMapper extends AbstractMapper<Composition, CompositionDto> {

    @Override
    public Class<CompositionDto> getDtoClass() {
        return CompositionDto.class;
    }
}
