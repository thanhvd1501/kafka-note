package com.amatrium.mapper;

import com.amatrium.dto.NotificationDto;
import com.amatrium.entity.Notification;
import org.springframework.stereotype.Service;

@Service
public class NotificationMapper  extends AbstractMapper<Notification, NotificationDto> {

    @Override
    public Class<NotificationDto> getDtoClass() {
        return NotificationDto.class;
    }
}