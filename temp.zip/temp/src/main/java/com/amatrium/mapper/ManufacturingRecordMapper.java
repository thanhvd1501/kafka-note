package com.amatrium.mapper;

import com.amatrium.dto.ManufacturingRecordDto;
import com.amatrium.entity.ManufacturingRecord;
import org.springframework.stereotype.Service;

@Service
public class ManufacturingRecordMapper extends AbstractMapper<ManufacturingRecord, ManufacturingRecordDto> {
    @Override
    public Class<ManufacturingRecordDto> getDtoClass() {
        return ManufacturingRecordDto.class;
    }
}
