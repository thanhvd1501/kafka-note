package com.amatrium.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public abstract class AbstractMapper<E, DTO> implements Mapper<E, DTO> {

    @Autowired
    private ModelMapper modelMapper;

    /**
     * @param e
     * @return
     * @see <a href="https://www.baeldung.com/java-modelmapper#what-is-property-mapping-in-modelmapper">Properties mapping</a>
     */
    @Override
    public DTO toDto(E e) {
        return modelMapper.map(e, getDtoClass());
    }

    @Override
    public List<DTO> toDtoList(List<E> eList) {
        return eList
                .stream()
                .map(this::toDto)
                .toList();
    }
}
