package com.amatrium.listener;

import com.amatrium.config.ApplicationConfig;
import com.amatrium.config.AsyncTaskConfig;
import com.amatrium.service.HousekeepingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/**
 * @author Son Nguyen
 */
@Component
@Profile("!test")
@Slf4j
public class ApplicationStartedProcessor implements ApplicationListener<ApplicationReadyEvent> {

    private static final long DAY_TO_MILLISECONDS = 24 * 60 * 60 * 1000L;

    @Autowired
    @Qualifier(AsyncTaskConfig.BEAN_ASYNC_EXECUTOR)
    private Executor executor;

    @Autowired
    private HousekeepingService housekeepingService;

    @Autowired
    private ApplicationConfig applicationConfig;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        // when application restarted, all the secret code is cleaned, so all the functions in NEW/IN_PROGRESS state should be cleaned
        housekeepingService.markFunctionStateTimeout(new Date());
    }

    /**
     * Initialize the housekeeping scheduler
     */
    @Scheduled(cron = "${amatrium.housekeeping.cron-job}")
    public void initCleanOldDataScheduler() {
        log.info("Start cleaning up the old data in the system");
        executor.execute(() -> {
            int recordsLifespan = applicationConfig.getNotificationLifespan();
            long beforeDate = System.currentTimeMillis() - recordsLifespan * DAY_TO_MILLISECONDS;
            housekeepingService.cleanNotification(new Date(beforeDate));
        });

        executor.execute(() -> {
            int recordsLifespan = applicationConfig.getFunctionStateLifespan();
            long beforeDate = System.currentTimeMillis() - recordsLifespan * DAY_TO_MILLISECONDS;
            housekeepingService.cleanFunctionState(new Date(beforeDate));
        });
    }

    /**
     * Initialize the scheduler to clean secret code
     */
    @Scheduled(fixedDelayString = "${amatrium.housekeeping.fixed-rate.clean-expiration-code:15}", initialDelay = 1, timeUnit = TimeUnit.MINUTES)
    public void initCleanSecretCodeScheduler() {
        housekeepingService.cleanUserSecretCode();
    }

    /**
     * Initialize the scheduler to mark the function state as failed when time-out
     */
    @Scheduled(fixedDelayString = "${amatrium.housekeeping.fixed-rate.function-state-time-out:15}", initialDelay = 5, timeUnit = TimeUnit.MINUTES)
    public void initCheckFunctionStateTimeoutScheduler() {
        int recordsLifespan = applicationConfig.getFunctionStateTimeout();
        long beforeDate = System.currentTimeMillis() - recordsLifespan * 60 * 1000L;
        housekeepingService.markFunctionStateTimeout(new Date(beforeDate));
    }

    /**
     * Initialize the scheduler to clean expiration cache
     */
    @Scheduled(fixedDelayString = "${amatrium.housekeeping.fixed-rate.clean-blacklist-token:30}", initialDelay = 1, timeUnit = TimeUnit.MINUTES)
    public void initCleanExpirationCacheScheduler() {
        housekeepingService.cleanExpirationCache();
    }

}
