package com.amatrium.constant;

public final class SecurityConstant {

    private SecurityConstant() {
    }

    public static final String TOKEN_CLAIM_ROLE = "roles";

    public static final String TOKEN_CLAIM_ORGANIZATION = "orgz";

    public static final String TOKEN_CLAIM_USER = "email";

    public static final String TOKEN_CLAIM_NAME = "name";

}
