package com.amatrium.constant;

/**
 * List out all the i18n key in the message.properties
 */
public final class I18nConstant {

    private I18nConstant() {
    }

    public static final String ERR_PERMISSION_DENIED = "error.permission-denied";

    public static final String MSG_IMPORT_NO_DATA = "msg.import.no-data";

    public static final String MSG_IMPORT_HISTORICAL_SUCCESS = "msg.import.manufacturing.success";

    public static final String MSG_IMPORT_HISTORICAL_FAILURE = "msg.import.manufacturing.failure";

    public static final String MSG_DATA_REACHES_LIMIT = "msg.import.manufacturing.reached-limit";

    public static final String MSG_IMPORT_MATERIAL_SUCCESS = "msg.import.material.success";

    public static final String MSG_IMPORT_MATERIAL_FAILURE = "msg.import.material.failure";

    public static final String MSG_RETRAIN_START = "msg.retrain.start";

    public static final String MSG_RETRAIN_SUCCESS = "msg.retrain.success";

    public static final String MSG_RETRAIN_FAILURE = "msg.retrain.failure";

    public static final String MSG_FUNCTION_STATE_TIME_OUT = "msg.function-state.time-out";

    public static final String MSG_UPDATE_ROLE_SUCCESS = "msg.update-role.success";
}
