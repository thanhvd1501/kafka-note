package com.amatrium.security;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Principal {

    private final String username;

    private final String organization;

}
