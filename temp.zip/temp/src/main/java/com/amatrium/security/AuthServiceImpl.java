package com.amatrium.security;

import com.amatrium.cache.UserDataManager;
import com.amatrium.config.ApplicationConfig;
import com.amatrium.constant.SecurityConstant;
import com.amatrium.dto.TokenPairDto;
import com.amatrium.entity.User;
import com.amatrium.exception.InternalException;
import com.amatrium.exception.JwtException;
import com.amatrium.exception.UnauthorizedException;
import com.amatrium.notification.Constants;
import com.amatrium.notification.MessengerService;
import com.amatrium.notification.message.EmailMessage;
import com.amatrium.repository.UserRepository;
import com.amatrium.util.RegexValidationUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class AuthServiceImpl implements AuthService {

    @Autowired
    private ApplicationConfig appConfig;

    @Autowired
    private JwtManagementService jwtManagementService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private MessengerService emailService;

    @Autowired
    private UserDataManager userDataManager;


    @Override
    public TokenPairDto login(String username, String password) throws UnauthorizedException {
        if (!StringUtils.hasText(username) || !StringUtils.hasText(password)) {
            throw new UnauthorizedException("Invalid credentials");
        }

        // verify the user credentials
        User user = userRepository.findByEmail(username);
        if (user == null ||
                !StringUtils.hasText(user.getPassword()) ||
                !passwordEncoder.matches(password.trim(), user.getPassword())) {
            throw new UnauthorizedException("Your account/password is incorrect");
        }

        try {
            Map<String, Object> claims = new HashMap<>();
            claims.put(SecurityConstant.TOKEN_CLAIM_NAME, user.getName());
            if (StringUtils.hasText(user.getOrganization())) {
                claims.put(SecurityConstant.TOKEN_CLAIM_ORGANIZATION, user.getOrganization());
            }

            return jwtManagementService.generateToken(
                    username,
                    List.of(user.getRole()),
                    claims,
                    true);
        } catch (JwtException e) {
            throw new UnauthorizedException("Failed to generate access token", e);
        }
    }

    @Override
    public boolean sendResetPasswordEmail(String email) throws InternalException {
        if (!StringUtils.hasText(email)) {
            throw new InternalException("Invalid email");
        }

        User user = userRepository.findByEmail(email);

        if (user == null) {
            log.error(String.format("Could not found any user by email '%s'", email));
            throw new InternalException("The user do not exist in your organization");
        }

        String randomCode = userDataManager.generateUserSecret(email);

        Map<String, String> emailArgs = new HashMap<>();
        emailArgs.put(Constants.ARG_WEB_UI_ENDPOINT, appConfig.getWebEndpoint());
        emailArgs.put(Constants.ARG_USER_EMAIL, email);
        emailArgs.put(Constants.ARG_CODE_TO_RESET_PASSWORD, randomCode);
        emailArgs.put(Constants.ARG_EXPIRATION_TIME, String.valueOf(appConfig.getSecretCodeLifespan()));

        EmailMessage emailInfo = EmailMessage.builder()
                .template(Constants.TEMPLATE_EMAIL_RESET_PASSWORD)
                .receiver(user.getEmail())
                .subject("Reset password")
                .arguments(emailArgs)
                .build();
        emailService.sendMessageInAsync(emailInfo);

        return true;
    }

    @Override
    public boolean resetUserPassword(String randomCode, String email, String password) throws InternalException {

        if(!RegexValidationUtil.isValidPassword(password)) {
            throw new InternalException("Password must be minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character among: @,$,!,%,*,?,&");
        }

        if (userDataManager.verifyUserSecret(email, randomCode)) {
            User user = userRepository.findByEmail(email);
            user.setPassword(passwordEncoder.encode(password));
            userRepository.save(user);

            userDataManager.clean(email, null);
            return true;
        }

        throw new InternalException("The code seems to be invalid or expired");
    }
}
