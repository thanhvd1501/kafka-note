package com.amatrium.security;

import com.amatrium.dto.TokenPairDto;
import com.amatrium.exception.JwtException;
import org.springframework.security.core.Authentication;

import java.util.List;
import java.util.Map;

public interface JwtManagementService {

    /**
     * Generate the authentication token
     *
     * @param user             identifier of the user (email or username)
     * @param userRoles        list of user role
     * @param additionalClaims other claims
     * @param withRefreshToken generate refresh token also?
     * @return
     * @throws JwtException
     */
    TokenPairDto generateToken(String user,
                               List<String> userRoles,
                               Map<String, Object> additionalClaims,
                               boolean withRefreshToken) throws JwtException;

    /**
     * @param accessToken
     * @return
     */
    Authentication createAuthentication(String accessToken) throws JwtException;
}
