package com.amatrium.security;

import com.amatrium.cache.UserDataManager;
import com.amatrium.config.JwtConfig;
import com.amatrium.constant.SecurityConstant;
import com.amatrium.dto.TokenPairDto;
import com.amatrium.exception.JwtException;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class JwtManagementServiceImpl implements JwtManagementService {

    @Autowired
    private JwtConfig jwtConfig;

    @Autowired
    private UserDataManager userDataManager;

    private MACSigner signer;

    private MACVerifier macVerifier;

    @PostConstruct
    public void init() throws JOSEException {
        // initialize token signing
        String signingKey = jwtConfig.getSigningKey();
        if (signingKey != null) {
            signer = new MACSigner(signingKey);
            macVerifier = new MACVerifier(signingKey);
        } else {
            signer = null;
        }
    }

    @Override
    public TokenPairDto generateToken(String user,
                                      List<String> userRoles,
                                      Map<String, Object> additionalClaims,
                                      boolean withRefreshToken) throws JwtException {
        if (additionalClaims == null) {
            additionalClaims = new HashMap<>();
        }

        // Adding the token claims
        long currentTime = System.currentTimeMillis();
        long lifespanInMinute = jwtConfig.getAccessTokenLifespan();
        JWTClaimsSet.Builder claimSetBuilder = new JWTClaimsSet.Builder()
                .claim(SecurityConstant.TOKEN_CLAIM_USER, user)
                .claim(SecurityConstant.TOKEN_CLAIM_ROLE, userRoles)
                .issueTime(new Date(currentTime))
                .expirationTime(new Date(currentTime + lifespanInMinute * 60 * 1000));
        for (Map.Entry<String, Object> claimEntry : additionalClaims.entrySet()) {
            claimSetBuilder = claimSetBuilder.claim(claimEntry.getKey(), claimEntry.getValue());
        }

        // Sign the token
        String signedJWT = getSignedJWT(claimSetBuilder.build());

        // Initialize response
        TokenPairDto ret = TokenPairDto.builder()
                .accessToken(signedJWT)
                .accessTokenExp(lifespanInMinute)
                .build();

        // Generate refresh token if needed
        if (withRefreshToken) {
            String refreshToken = generateRefreshToken(user, currentTime);
            ret.setRefreshToken(refreshToken);
            ret.setRefreshTokenExp(jwtConfig.getRefreshTokenLifespan());
        }

        return ret;
    }

    @Override
    public Authentication createAuthentication(String accessToken) throws JwtException {
        Authentication ret;

        SignedJWT signedJWT = validateAccessToken(accessToken);
        if (signedJWT == null) {
            return null;
        }

        try {
            JWTClaimsSet jwtClaimsSet = signedJWT.getJWTClaimsSet();
            String email = (String) jwtClaimsSet.getClaim(SecurityConstant.TOKEN_CLAIM_USER);
            String organization = (String) jwtClaimsSet.getClaim(SecurityConstant.TOKEN_CLAIM_ORGANIZATION);
            Principal principal = new Principal(email, organization);

            List<String> userRoles = (List<String>) jwtClaimsSet.getClaim(SecurityConstant.TOKEN_CLAIM_ROLE);
            List<SimpleGrantedAuthority> authorities = userRoles.stream().map(SimpleGrantedAuthority::new).toList();

            ret = new UsernamePasswordAuthenticationToken(principal, null, authorities);
        } catch (ParseException e) {
            log.error(e.getMessage());
            return null;
        }

        return ret;
    }

    /**
     * Generate refresh token
     *
     * @param user
     * @return
     * @throws JwtException
     */
    private String generateRefreshToken(String user, long issuerAt) throws JwtException {
        long lifespan = jwtConfig.getRefreshTokenLifespan() * 60 * 1000;
        JWTClaimsSet.Builder jwtClaimsSet = new JWTClaimsSet.Builder()
                .claim(SecurityConstant.TOKEN_CLAIM_USER, user)
                .issueTime(new Date(issuerAt))
                .expirationTime(new Date(issuerAt + lifespan));

        return getSignedJWT(jwtClaimsSet.build());
    }

    /**
     * @param claimSet
     * @return
     * @throws JwtException
     */
    private String getSignedJWT(JWTClaimsSet claimSet) throws JwtException {
        JWSHeader jwtHeader = new JWSHeader.Builder(JWSAlgorithm.HS256)
                .type(JOSEObjectType.JWT)
                .build();
        SignedJWT signedJWT = new SignedJWT(jwtHeader, claimSet);

        try {
            signedJWT.sign(signer);
        } catch (JOSEException e) {
            log.error(e.getMessage());
            throw new JwtException("Failed to generate access token");
        }

        return signedJWT.serialize();
    }

    /**
     * Validate if access token is valid
     *
     * @param token
     * @return the signed jwt if it's valid
     */
    private SignedJWT validateAccessToken(String token) throws JwtException {
        if (!StringUtils.hasText(token)) {
            return null;
        }

        try {
            // sign verification
            SignedJWT signedJWT = SignedJWT.parse(token);
            if (!signedJWT.verify(macVerifier)) {
                log.error("Invalid signature");
                throw new JwtException("Token is invalid");
            }

            // expiration check
            JWTClaimsSet jwtClaimsSet = signedJWT.getJWTClaimsSet();
            Date expirationTime = jwtClaimsSet.getExpirationTime();
            if (expirationTime == null || expirationTime.before(new Date())) {
                log.error("Token expired");
                throw new JwtException("Token was expired");
            }

            //require login again check
            Date issueTime = jwtClaimsSet.getIssueTime();
            String user = (String) jwtClaimsSet.getClaim(SecurityConstant.TOKEN_CLAIM_USER);
            if (!userDataManager.verifyIssueTime(user, issueTime)) {
                log.error(String.format("Login again is requested for user %s",user));
                throw new JwtException(String.format("Login again is requested for user %s",user));
            }

            return signedJWT;
        } catch (ParseException | JOSEException e) {
            log.error(e.getMessage());
            throw new JwtException("Failed to verify the token");
        }
    }
}
