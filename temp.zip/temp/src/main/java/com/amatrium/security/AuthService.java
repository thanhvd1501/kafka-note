package com.amatrium.security;

import com.amatrium.dto.TokenPairDto;
import com.amatrium.exception.InternalException;
import com.amatrium.exception.UnauthorizedException;

public interface AuthService {

    /**
     * Login
     *
     * @param username
     * @param password
     * @return
     */
    TokenPairDto login(String username, String password) throws UnauthorizedException;

    boolean sendResetPasswordEmail(String email) throws InternalException;

    boolean resetUserPassword(String code, String email, String password) throws InternalException;
}
