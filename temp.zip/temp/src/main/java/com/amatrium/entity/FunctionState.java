package com.amatrium.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document("functionstates")
public class FunctionState extends Auditor {

    @Id
    private String id;

    @Field(value = "category_id")
    private String categoryId;

    @Field(value = "type")
    private String type;

    @Field(value = "state")
    private String state;
}
