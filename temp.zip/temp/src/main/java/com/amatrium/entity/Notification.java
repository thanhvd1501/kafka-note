package com.amatrium.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document("notifications")
public class Notification extends Auditor {

    @Id
    private String id;

    @Field("severity")
    private String severity;

    @Field("type")
    private String type;

    @Field("description")
    private String description;

    //language to message
    @Field("message")
    private Map<String, String> message;

    @Field("owner")
    private String owner;

    @Field("read")
    private Boolean isRead;
}