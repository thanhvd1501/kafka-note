package com.amatrium.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document("categories")
public class Category extends InitializationInfo {

    @Id
    private String id;

    @Field("name")
    private String name;

    @Field(value = "organization", targetType = FieldType.OBJECT_ID)
    private String organization;

    @Field("materials")
    private List<CategoryMaterial> materials;

    @Field("compositions")
    private List<Composition> compositions;

    @Field("processing")
    private List<Composition> processing;

    @Field("properties")
    private List<Property> properties;

}
