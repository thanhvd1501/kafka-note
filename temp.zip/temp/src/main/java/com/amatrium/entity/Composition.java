package com.amatrium.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document("compositions")
public class Composition extends Auditor {

    @Id
    private String id;

    @Field(value = "symbol")
    private String symbol;

    @Field(value = "name")
    private String name;

    @Field(value = "unit")
    private String unit;
}
