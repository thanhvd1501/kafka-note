package com.amatrium.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;

@Getter
@Setter
public class InitializationInfo {

    @CreatedDate
    @Field(name = "created_at")
    private Date createdDate;

    @CreatedBy
    @Field("created_by")
    private String createdBy;
}
