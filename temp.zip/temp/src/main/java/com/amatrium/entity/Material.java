package com.amatrium.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document("materials")
public class Material extends Auditor {

    @Id
    private String id;

    @Field("category_id")
    private String categoryId;

    @Field("label")
    private String label;

    @Field("compositions")
    private List<MaterialComposition> compositions;

    @Field("processing")
    private List<MaterialComposition> processing;
}
