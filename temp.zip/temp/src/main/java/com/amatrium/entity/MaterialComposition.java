package com.amatrium.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MaterialComposition {

    @Field("symbol")
    private String symbol;

    @Field("name")
    private String name;

    @Field("min")
    private Double min;

    @Field("max")
    private Double max;

    @Field("unit")
    private String unit;

    public MaterialComposition(MaterialComposition materialComposition) {
        this.symbol = materialComposition.getSymbol();
        this.name = materialComposition.getName();
        this.min = materialComposition.getMin();
        this.max = materialComposition.getMax();
        this.unit = materialComposition.getUnit();
    }
}
