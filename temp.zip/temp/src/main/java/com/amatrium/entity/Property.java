package com.amatrium.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document("properties")
public class Property extends Auditor {

    @Id
    private String id;

    @Field(value = "label", targetType = FieldType.STRING)
    private String label;

    @Field(value = "name")
    private String name;

    @Field(value = "unit")
    private String unit;
}
