package com.amatrium.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document("users")
public class User extends Auditor {

    @Id
    private String id;

    @Field("email")
    private String email;

    @Field("name")
    private String name;

    @Field("organization")
    private String organization;

    @Field("role")
    private String role;

    @Field("password")
    private String password;

}
