package com.amatrium.domaintype;

import java.util.List;

public enum UserRole {
    // The owner of the system
    SUPER_ADMIN,

    // The user roles of a certain organization
    ADMIN,
    DATA_ENTRY,
    USER;

    public static List<UserRole> getUserRoles() {
        return List.of(ADMIN, DATA_ENTRY, USER);
    }
}
