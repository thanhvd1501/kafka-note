package com.amatrium.domaintype;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Locale;

@Getter
@AllArgsConstructor
public enum SupportedLocale {

    ENGLISH("en", Locale.ENGLISH);

    private final String code;
    private final Locale locale;
}
