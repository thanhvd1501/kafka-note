package com.amatrium.domaintype;

import lombok.Getter;

@Getter
public enum NotificationType {
    MODEL_TRAINING,
    IMPORTING
}
