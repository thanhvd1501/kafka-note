package com.amatrium.domaintype;

public enum FunctionType {

    IMPORT,

    RETRAIN,

}