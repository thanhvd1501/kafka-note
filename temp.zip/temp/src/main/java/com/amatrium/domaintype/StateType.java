package com.amatrium.domaintype;

public enum StateType {

    NEW,

    COMPLETED,

    IN_PROGRESS,

    FAILED

}
