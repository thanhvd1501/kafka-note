package com.amatrium.domaintype;

public enum PredictionType {
    DISTRIBUTION,
    PROPERTY
}
