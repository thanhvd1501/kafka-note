package com.amatrium.cache;

import com.amatrium.config.ApplicationConfig;
import com.amatrium.exception.InternalException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;

@ExtendWith({
        MockitoExtension.class
})
public class UserDataManagerTest {

    @Mock
    private ApplicationConfig appConfig;

    @InjectMocks
    private UserDataManagerImpl userDataManager;

    @Test
    void test_generateUserSecret_whenInvalidInput() {
        Exception exception = Assertions.assertThrows(InternalException.class, () -> userDataManager.generateUserSecret(null));
        Assertions.assertNotNull(exception);

        exception = Assertions.assertThrows(InternalException.class, () -> userDataManager.generateUserSecret(" "));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_generateUserSecret() throws InternalException {
        String code = userDataManager.generateUserSecret("user");
        Assertions.assertNotNull(code);
    }

    @Test
    void test_verifyUserSecret_whenInvalidInput() throws InternalException {
        boolean result = userDataManager.verifyUserSecret(null, "avc");
        Assertions.assertFalse(result);

        result = userDataManager.verifyUserSecret(" ", "avc");
        Assertions.assertFalse(result);

        result = userDataManager.verifyUserSecret("user", "avc");
        Assertions.assertFalse(result);

        String code = userDataManager.generateUserSecret("user");
    }

    @Test
    void test_verifyUserSecret() throws InternalException {
        Mockito.when(appConfig.getSecretCodeLifespan()).thenReturn(15);
        String code = userDataManager.generateUserSecret("user");
        boolean result = userDataManager.verifyUserSecret("user", code);
        Assertions.assertTrue(result);
    }

    @Test
    void test_cleanAll() throws InternalException {
        // clean all
        userDataManager.clean(null, null);

        // clean all by user
        String code = userDataManager.generateUserSecret("user");
        userDataManager.clean("user", null);
        boolean result = userDataManager.verifyUserSecret("user", code);
        Assertions.assertFalse(result);

        // clean all by date
        String user1Code = userDataManager.generateUserSecret("user1");
        userDataManager.clean(null, System.currentTimeMillis() - 30 * 60 * 1000L);
        result = userDataManager.verifyUserSecret("user1", code);
        Assertions.assertFalse(result);

        // clean all by user and date
        String user2Code = userDataManager.generateUserSecret("user2");
        userDataManager.clean("user2", System.currentTimeMillis() - 30 * 60 * 1000L);
        result = userDataManager.verifyUserSecret("user2", code);
        Assertions.assertFalse(result);
    }

    @Test
    void test_verifyIssueTime() throws InternalException {
        boolean result = userDataManager.verifyIssueTime("user", null);
        Assertions.assertFalse(result);

        result = userDataManager.verifyIssueTime(null, new Date());
        Assertions.assertFalse(result);

        userDataManager.markAccessExpired("user", 123456789L);
        result = userDataManager.verifyIssueTime("user", new Date(12345678L));
        Assertions.assertFalse(result);

        result = userDataManager.verifyIssueTime("username", new Date());
        Assertions.assertTrue(result);

        userDataManager.markAccessExpired("usr", 123456789L);
        result = userDataManager.verifyIssueTime("usr", new Date(12345678910L));
        Assertions.assertTrue(result);
    }

    @Test
    void test_markAccessExpired_whenInvalidInput() {
        Exception exception = Assertions.assertThrows(InternalException.class, () -> userDataManager.markAccessExpired(null, 123456L));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_markAccessExpired() throws InternalException {
        userDataManager.markAccessExpired("user", 12345678910L);
        boolean result = userDataManager.verifyIssueTime("user", new Date(1234567891011L));
        Assertions.assertTrue(result);
    }

    @Test
    void test_cleanExpirationCache() throws InternalException {
        userDataManager.markAccessExpired("user", 12345678910L);
        userDataManager.cleanExpirationCache(12345678911L);
        boolean result = userDataManager.verifyIssueTime("user", new Date());
        Assertions.assertTrue(result);
    }
}
