package com.amatrium.cache;

import com.amatrium.domaintype.StateType;
import com.amatrium.exception.InternalException;
import com.amatrium.mock.DummyFunctionState;
import com.amatrium.repository.FunctionStateRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

@ExtendWith({
        MockitoExtension.class
})
class ProcessingTaskManagerTest {

    @Mock
    private FunctionStateRepository functionStateRepo;

    @InjectMocks
    private ProcessingTaskManagerImpl processingTaskManager;

    @Test
    void test_lockManufacturingRecordImporting() {
        Exception exception = Assertions.assertThrows(InternalException.class, () -> processingTaskManager.lockCategoryForImporting(null));
        Assertions.assertNotNull(exception);

        Mockito.when(functionStateRepo.find(Mockito.any())).thenReturn(DummyFunctionState.mockFunctionStates(3));
        exception = Assertions.assertThrows(InternalException.class, () -> processingTaskManager.lockCategoryForImporting("123456789"));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_unlockCategory() {
        Assertions.assertFalse(processingTaskManager.unlockCategory(null, StateType.FAILED));

        Mockito.when(functionStateRepo.find(Mockito.any())).thenReturn(new ArrayList<>());
        Assertions.assertFalse(processingTaskManager.unlockCategory("123456789", StateType.FAILED));

        Mockito.when(functionStateRepo.find(Mockito.any())).thenReturn(DummyFunctionState.mockFunctionStates(3));
        Assertions.assertTrue(processingTaskManager.unlockCategory("123456789", StateType.FAILED));
    }

    @Test
    void test_isCategoryLocked() throws InternalException {
        Exception exception = Assertions.assertThrows(InternalException.class, () -> processingTaskManager.isCategoryLocked(null));
        Assertions.assertNotNull(exception);

        Mockito.when(functionStateRepo.find(Mockito.any())).thenReturn(DummyFunctionState.mockFunctionStates(3));
        Assertions.assertTrue(processingTaskManager.isCategoryLocked("123456789"));
    }
}
