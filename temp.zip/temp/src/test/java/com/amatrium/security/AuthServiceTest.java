package com.amatrium.security;

import com.amatrium.cache.UserDataManager;
import com.amatrium.config.ApplicationConfig;
import com.amatrium.domaintype.UserRole;
import com.amatrium.dto.TokenPairDto;
import com.amatrium.entity.User;
import com.amatrium.exception.InternalException;
import com.amatrium.exception.JwtException;
import com.amatrium.exception.UnauthorizedException;
import com.amatrium.mock.DummyUserManagement;
import com.amatrium.notification.MessengerService;
import com.amatrium.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

@ExtendWith({
        MockitoExtension.class
})
class AuthServiceTest {

    @InjectMocks
    private AuthServiceImpl authService;

    @Mock
    private JwtManagementService jwtManagementService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private MessengerService emailService;

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private UserDataManager userDataManager;

    @Test
    void test_login_whenUsernamePasswordInvalid() {
        // username was null
        Exception exception = Assertions.assertThrows(UnauthorizedException.class, () -> authService.login(null, "pwd"));
        Assertions.assertNotNull(exception);

        // username was empty
        exception = Assertions.assertThrows(UnauthorizedException.class, () -> authService.login(" ", "pwd"));
        Assertions.assertNotNull(exception);

        // pwd was null
        exception = Assertions.assertThrows(UnauthorizedException.class, () -> authService.login("user", null));
        Assertions.assertNotNull(exception);

        // pwd was empty
        exception = Assertions.assertThrows(UnauthorizedException.class, () -> authService.login("user", ""));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_login_whenNoUserWasFound() {
        String username = "admin@mail.com";
        Mockito.when(userRepository.findByEmail(username)).thenReturn(null);

        Exception exception = Assertions.assertThrows(UnauthorizedException.class, () -> authService.login(username, "pwd"));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_login_whenUserHasNoPwd() {
        String username = "admin@mail.com";
        User user = new User();
        user.setEmail(username);
        user.setPassword(null);

        Mockito.when(userRepository.findByEmail(username)).thenReturn(user);
        Exception exception = Assertions.assertThrows(UnauthorizedException.class, () -> authService.login(username, "pwd"));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_login_whenPwdIsIncorrect() {
        String username = "admin@mail.com";
        User user = new User();
        user.setEmail(username);
        user.setPassword("pwd");

        Mockito.when(userRepository.findByEmail(username)).thenReturn(user);
        Mockito.when(passwordEncoder.matches(Mockito.any(), Mockito.any())).thenReturn(false);
        Exception exception = Assertions.assertThrows(UnauthorizedException.class, () -> authService.login(username, "pwd"));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_login() throws JwtException, UnauthorizedException {
        TokenPairDto tokenPair = TokenPairDto.builder().build();

        String username = "admin@mail.com";
        String pwd = "123";
        User user = new User();
        user.setName("Test");
        user.setEmail(username);
        user.setPassword(pwd);
        user.setOrganization("123");
        user.setRole(UserRole.ADMIN.name());

        Mockito.when(userRepository.findByEmail(username)).thenReturn(user);
        Mockito.when(passwordEncoder.matches(Mockito.any(), Mockito.any())).thenReturn(true);
        Mockito.when(jwtManagementService.generateToken(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyBoolean())).thenReturn(tokenPair);

        TokenPairDto ret = authService.login(username, pwd);
        Assertions.assertNotNull(ret);
    }

    @Test
    void test_sendResetPasswordEmail_whenInvalidInput() {
        Exception exception = Assertions.assertThrows(InternalException.class, () -> authService.sendResetPasswordEmail(null));
        Assertions.assertNotNull(exception);

        exception = Assertions.assertThrows(InternalException.class, () -> authService.sendResetPasswordEmail(" "));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_sendResetPasswordEmail_whenUserNotFoundByEmail() {
        String email = "user@gmail.com";
        Mockito.when(userRepository.findByEmail(email)).thenReturn(null);
        Exception exception = Assertions.assertThrows(InternalException.class, () -> authService.sendResetPasswordEmail(email));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_sendResetPasswordEmail() throws InternalException {
        String email = "user@gmail.com";
        Mockito.when(userRepository.findByEmail(email)).thenReturn(DummyUserManagement.mockUser("id", "user"));
        Mockito.when(userDataManager.generateUserSecret(Mockito.any())).thenReturn("123");

        boolean result = authService.sendResetPasswordEmail(email);
        Assertions.assertTrue(result);
    }

    @Test
    void test_resetUserPassword_whenVerifyFailed() {
        Mockito.when(userDataManager.verifyUserSecret(Mockito.any(), Mockito.any())).thenReturn(false);
        Exception exception = Assertions.assertThrows(InternalException.class, () -> authService.resetUserPassword("123", "user@gmail.com", "123456789H@i"));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_resetUserPassword_whenInvalidPassword() {
        Exception exception = Assertions.assertThrows(InternalException.class, () -> authService.resetUserPassword("12345678", "haivu0352@gmail.com", "123456789"));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_resetUserPassword() throws InternalException {
        Mockito.when(userDataManager.verifyUserSecret(Mockito.any(), Mockito.any())).thenReturn(true);
        Mockito.when(userRepository.findByEmail(Mockito.any())).thenReturn(DummyUserManagement.mockUser("123", "user"));
        Mockito.when(passwordEncoder.encode(Mockito.any())).thenReturn("123");

        boolean ret = authService.resetUserPassword("123", "user@gmail.com", "123456789H@i");
        Assertions.assertTrue(ret);
    }
}
