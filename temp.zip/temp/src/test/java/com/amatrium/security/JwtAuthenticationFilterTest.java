package com.amatrium.security;

import com.amatrium.exception.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.IOException;

@ExtendWith({
        MockitoExtension.class
})
class JwtAuthenticationFilterTest {

    @Mock
    private JwtManagementService jwtService;

    @InjectMocks
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Test
    void test_filter() throws IOException, ServletException, JwtException {
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
        FilterChain filterChain = Mockito.mock(FilterChain.class);

        String principal = "user";
        Authentication authentication = new UsernamePasswordAuthenticationToken(principal, null);

        Mockito.when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn("Bearer 123");
        Mockito.doNothing().when(filterChain).doFilter(request, response);
        Mockito.when(jwtService.createAuthentication("123")).thenReturn(authentication);

        jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

        Authentication savedAuth = SecurityContextHolder.getContext().getAuthentication();
        Assertions.assertNotNull(savedAuth);
        Assertions.assertEquals(principal, savedAuth.getPrincipal().toString());
    }

    @Test
    void test_filter_whenExceptionOccurred() throws IOException, ServletException, JwtException {
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
        FilterChain filterChain = Mockito.mock(FilterChain.class);

        Mockito.when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(null);
        Mockito.doNothing().when(filterChain).doFilter(request, response);
        Mockito.when(jwtService.createAuthentication(Mockito.any())).thenThrow(new JwtException("Dummy exception"));

        jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

        Authentication savedAuth = SecurityContextHolder.getContext().getAuthentication();
        Assertions.assertNull(savedAuth);
    }
}
