package com.amatrium.security;

import com.amatrium.cache.UserDataManager;
import com.amatrium.config.JwtConfig;
import com.amatrium.domaintype.UserRole;
import com.amatrium.dto.TokenPairDto;
import com.amatrium.exception.JwtException;
import com.nimbusds.jose.JOSEException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;

import java.util.List;
import java.util.Map;

@ExtendWith({
        MockitoExtension.class
})
class JwtManagementServiceTest {

    @Mock
    private JwtConfig jwtConfig;

    @Mock
    private UserDataManager dataManager;

    @InjectMocks
    private JwtManagementServiceImpl jwtManagementService;

    @BeforeEach
    public void beforeEach() {
        Mockito.when(jwtConfig.getSigningKey()).thenReturn("8y/B?E(H+MbPeShVmYq3t6w9z$C&F)J@");
    }

    @Test
    void test_generateToken_withoutRefreshToken() throws JwtException, JOSEException {
        Mockito.when(jwtConfig.getAccessTokenLifespan()).thenReturn(3L);

        jwtManagementService.init();
        TokenPairDto tokenPairDto = jwtManagementService.generateToken("user",
                List.of("USER"),
                null,
                false);

        Assertions.assertNotNull(tokenPairDto);
        Assertions.assertNotNull(tokenPairDto.getAccessToken());
        Assertions.assertNull(tokenPairDto.getRefreshToken());
    }

    @Test
    void test_generateToken_withRefreshToken() throws JwtException, JOSEException {
        Mockito.when(jwtConfig.getAccessTokenLifespan()).thenReturn(3L);
        Mockito.when(jwtConfig.getRefreshTokenLifespan()).thenReturn(3L);

        jwtManagementService.init();
        TokenPairDto tokenPairDto = jwtManagementService.generateToken("user",
                List.of("USER"),
                Map.of("claim", "Test"),
                true);

        Assertions.assertNotNull(tokenPairDto);
        Assertions.assertNotNull(tokenPairDto.getAccessToken());
        Assertions.assertNotNull(tokenPairDto.getRefreshToken());
    }

    @Test
    void test_createAuthentication() throws JOSEException, JwtException {
        jwtManagementService.init();

        // generate token
        String user = "user";
        Mockito.when(jwtConfig.getAccessTokenLifespan()).thenReturn(3L);
        Mockito.when(dataManager.verifyIssueTime(Mockito.any(),Mockito.any())).thenReturn(true);
        jwtManagementService.init();
        TokenPairDto tokenPairDto = jwtManagementService.generateToken(
                user,
                List.of(UserRole.USER.name()),
                Map.of("claim", "Test"),
                false);

        String token = tokenPairDto.getAccessToken();
        Authentication authentication = jwtManagementService.createAuthentication(token);
        Assertions.assertNotNull(authentication);
        Principal principal = (Principal) authentication.getPrincipal();
        Assertions.assertEquals(user, principal.getUsername());
    }

    @Test
    void test_createAuthentication_whenTokenIsNull() throws JwtException, JOSEException {
        jwtManagementService.init();
        Authentication authentication = jwtManagementService.createAuthentication(null);
        Assertions.assertNull(authentication);

        authentication = jwtManagementService.createAuthentication("  ");
        Assertions.assertNull(authentication);
    }

    @Test
    void test_createAuthentication_whenTokenIsInvalid() throws JOSEException {
        jwtManagementService.init();
        JwtException exception = Assertions.assertThrows(JwtException.class, () -> jwtManagementService.createAuthentication("123"));
        Assertions.assertNotNull(exception);
    }
}
