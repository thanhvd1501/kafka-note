package com.amatrium.mock;

import com.amatrium.dto.PropertyDto;
import com.amatrium.entity.Property;

import java.util.ArrayList;
import java.util.List;

public class DummyProperty {

    public static Property mockProperty(String id) {
        return Property.builder()
                .id(id)
                .build();
    }

    public static PropertyDto mockPropertyDto(String id) {
        return PropertyDto.builder()
                .id(id)
                .build();
    }

    public static List<Property> mockProperties(int number) {
        List<Property> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockProperty("id" + i));
        }
        return ret;
    }

    public static List<PropertyDto> mockPropertyDtos(int number) {
        List<PropertyDto> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockPropertyDto("id" + i));
        }
        return ret;
    }
}
