package com.amatrium.mock;

import com.amatrium.util.CsvReader;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;

public final class DummyFile {

    public static final String COMPOSITION_FILE = "composition.csv";

    public static final String COMPOSITION_HEADER = "symbol,name,unit";

    private DummyFile() {
    }

    /**
     *
     */
    public static MultipartFile mockCompositionsCsv(boolean withHeader, int numberOfRow) {
        StringBuilder stringBuilder = new StringBuilder();
        // add the header
        if (withHeader) {
            stringBuilder.append(COMPOSITION_HEADER);
            stringBuilder.append(System.lineSeparator());
        }

        for (int i = 0; i < numberOfRow; i++) {
            stringBuilder.append(String.format("symb%d, name%d, %s", i + 1, i + 1, "%"));
            stringBuilder.append(System.lineSeparator());
        }

        // add more blank lines
        stringBuilder.append(" ");
        stringBuilder.append(System.lineSeparator());
        stringBuilder.append(",,,");
        stringBuilder.append(System.lineSeparator());

        return new MockMultipartFile(COMPOSITION_FILE, COMPOSITION_FILE, CsvReader.CSV_CONTENT_TYPE, stringBuilder.toString().getBytes(StandardCharsets.UTF_8));
    }

    public static MultipartFile mockCompositionsHasSymbolDuplicateCsv() {
        StringBuilder stringBuilder = new StringBuilder();

        // add the header
        stringBuilder.append(COMPOSITION_HEADER);
        stringBuilder.append(System.lineSeparator());

        stringBuilder.append("ti,Titanium,%");
        stringBuilder.append(System.lineSeparator());

        stringBuilder.append("n,Nitrogen,%");
        stringBuilder.append(System.lineSeparator());

        stringBuilder.append("n,Nitrogen,%");
        stringBuilder.append(System.lineSeparator());

        return new MockMultipartFile(COMPOSITION_FILE, COMPOSITION_FILE, CsvReader.CSV_CONTENT_TYPE, stringBuilder.toString().getBytes(StandardCharsets.UTF_8));
    }
}
