package com.amatrium.mock;

import com.amatrium.dto.ManufacturingRecordDto;
import com.amatrium.entity.ManufacturingRecord;

import java.util.ArrayList;
import java.util.List;

public class DummyManufacturingRecord {

    public static ManufacturingRecord mockManufacturingRecord(String id) {
        return ManufacturingRecord.builder()
                .id(id)
                .build();
    }

    public static ManufacturingRecordDto mockManufacturingRecordDto(String id) {
        return ManufacturingRecordDto.builder()
                .id(id)
                .build();
    }

    public static List<ManufacturingRecord> mockManufacturingRecords(int number) {
        List<ManufacturingRecord> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockManufacturingRecord("id" + i));
        }
        return ret;
    }

    public static List<ManufacturingRecordDto> mockManufacturingRecordDtos(int number) {
        List<ManufacturingRecordDto> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockManufacturingRecordDto("id" + i));
        }
        return ret;
    }
}
