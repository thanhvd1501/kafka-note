package com.amatrium.mock;

import com.amatrium.dto.MaterialDto;
import com.amatrium.entity.Material;

import java.util.ArrayList;
import java.util.List;

public class DummyMaterial {

    public static Material mockMaterial(String id) {
        return Material.builder()
                .id(id)
                .build();
    }

    public static MaterialDto mockMaterialDto(String id) {
        return MaterialDto.builder()
                .id(id)
                .build();
    }

    public static List<Material> mockMaterials(int number) {
        List<Material> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockMaterial("id" + i));
        }
        return ret;
    }

    public static List<MaterialDto> mockMaterialDtos(int number) {
        List<MaterialDto> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockMaterialDto("id" + i));
        }
        return ret;
    }
}
