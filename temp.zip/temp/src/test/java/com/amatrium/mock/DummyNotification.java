package com.amatrium.mock;

import com.amatrium.dto.NotificationDto;
import com.amatrium.entity.Notification;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class DummyNotification {
    public DummyNotification() {
    }

    public static Notification mockNotification(String id, String owner) {
        return Notification.builder()
                .id(id)
                .severity("Info")
                .type("Importing")
                .message(Collections.singletonMap("en", "abc"))
                .owner(owner)
                .isRead(true)
                .build();
    }

    public static NotificationDto mockNotificationDto(String id, String owner) {
        return NotificationDto.builder()
                .id(id)
                .severity("Info")
                .type("Importing")
                .message(Collections.singletonMap("en", "xyz"))
                .owner(owner)
                .isRead(true)
                .build();
    }

    public static List<Notification> mockNotifications(int number, String owner) {
        List<Notification> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockNotification("id" + i, owner + i));
        }
        return ret;
    }

    public static List<NotificationDto> mockNotificationDtos(int number, String owner) {
        List<NotificationDto> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockNotificationDto("id" + i, owner + i));
        }
        return ret;
    }
}
