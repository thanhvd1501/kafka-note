package com.amatrium.mock;

import com.amatrium.dto.CompositionDto;
import com.amatrium.entity.Composition;

import java.util.ArrayList;
import java.util.List;

public final class DummyMetadata {

    private DummyMetadata() {
    }

    public static Composition mockComposition(String symb) {
        return Composition.builder()
                .symbol(symb)
                .name("Titanium")
                .unit("%")
                .build();
    }

    public static List<Composition> mockCompositions(int number) {
        List<Composition> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockComposition("symb" + i));
        }
        return ret;
    }

    public static CompositionDto mockCompositionDto(String id) {
        return CompositionDto.builder()
                .id(id)
                .symbol("ti")
                .name("Titanium")
                .unit("%")
                .build();
    }

    public static List<CompositionDto> mockCompositionDtos(int number) {
        List<CompositionDto> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockCompositionDto("id" + i));
        }
        return ret;
    }

}
