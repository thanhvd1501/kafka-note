package com.amatrium.mock;

import com.amatrium.dto.OrganizationDto;
import com.amatrium.entity.Organization;

import java.util.ArrayList;
import java.util.List;

public class DummyOrganization {

    public static final String ORGZ_ID = "123456";

    public DummyOrganization() {
    }

    public static Organization mockOrganization(String id, String name) {
        return Organization.builder()
                .id(id)
                .name(name)
                .build();
    }

    public static OrganizationDto mockOrganizationDto(String id, String name) {
        return OrganizationDto.builder()
                .id(id)
                .name(name)
                .build();
    }

    public static List<Organization> mockOrganizations(int number, String id, String name) {
        List<Organization> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockOrganization(id, name + i));
        }
        return ret;
    }

    public static List<OrganizationDto> mockOrganizationDtos(int number, String id, String name) {
        List<OrganizationDto> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockOrganizationDto(id, name + i));
        }
        return ret;
    }
}
