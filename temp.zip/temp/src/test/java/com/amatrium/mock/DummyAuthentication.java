package com.amatrium.mock;

import com.amatrium.security.Principal;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.List;

public class DummyAuthentication {

    public static final String USER_NAME = "test@your-email.com";

    public DummyAuthentication() {
    }

    public static Authentication mockAuthentication(String role) {
        Principal principal = new Principal(USER_NAME, DummyOrganization.ORGZ_ID);
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(role));

        return new UsernamePasswordAuthenticationToken(
                principal,
                null,
                authorities);
    }

    public static Authentication mockAuthentication(String orgzId, String role) {
        Principal principal = new Principal(USER_NAME, orgzId);
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(role));

        return new UsernamePasswordAuthenticationToken(
                principal,
                null,
                authorities);
    }

    public static Authentication mockAuthentication(String orgzId, String username, String role) {
        Principal principal = new Principal(username, orgzId);
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(role));

        return new UsernamePasswordAuthenticationToken(
                principal,
                null,
                authorities);
    }
}
