package com.amatrium.mock;

import com.amatrium.dto.CompositionDto;
import com.amatrium.entity.Composition;

import java.util.ArrayList;
import java.util.List;

public class DummyComposition {

    public static Composition mockComposition(String id) {
        return Composition.builder()
                .id(id)
                .build();
    }

    public static CompositionDto mockCompositionDto(String id) {
        return CompositionDto.builder()
                .id(id)
                .build();
    }

    public static List<Composition> mockCompositions(int number) {
        List<Composition> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockComposition("id" + i));
        }
        return ret;
    }

    public static List<CompositionDto> mockCompositionDtos(int number) {
        List<CompositionDto> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockCompositionDto("id" + i));
        }
        return ret;
    }
}
