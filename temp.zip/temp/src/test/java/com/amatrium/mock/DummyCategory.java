package com.amatrium.mock;

import com.amatrium.dto.CategoryDto;
import com.amatrium.entity.Category;

import java.util.ArrayList;
import java.util.List;

public class DummyCategory {

    public DummyCategory() {
    }

    public static Category mockCategory(String id) {
        return Category.builder()
                .id(id)
                .name("SDI Butler")
                .organization(DummyOrganization.ORGZ_ID)
                .build();
    }

    public static CategoryDto mockCategoryDto(String id) {
        return CategoryDto.builder()
                .id(id)
                .name("SDI Butler")
                .build();
    }

    public static List<Category> mockCategories(int number) {
        List<Category> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockCategory("id" + i));
        }

        return ret;
    }

    public static List<CategoryDto> mockCategoriesDtos(int number) {
        List<CategoryDto> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockCategoryDto("id" + i));
        }
        return ret;
    }
}
