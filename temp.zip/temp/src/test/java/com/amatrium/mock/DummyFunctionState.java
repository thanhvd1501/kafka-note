package com.amatrium.mock;

import com.amatrium.entity.FunctionState;

import java.util.ArrayList;
import java.util.List;

public class DummyFunctionState {

    public static FunctionState mockFunctionState(String id) {
        return FunctionState.builder()
                .id(id)
                .build();
    }

    public static List<FunctionState> mockFunctionStates(int number) {
        List<FunctionState> ret = new ArrayList<>();
        for (int i = 0; i < number; i++) {
            ret.add(mockFunctionState("id" + i));
        }
        return ret;
    }
}
