package com.amatrium.mock;

import com.amatrium.domaintype.UserRole;
import com.amatrium.dto.UserDto;
import com.amatrium.entity.User;

import java.util.ArrayList;
import java.util.List;

public class DummyUserManagement {
    public DummyUserManagement() {
    }

    public static User mockUser(String id, String name) {
        return User.builder()
                .id(id)
                .email(name + "@amatrium.com")
                .name(name)
                .organization("640d6d1b4a937db07f76dc53")
                .role(UserRole.ADMIN.name())
                .password("123456")
                .build();
    }

    public static UserDto mockUserDto(String id, String name, String role) {
        return UserDto.builder()
                .id(id)
                .email(name + "@amatrium.com")
                .name(name)
                .organization("640d6d1b4a937db07f76dc53")
                .role(role)
                .build();
    }

    public static List<User> mockUsers(int number, String name) {
        List<User> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockUser("id" + i, name + i));
        }
        return ret;
    }

    public static List<UserDto> mockUserDtos(int number, String name) {
        List<UserDto> ret = new ArrayList<>();

        for (int i = 0; i < number; i++) {
            ret.add(mockUserDto("id" + i, name + i, UserRole.ADMIN.name()));
        }
        return ret;
    }
}
