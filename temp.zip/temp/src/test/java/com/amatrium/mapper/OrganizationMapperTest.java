package com.amatrium.mapper;

import com.amatrium.dto.OrganizationDto;
import com.amatrium.entity.Organization;
import com.amatrium.mock.DummyOrganization;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class OrganizationMapperTest {

    @InjectMocks
    private OrganizationMapper organizationMapper;

    @Mock
    private ModelMapper modelMapper;

    @Test
    void test_convert() {
        List<Organization> dummyData = DummyOrganization.mockOrganizations(2, "id", "Orgz");
        Mockito.when(modelMapper.map(dummyData.get(0), OrganizationDto.class)).thenReturn(Mockito.mock(OrganizationDto.class));
        Mockito.when(modelMapper.map(dummyData.get(1), OrganizationDto.class)).thenReturn(Mockito.mock(OrganizationDto.class));

        List<OrganizationDto> ret = organizationMapper.toDtoList(dummyData);
        Assertions.assertEquals(dummyData.size(), ret.size());
    }
}
