package com.amatrium.mapper;

import com.amatrium.dto.CompositionDto;
import com.amatrium.entity.Composition;
import com.amatrium.mock.DummyComposition;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class CompositionMapperTest {

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CompositionMapper compositionMapper;

    @Test
    void test_convert() {
        List<Composition> dummyData = DummyComposition.mockCompositions(2);
        Mockito.when(modelMapper.map(dummyData.get(0), CompositionDto.class)).thenReturn(Mockito.mock(CompositionDto.class));
        Mockito.when(modelMapper.map(dummyData.get(1), CompositionDto.class)).thenReturn(Mockito.mock(CompositionDto.class));

        List<CompositionDto> ret = compositionMapper.toDtoList(dummyData);
        Assertions.assertEquals(ret.size(), dummyData.size());
    }
}
