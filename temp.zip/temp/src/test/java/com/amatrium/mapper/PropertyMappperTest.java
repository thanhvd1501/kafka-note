package com.amatrium.mapper;

import com.amatrium.dto.PropertyDto;
import com.amatrium.entity.Property;
import com.amatrium.mock.DummyProperty;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class PropertyMappperTest {

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private PropertyMappper propertyMappper;

    @Test
    void test_convert() {
        List<Property> dummyData = DummyProperty.mockProperties(2);
        Mockito.when(modelMapper.map(dummyData.get(0), PropertyDto.class)).thenReturn(Mockito.mock(PropertyDto.class));
        Mockito.when(modelMapper.map(dummyData.get(1), PropertyDto.class)).thenReturn(Mockito.mock(PropertyDto.class));

        List<PropertyDto> ret = propertyMappper.toDtoList(dummyData);
        Assertions.assertEquals(ret.size(), dummyData.size());
    }
}
