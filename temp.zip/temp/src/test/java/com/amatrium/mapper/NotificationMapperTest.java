package com.amatrium.mapper;

import com.amatrium.dto.NotificationDto;
import com.amatrium.entity.Notification;
import com.amatrium.mock.DummyNotification;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class NotificationMapperTest {

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private NotificationMapper notificationMapper;

    @Test
    void test_convert() {
        List<Notification> dummyData = DummyNotification.mockNotifications(2, "user");
        Mockito.when(modelMapper.map(dummyData.get(0), NotificationDto.class)).thenReturn(Mockito.mock(NotificationDto.class));
        Mockito.when(modelMapper.map(dummyData.get(1), NotificationDto.class)).thenReturn(Mockito.mock(NotificationDto.class));

        List<NotificationDto> ret = notificationMapper.toDtoList(dummyData);
        Assertions.assertEquals(ret.size(), dummyData.size());
    }
}
