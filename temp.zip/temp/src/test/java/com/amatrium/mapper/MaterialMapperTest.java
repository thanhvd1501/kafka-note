package com.amatrium.mapper;

import com.amatrium.dto.MaterialDto;
import com.amatrium.entity.Material;
import com.amatrium.mock.DummyMaterial;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class MaterialMapperTest {

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private MaterialMapper materialMapper;

    @Test
    void test_convert() {
        List<Material> dummyData = DummyMaterial.mockMaterials(2);
        Mockito.when(modelMapper.map(dummyData.get(0), MaterialDto.class)).thenReturn(Mockito.mock(MaterialDto.class));
        Mockito.when(modelMapper.map(dummyData.get(1), MaterialDto.class)).thenReturn(Mockito.mock(MaterialDto.class));

        List<MaterialDto> ret = materialMapper.toDtoList(dummyData);
        Assertions.assertEquals(ret.size(), dummyData.size());
    }
}
