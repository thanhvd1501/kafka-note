package com.amatrium.mapper;

import com.amatrium.dto.ManufacturingRecordDto;
import com.amatrium.entity.ManufacturingRecord;
import com.amatrium.mock.DummyManufacturingRecord;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class ManufacturingRecordMapperTest {

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private ManufacturingRecordMapper manufacturingRecordMapper;

    @Test
    void test_convert() {
        List<ManufacturingRecord> dummyData = DummyManufacturingRecord.mockManufacturingRecords(2);
        Mockito.when(modelMapper.map(dummyData.get(0), ManufacturingRecordDto.class)).thenReturn(Mockito.mock(ManufacturingRecordDto.class));
        Mockito.when(modelMapper.map(dummyData.get(1), ManufacturingRecordDto.class)).thenReturn(Mockito.mock(ManufacturingRecordDto.class));

        List<ManufacturingRecordDto> ret = manufacturingRecordMapper.toDtoList(dummyData);
        Assertions.assertEquals(ret.size(), dummyData.size());

    }
}
