package com.amatrium.mapper;

import com.amatrium.dto.CategoryDto;
import com.amatrium.entity.Category;
import com.amatrium.mock.DummyCategory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class CategoryMapperTest {

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CategoryMapper categoryMapper;

    @Test
    void test_convert() {
        List<Category> dummyData = DummyCategory.mockCategories(2);
        Mockito.when(modelMapper.map(dummyData.get(0), CategoryDto.class)).thenReturn(Mockito.mock(CategoryDto.class));
        Mockito.when(modelMapper.map(dummyData.get(1), CategoryDto.class)).thenReturn(Mockito.mock(CategoryDto.class));

        List<CategoryDto> ret = categoryMapper.toDtoList(dummyData);
        Assertions.assertEquals(ret.size(), dummyData.size());
    }
}
