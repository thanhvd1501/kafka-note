package com.amatrium.mapper;

import com.amatrium.dto.UserDto;
import com.amatrium.entity.User;
import com.amatrium.mock.DummyUserManagement;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class UserMapperTest {

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private UserMapper userMapper;

    @Test
    void test_convert() {
        List<User> dummyData = DummyUserManagement.mockUsers(2, "Admin");
        Mockito.when(modelMapper.map(dummyData.get(0), UserDto.class)).thenReturn(Mockito.mock(UserDto.class));
        Mockito.when(modelMapper.map(dummyData.get(1), UserDto.class)).thenReturn(Mockito.mock(UserDto.class));

        List<UserDto> ret = userMapper.toDtoList(dummyData);
        Assertions.assertEquals(ret.size(), dummyData.size());
    }
}
