package com.amatrium.service;

import com.amatrium.cache.UserDataManager;
import com.amatrium.config.ApplicationConfig;
import com.amatrium.domaintype.UserRole;
import com.amatrium.dto.UserDto;
import com.amatrium.entity.User;
import com.amatrium.exception.InternalException;
import com.amatrium.mapper.UserMapper;
import com.amatrium.mock.DummyAuthentication;
import com.amatrium.mock.DummyOrganization;
import com.amatrium.mock.DummyUserManagement;
import com.amatrium.notification.MessengerService;
import com.amatrium.repository.NotificationRepository;
import com.amatrium.repository.OrganizationRepository;
import com.amatrium.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@ExtendWith({
        MockitoExtension.class
})
class UsersManagementServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private OrganizationRepository organizationRepository;

    @Mock
    private UserMapper userMapper;

    @Mock
    private MessengerService emailService;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private I18nMessageService i18nMessageService;

    @Mock
    private UserDataManager dataManager;

    @InjectMocks
    private UsersManagementServiceImpl usersManagementService;

    @Test
    void test_getUserRole() {
        List<String> ret = usersManagementService.getAllUserRole();

        Assertions.assertEquals(3, ret.size());
    }

    @Test
    void test_getUserDetail() throws InternalException {
        int number = 5;
        String id = "640d6d1b4a937db07f76dc53";
        String name = "amatrium";
        Mockito.when(userRepository.find(Mockito.any()))
                .thenReturn(DummyUserManagement.mockUsers(number, name));

        Mockito.when(userMapper.toDto(Mockito.any()))
                .thenReturn(DummyUserManagement.mockUserDto(id, name, UserRole.ADMIN.name()));

        UserDto ret = usersManagementService.getUserDetails(id);

        Assertions.assertNotNull(ret);
    }

    @Test
    void test_createNewUser() throws InternalException {
        String orgzId = DummyOrganization.ORGZ_ID;
        String name = "amatrium";

        SecurityContextHolder.getContext()
                .setAuthentication(DummyAuthentication.mockAuthentication(orgzId, UserRole.USER.name()));
        Mockito.when(userRepository.find(Mockito.any()))
                .thenReturn(null);
        Mockito.when(userRepository.save(Mockito.any()))
                .thenReturn(DummyUserManagement.mockUser(orgzId, name));
        Mockito.when(organizationRepository.findById(Mockito.any()))
                .thenReturn(Optional.ofNullable(DummyOrganization.mockOrganization(orgzId, name)));
        Mockito.when(userMapper.toDto(Mockito.any()))
                .thenReturn(DummyUserManagement.mockUserDto(orgzId, name, UserRole.ADMIN.name()));
        Mockito.doNothing().when(emailService).sendMessageInAsync(Mockito.any());

        UserDto ret = usersManagementService.createNewUser(
                DummyUserManagement.mockUserDto(orgzId, name, UserRole.ADMIN.name()));

        Assertions.assertNotNull(ret);
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Test
    void test_createNewUser_withInvalidInput() {
        String orgzId = DummyOrganization.ORGZ_ID;

        SecurityContextHolder.getContext()
                .setAuthentication(DummyAuthentication.mockAuthentication(orgzId, UserRole.USER.name()));

        Exception exception = Assertions.assertThrows(
                InternalException.class, () -> usersManagementService.createNewUser(null)
        );
        Assertions.assertNotNull(exception);
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Test
    void test_createNewUser_withInvalidRole() {
        String orgzId = DummyOrganization.ORGZ_ID;
        String name = "amatrium";

        SecurityContextHolder.getContext()
                .setAuthentication(DummyAuthentication.mockAuthentication(orgzId, UserRole.SUPER_ADMIN.name()));

        Exception exception = Assertions.assertThrows(InternalException.class, () -> usersManagementService.createNewUser(DummyUserManagement.mockUserDto(orgzId, name, UserRole.SUPER_ADMIN.name())));
        Assertions.assertNotNull(exception);
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Test
    void test_createNewUser_withInvalidEmail() {
        String orgzId = DummyOrganization.ORGZ_ID;
        String name = "";

        SecurityContextHolder.getContext()
                .setAuthentication(DummyAuthentication.mockAuthentication(orgzId, UserRole.USER.name()));

        Exception exception = Assertions.assertThrows(InternalException.class, () -> usersManagementService.createNewUser(DummyUserManagement.mockUserDto(orgzId, name, UserRole.ADMIN.name())));
        Assertions.assertNotNull(exception);
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Test
    void test_createNewUser_withInvalidOrganization() {
        String orgzId = "";
        String name = "amatrium";

        SecurityContextHolder.getContext()
                .setAuthentication(DummyAuthentication.mockAuthentication(orgzId, UserRole.USER.name()));

        Exception exception = Assertions.assertThrows(InternalException.class, () -> usersManagementService.createNewUser(DummyUserManagement.mockUserDto(orgzId, name, UserRole.ADMIN.name())));
        Assertions.assertNotNull(exception);
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Test
    void test_deleteUser() throws InternalException {
        int number = 5;
        String orgzId = DummyOrganization.ORGZ_ID;
        String name = "amatrium";

        Mockito.when(userRepository.find(Mockito.any()))
                .thenReturn(DummyUserManagement.mockUsers(number, name));
        Mockito.doNothing().when(userRepository).delete(Mockito.any());

        boolean ret = usersManagementService.deleteUser(orgzId);

        Assertions.assertEquals(true, ret);
    }

    @Test
    void test_deleteUser_withWrongUserID() {
        String orgzId = "";

        Mockito.when(userRepository.find(Mockito.any()))
                .thenReturn(null);

        Exception exception = Assertions.assertThrows(NullPointerException.class, () -> usersManagementService.deleteUser(orgzId));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_getAllUsers() {
        int number = 5;
        String name = "amatrium";

        Mockito.when(userRepository.find(Mockito.any()))
                .thenReturn(DummyUserManagement.mockUsers(number, name));
        Mockito.when(userMapper.toDto(Mockito.any()))
                .thenReturn(DummyUserManagement.mockUserDto("id", name, "ADMIN"));

        List<UserDto> ret = usersManagementService.getAllUsers();

        Assertions.assertEquals(5, ret.size());
    }

    @Test
    void test_changePassword() throws InternalException {
        String id = "640d6d1b4a937db07f76dc53";
        String name = "amatrium";
        String oldPassword = "123456";
        String newPassword = "123456789H@i";
        String orgzId = DummyOrganization.ORGZ_ID;

        User user = DummyUserManagement.mockUser(id, name);
        Mockito.when(userRepository.find(Mockito.any()))
                .thenReturn(List.of(user));

        Mockito.when(passwordEncoder.matches(Mockito.any(), Mockito.any()))
                .thenReturn(true);

        Mockito.when(passwordEncoder.encode(Mockito.any()))
                .thenReturn(newPassword);

        Mockito.doNothing().when(emailService).sendMessageInAsync(Mockito.any());

        Mockito.when(userRepository.save(Mockito.any()))
                .thenReturn(user);

        SecurityContextHolder.getContext()
                .setAuthentication(DummyAuthentication.mockAuthentication(orgzId, user.getEmail(), UserRole.USER.name()));

        boolean ret = usersManagementService.changePassword(id, oldPassword, newPassword);

        Assertions.assertTrue(ret);
    }

    @Test
    void test_changePassword_withEmptyPassword() throws InternalException {
        String id = "640d6d1b4a937db07f76dc53";
        String oldPassword = "123456";
        String newPassword = "";

        Exception exception = Assertions.assertThrows(
                InternalException.class, () -> usersManagementService.changePassword(id, oldPassword, newPassword)
        );
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_changeUserRole() throws InternalException {
        String id = "640d6d1b4a937db07f76dc53";
        String name = "amatrium";
        String orgzId = DummyOrganization.ORGZ_ID;

        User user = DummyUserManagement.mockUser(id, name);
        Mockito.when(userRepository.find(Mockito.any()))
                .thenReturn(List.of(user));

        Mockito.when(userRepository.save(Mockito.any()))
                .thenReturn(user);

        SecurityContextHolder.getContext()
                .setAuthentication(DummyAuthentication.mockAuthentication(orgzId, UserRole.ADMIN.name()));

        boolean ret = usersManagementService.updateUserRole(id, UserRole.USER.name());

        Assertions.assertTrue(ret);
    }
}
