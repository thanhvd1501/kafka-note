package com.amatrium.service;

import com.amatrium.cache.ProcessingTaskManagerImpl;
import com.amatrium.entity.Category;
import com.amatrium.exception.InternalException;
import com.amatrium.mock.DummyFile;
import com.amatrium.repository.CategoryRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

@ExtendWith({
        MockitoExtension.class
})
class ImportServiceTest {

    @Mock
    private CategoryRepository categoryRepo;

    @Mock
    private ProcessingTaskManagerImpl processingTaskManager;

    @InjectMocks
    private ImportServiceImpl service;

    @Test
    void test_importManufacturingRecord_whenInvalidIdCategory() {
        Mockito.when(categoryRepo.findById(Mockito.anyString())).thenReturn(Optional.empty());

        Exception exception = Assertions.assertThrows(InternalException.class, () -> service.importManufacturingRecord("123", true, DummyFile.mockCompositionsCsv(true, 0)));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_importManufacturingRecord_whenLockedCategory() throws InternalException {
        Mockito.when(categoryRepo.findById(Mockito.anyString())).thenReturn(Optional.of(Mockito.mock(Category.class)));
        Mockito.when(processingTaskManager.isCategoryLocked(Mockito.anyString())).thenReturn(true);

        Exception exception = Assertions.assertThrows(InternalException.class, () -> service.importManufacturingRecord("123", true, DummyFile.mockCompositionsCsv(true, 0)));
        Assertions.assertNotNull(exception);
    }
}
