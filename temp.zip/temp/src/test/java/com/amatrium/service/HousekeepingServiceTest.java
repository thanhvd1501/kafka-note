package com.amatrium.service;

import com.amatrium.cache.UserDataManagerImpl;
import com.amatrium.config.ApplicationConfig;
import com.amatrium.constant.I18nConstant;
import com.amatrium.domaintype.Severity;
import com.amatrium.entity.Category;
import com.amatrium.entity.FunctionState;
import com.amatrium.exception.InternalException;
import com.amatrium.notification.sse.SseManager;
import com.amatrium.repository.CategoryRepository;
import com.amatrium.repository.FunctionStateRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.times;

@ExtendWith({
        MockitoExtension.class
})
class HousekeepingServiceTest {

    @Mock
    private ApplicationConfig applicationConfig;

    @Mock
    private UserDataManagerImpl userDataManager;

    @InjectMocks
    private HousekeepingServiceImpl service;

    @Mock
    private NotificationService notificationService;

    @Mock
    private FunctionStateRepository functionStateRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private I18nMessageService i18nMessageService;

    @Mock
    private SseManager sseManager;

    @Test
    void test_cleanResetPasswordCode() throws InternalException {
        Mockito.when(applicationConfig.getSecretCodeLifespan()).thenReturn(30);

        userDataManager.generateUserSecret("amatrium@gmail.com");
        service.cleanUserSecretCode();

        Assertions.assertFalse(userDataManager.verifyUserSecret("amatrium@gmail.com", "12345"));
    }

    @Test
    void test_cleanAllNotification() throws InternalException {
        service.cleanNotification(new Date());

        Mockito.verify(notificationService, times(1)).deleteNotification(Mockito.any(), Mockito.any(), Mockito.any());
    }

    @Test
    void test_checkFunctionStateTimeout() {
        FunctionState functionState = new FunctionState();
        functionState.setType(Severity.INFO.name());
        functionState.setCategoryId("12323323");
        Category category = new Category();
        category.setId("12323323");
        category.setName("SDI Builder");
        category.setOrganization("123234343");

        Mockito.when(functionStateRepository.find(Mockito.any())).thenReturn(List.of(functionState));
        Mockito.when(i18nMessageService.translateMessage(I18nConstant.MSG_FUNCTION_STATE_TIME_OUT, List.of(functionState.getType(), category.getName()))).thenReturn(new HashMap<>());
        Mockito.when(categoryRepository.findById(Mockito.any())).thenReturn(Optional.of(category));

        service.markFunctionStateTimeout(new Date());

        Mockito.verify(functionStateRepository, times(1)).saveAll(List.of(functionState));
    }

    @Test
    void test_cleanAllFunctionStateOutDate() {
        FunctionState functionState = new FunctionState();
        Mockito.when(functionStateRepository.find(Mockito.any())).thenReturn(List.of(functionState));

        service.cleanFunctionState(new Date());

        Mockito.verify(functionStateRepository, times(1)).deleteAll(List.of(functionState));
    }
}
