package com.amatrium.service;

import com.amatrium.domaintype.UserRole;
import com.amatrium.dto.CategoryDto;
import com.amatrium.dto.CompositionDto;
import com.amatrium.entity.Composition;
import com.amatrium.exception.InternalException;
import com.amatrium.mapper.CategoryMapper;
import com.amatrium.mapper.CompositionMapper;
import com.amatrium.mock.DummyAuthentication;
import com.amatrium.mock.DummyCategory;
import com.amatrium.mock.DummyFile;
import com.amatrium.mock.DummyMetadata;
import com.amatrium.repository.CategoryRepository;
import com.amatrium.repository.CompositionRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

@ExtendWith({
        MockitoExtension.class
})
class CategoryServiceTest {

    @Mock
    private CategoryRepository repo;

    @Mock
    private CompositionRepository compositionRepo;

    @Mock
    private CategoryMapper mapper;

    @Mock
    private CompositionMapper compositionMapper;

    @InjectMocks
    private CategoryServiceImpl categoryService;

    @BeforeEach
    public void beforeEach() {
        SecurityContextHolder.getContext().setAuthentication(DummyAuthentication.mockAuthentication(UserRole.ADMIN.name()));
    }

    @Test
    void test_getCategories() {
        int number = 5;
        String text = "abc";

        Mockito.when(repo.find(Mockito.any())).thenReturn(DummyCategory.mockCategories(number));
        Mockito.when(mapper.toDtoList(Mockito.anyList())).thenReturn(DummyCategory.mockCategoriesDtos(number));

        List<CategoryDto> ret = categoryService.search(text);

        Assertions.assertNotNull(ret);
    }
}
