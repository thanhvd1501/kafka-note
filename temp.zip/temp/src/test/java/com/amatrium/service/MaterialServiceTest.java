package com.amatrium.service;

import com.amatrium.dto.MaterialDto;
import com.amatrium.entity.Material;
import com.amatrium.exception.InternalException;
import com.amatrium.mapper.MaterialMapper;
import com.amatrium.repository.MaterialRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

@ExtendWith({
        MockitoExtension.class
})
class MaterialServiceTest {

    @Mock
    private MaterialMapper mapper;

    @Mock
    private MaterialRepository repo;

    @InjectMocks
    private MaterialServiceImpl materialService;

    @Test
    void test_getMaterialById_whenIdIsInvalid() throws InternalException {
        Exception exception = Assertions.assertThrows(InternalException.class, () -> materialService.getMaterialById(null));
        Assertions.assertNotNull(exception);

        exception = Assertions.assertThrows(InternalException.class, () -> materialService.getMaterialById(""));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_getMaterialById_whenId_not_exist() {
        String Id = "123456789";

        Mockito.when(repo.findById(Id)).thenReturn(Optional.empty());

        Exception exception = Assertions.assertThrows(InternalException.class, () -> materialService.getMaterialById(Id));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_getMaterialById() throws InternalException {
        String Id = "640b0a92a440ac66a8c9d190";
        Material material = Material.builder()
                .id("640b0a92a440ac66a8c9d190")
                .build();

        Mockito.when(repo.findById(Id)).thenReturn(Optional.ofNullable(material));
        Mockito.when(mapper.toDto(Mockito.any())).thenReturn(MaterialDto.builder().id(Id).build());

        MaterialDto materials = materialService.getMaterialById(Id);
        Assertions.assertEquals(Id, materials.getId());
    }
}
