package com.amatrium.service;

import com.amatrium.dto.OrganizationDto;
import com.amatrium.entity.Organization;
import com.amatrium.mapper.OrganizationMapper;
import com.amatrium.mock.DummyOrganization;
import com.amatrium.repository.OrganizationRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class OrganizationServiceTest {

    @Mock
    private OrganizationRepository repo;

    @Mock
    private OrganizationMapper mapper;

    @InjectMocks
    private OrganizationServiceImpl service;

    @Test
    void test_findAll() {
        List<Organization> dummyData = DummyOrganization.mockOrganizations(2, "id", "Orgz");
        List<OrganizationDto> listDto = DummyOrganization.mockOrganizationDtos(2, "id", "Orgz");

        Mockito.when(repo.findAll()).thenReturn(dummyData);
        Mockito.when(mapper.toDtoList(Mockito.anyList())).thenReturn(listDto);

        Assertions.assertEquals(service.findAll().size(), dummyData.size());
    }

    @Test
    void test_findOrganization() {
        List<Organization> dummyData = DummyOrganization.mockOrganizations(2, "id", "Orgz");
        List<OrganizationDto> listDto = DummyOrganization.mockOrganizationDtos(2, "id", "Orgz");

        Mockito.when(repo.find(Mockito.any())).thenReturn(dummyData);
        Mockito.when(mapper.toDtoList(Mockito.anyList())).thenReturn(listDto);

        Assertions.assertEquals("Orgz0", service.findOrganization("Orgz0").get(0).getName());
    }
}
