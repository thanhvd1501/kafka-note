//package com.amatrium.service;
//
//import com.amatrium.dto.NotificationDto;
//import com.amatrium.exception.InternalException;
//import com.amatrium.mapper.NotificationMapper;
//import com.amatrium.mock.DummyNotification;
//import com.amatrium.mock.DummyUserManagement;
//import com.amatrium.repository.NotificationRepository;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mockito;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.util.Date;
//import java.util.List;
//
//@ExtendWith({
//        MockitoExtension.class
//})
//public class NotificationServiceTest {
//
//    @Mock
//    private NotificationRepository notificationRepository;
//
//    @Mock
//    private NotificationMapper notificationMapper;
//
//    @InjectMocks
//    private  NotificationServiceImpl notificationService;
//
//    @Test
//    void test_getUserNotification() {
//        int number = 5;
//        String id = "642ff1df47397e4b8f79379c";
//        String name = "amatrium";
//
//        Mockito.when(notificationRepository.find(Mockito.any()))
//                .thenReturn(DummyNotification.mockNotifications(number, name));
//        Mockito.when(notificationMapper.toDtoList(Mockito.any()))
//                .thenReturn(DummyNotification.mockNotificationDtos(number, name));
//
//        List<NotificationDto> ret = notificationService.getUserNotification(id);
//
//        Assertions.assertEquals(5, ret.size());
//    }
//
//    @Test
//    void test_deleteNotification() throws InternalException {
//        int number = 5;
//        String id = "642ff1df47397e4b8f79379c";
//        String owner = "amatrium";
//        Date date = new Date(2023,04,07);
//
//        Mockito.when(notificationRepository.find(Mockito.any()))
//                .thenReturn(DummyNotification.mockNotifications(number, owner));
//
//        Mockito.doNothing().when(notificationRepository).delete(Mockito.any());
//
//        boolean ret = notificationService.deleteNotification(id, true, date);
//
//        Assertions.assertTrue(ret);
//    }
//
//    @Test
//    void test_deleteNotification_withWrongUserID() {
//        String userId = "";
//        Date date = new Date(2023,04,07);
//
//        Mockito.when(notificationRepository.find(Mockito.any()))
//                .thenReturn(null);
//
//        Exception exception = Assertions.assertThrows(
//                InternalException.class, () -> notificationService.deleteNotification(userId, false, date)
//        );
//        Assertions.assertNotNull(exception);
//    }
//}