package com.amatrium.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@ExtendWith({
        MockitoExtension.class
})
class I18nMessageServiceTest {

    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private I18nMessageServiceImpl i18nMessageService;

    @Test
    void test_translateWithValidKey() {
        String key = "test.key";
        String expectedMessage = "This is a test message";
        // Mock the MessageSource object
        Mockito.when(messageSource.getMessage(key, null, key, Locale.getDefault())).thenReturn(expectedMessage);

        // Call the translate() method with the valid key
        String translatedMessage = i18nMessageService.translate(key);

        // Verify that the MessageSource object's getMessage() method was called with the correct parameters
        Mockito.verify(messageSource).getMessage(key, null, key, Locale.getDefault());
        // Assert that the translated message is the expected message
        Assertions.assertEquals(expectedMessage, translatedMessage);
    }

    @Test
    void test_translateWithValidKeyAndLocale() {
        String key = "test.key";
        String expectedMessage = "This is a test message in French";
        Locale locale = Locale.FRENCH;

        // Mock the MessageSource object
        Mockito.when(messageSource.getMessage(key, null, key, locale)).thenReturn(expectedMessage);

        // Call the translate() method with the valid key and locale
        String translatedMessage = i18nMessageService.translate(key, locale);

        // Verify that the MessageSource object's getMessage() method was called with the correct parameters
        Mockito.verify(messageSource).getMessage(key, null, key, locale);

        // Assert that the translated message is the expected message
        Assertions.assertEquals(expectedMessage, translatedMessage);
    }

    @Test
    void test_translateWithValidKeyLocaleAndArgs() {
        String key = "test.key";
        String expectedMessage = "Hello John, your balance is $100.00";
        Locale locale = Locale.US;
        List<String> args = Arrays.asList("John", "$100.00");

        // Mock the MessageSource object
        Mockito.when(messageSource.getMessage(key, args.toArray(), key, locale)).thenReturn(expectedMessage);

        // Call the translate() method with the valid key, locale, and arguments
        String translatedMessage = i18nMessageService.translate(key, locale, args);

        // Verify that the MessageSource object's getMessage() method was called with the correct parameters
        Mockito.verify(messageSource).getMessage(key, args.toArray(), key, locale);

        // Assert that the translated message is the expected message
        Assertions.assertEquals(expectedMessage, translatedMessage);
    }

    @Test
    void testTranslateWithInvalidKey() {
        String key = "invalid.key";
        String expectedTranslation = key;

        Mockito.when(messageSource.getMessage(key, null, key, Locale.getDefault())).thenThrow(new NoSuchMessageException("Could not find message"));
        String actualTranslation = i18nMessageService.translate(key);

        Assertions.assertEquals(expectedTranslation, actualTranslation);
        // Assert that an error was logged
    }
}
