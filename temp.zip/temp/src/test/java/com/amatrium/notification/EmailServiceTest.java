package com.amatrium.notification;

import com.amatrium.config.ApplicationConfig;
import com.amatrium.notification.message.BaseMessage;
import com.amatrium.notification.message.EmailMessage;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.test.util.ReflectionTestUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.util.HashMap;
import java.util.Map;

@ExtendWith({
        MockitoExtension.class
})
class EmailServiceTest {

    @Mock
    private JavaMailSender javaMailSender;

    @Mock
    private SpringTemplateEngine templateEngine;

    @Mock
    private ApplicationConfig applicationConfig;

    @InjectMocks
    private EmailServiceImpl emailService;

    @Test
    void testSendMessageInAsync_withValidEmail() throws MessagingException {
        // Given
        EmailMessage email = new EmailMessage();
        email.setReceiver("test@example.com");
        email.setSubject("Test email");
        email.setTemplate("email_template.html");
        Map<String, String> args = new HashMap<>();
        args.put("name", "John Doe");
        args.put("message", "This is a test email");
        email.setArguments(args);

        MimeMessage mockMimeMessage = Mockito.mock(MimeMessage.class);
        Mockito.when(applicationConfig.getWebEndpoint()).thenReturn("web-ui.com");
        Mockito.when(javaMailSender.createMimeMessage()).thenReturn(mockMimeMessage);
        ReflectionTestUtils.setField(emailService, "fromAddress", "noreply@amatrium.com");

        MimeMessageHelper mockMimeMessageHelper = Mockito.mock(MimeMessageHelper.class);

        String mockHtml = "<html><body><p>Hello, John Doe!</p><p>This is a test email</p></body></html>";
        Mockito.when(templateEngine.process(Mockito.any(String.class), Mockito.any(Context.class))).thenReturn(mockHtml);

        // When
        emailService.sendMessageInAsync(email);

        // Then
        Mockito.verify(javaMailSender, Mockito.times(1)).send(mockMimeMessage);
    }

    @Test
    void testSendMessageInAsync_withNotEmailMessage() {
        // Given
        BaseMessage baseMessage = Mockito.mock(BaseMessage.class);

        // When
        emailService.sendMessageInAsync(baseMessage);

        // Then
        Mockito.verifyNoInteractions(javaMailSender);
    }

}
