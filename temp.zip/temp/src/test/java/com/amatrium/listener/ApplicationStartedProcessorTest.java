package com.amatrium.listener;

import com.amatrium.config.ApplicationConfig;
import com.amatrium.service.HousekeepingService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.context.event.ApplicationReadyEvent;

import java.util.concurrent.Executor;

@ExtendWith({
        MockitoExtension.class
})
public class ApplicationStartedProcessorTest {

    @InjectMocks
    private ApplicationStartedProcessor applicationStartedProcessor;

    @Mock
    private Executor executor;

    @Mock
    private HousekeepingService housekeepingService;

    @Mock
    private ApplicationConfig applicationConfig;

    @Test
    void test_appStartUp() {
        applicationStartedProcessor.onApplicationEvent(Mockito.mock(ApplicationReadyEvent.class));
        Mockito.verify(housekeepingService, Mockito.times(1)).markFunctionStateTimeout(Mockito.any());
    }

    @Test
    void test_initCleanOldDataScheduler() {
        applicationStartedProcessor.initCleanOldDataScheduler();
        Mockito.verify(executor, Mockito.times(2)).execute(Mockito.any());
    }

    @Test
    void test_initCleanSecretCodeScheduler() {
        applicationStartedProcessor.initCleanSecretCodeScheduler();
        Mockito.verify(housekeepingService, Mockito.times(1)).cleanUserSecretCode();
    }

    @Test
    void test_initCheckFunctionStateTimeoutScheduler() {
        applicationStartedProcessor.initCheckFunctionStateTimeoutScheduler();
        Mockito.verify(housekeepingService, Mockito.times(1)).markFunctionStateTimeout(Mockito.any());
    }
}
