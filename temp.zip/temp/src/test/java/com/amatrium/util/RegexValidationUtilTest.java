package com.amatrium.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith({
        MockitoExtension.class
})
class RegexValidationUtilTest {

    @Test
    void test_verifyEmail_whenEmailWasNotValid() {
        // null
        boolean result = RegexValidationUtil.verifyEmail(null);
        Assertions.assertFalse(result);

        // empty
        result = RegexValidationUtil.verifyEmail("   ");
        Assertions.assertFalse(result);

        // invalid format
        result = RegexValidationUtil.verifyEmail("email");
        Assertions.assertFalse(result);
    }

    @Test
    void test_verifyEmail() {
        boolean result = RegexValidationUtil.verifyEmail("email@oganization.com");
        Assertions.assertTrue(result);
    }

    @Test
    void test_isValidPassword() {
        Assertions.assertTrue(RegexValidationUtil.isValidPassword("123456789H@i"));
        Assertions.assertFalse(RegexValidationUtil.isValidPassword("12345678910"));
        Assertions.assertFalse(RegexValidationUtil.isValidPassword("1234567"));
        Assertions.assertFalse(RegexValidationUtil.isValidPassword("123456789Hai"));
        Assertions.assertFalse(RegexValidationUtil.isValidPassword("123456789HAI"));
        Assertions.assertFalse(RegexValidationUtil.isValidPassword("123456789hai"));
    }
}
