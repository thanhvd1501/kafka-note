package com.amatrium.util;

import com.amatrium.entity.Composition;
import com.amatrium.exception.InternalException;
import com.amatrium.mock.DummyFile;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class CsvUtilTest {

    @Test
    void test_importCsvFile_whenFileIsInvalid() {
        MultipartFile input = null;
        Exception exception = Assertions.assertThrows(InternalException.class, () -> CsvReader.readCsvData(input, true, null, null));
        Assertions.assertNotNull(exception);

        MultipartFile invalidFileType = Mockito.mock(MultipartFile.class);
        Mockito.when(invalidFileType.getContentType()).thenReturn("text");
        exception = Assertions.assertThrows(InternalException.class, () -> CsvReader.readCsvData(invalidFileType, true, null, null));
        Assertions.assertNotNull(exception);
    }

    @Test
    void test_importCsvFile() throws InternalException {
        int numOfRow = 3;
        MultipartFile input = DummyFile.mockCompositionsCsv(true, numOfRow);

        List<Composition> compositions = CsvReader.readCsvData(input, true, null, this::createComposition);
        Assertions.assertEquals(numOfRow, compositions.size());
    }

    private Composition createComposition(String[] values) {
        return Composition.builder()
                .symbol(values[0].trim())
                .name(values[1].trim())
                .unit(values[2].trim())
                .build();
    }

}
