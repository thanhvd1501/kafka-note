package com.amatrium.util;

import com.amatrium.domaintype.UserRole;
import com.amatrium.security.Principal;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class SecurityUtilTest {

    @BeforeEach
    public void beforeEach() {
        Principal principal = new Principal("user", "organization");
        List<GrantedAuthority> authorities = List.of(new GrantedAuthority() {
            @Override
            public String getAuthority() {
                return UserRole.ADMIN.name();
            }
        });
        Authentication authentication = new UsernamePasswordAuthenticationToken(principal, null, authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @Test
    void test_resolveToken() {
        String token = "Bearer 123456789";
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        Mockito.when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(token);
        String ret = SecurityUtil.resolveToken(request);
        Assertions.assertEquals(token.length() - 7, ret.length());
        Assertions.assertTrue(ret.startsWith(String.valueOf(token.charAt(7))));
    }

    @Test
    void test_getCurrentUsername() {
        Assertions.assertEquals("user", SecurityUtil.getCurrentUsername().get());
    }

    @Test
    void test_getUserOrganization() {
        Assertions.assertEquals("organization", SecurityUtil.getUserOrganization());
    }

    @Test
    void test_getAuthorities() {
        Assertions.assertEquals(1, SecurityUtil.getAuthorities().size());
        Assertions.assertEquals(UserRole.ADMIN, SecurityUtil.getAuthorities().get(0));
    }
}
