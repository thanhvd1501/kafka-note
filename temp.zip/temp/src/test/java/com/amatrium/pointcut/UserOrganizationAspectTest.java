package com.amatrium.pointcut;

import com.amatrium.domaintype.UserRole;
import com.amatrium.exception.AspectException;
import com.amatrium.security.Principal;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;

@ExtendWith({
        MockitoExtension.class
})
class UserOrganizationAspectTest {

    @InjectMocks
    private UserOrganizationAspect userOrganizationAspect;

    @Test
    void test_verifyUserOrganization_whenOrganizationIsMissingAndNotSuperAdmin() {
        Principal principal = new Principal("abc", null);
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(UserRole.ADMIN.name()));
        Authentication authentication = new UsernamePasswordAuthenticationToken(principal, null, authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        Exception exception = Assertions.assertThrows(AspectException.class, () -> userOrganizationAspect.verifyUserOrganization());
        Assertions.assertNotNull(exception);
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Test
    void test_verifyUserOrganization_whenUserIsSuperAdmin() {
        Principal principal = new Principal("abc", null);
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(UserRole.SUPER_ADMIN.name()));
        Authentication authentication = new UsernamePasswordAuthenticationToken(principal, null, authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        Assertions.assertDoesNotThrow(() -> userOrganizationAspect.verifyUserOrganization());
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Test
    void test_verifyUserOrganization_whenOrganizationIsExist() {
        Principal principal = new Principal("abc", "organization");
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(UserRole.USER.name()));
        Authentication authentication = new UsernamePasswordAuthenticationToken(principal, null, authorities);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        Assertions.assertDoesNotThrow(() -> userOrganizationAspect.verifyUserOrganization());
        SecurityContextHolder.getContext().setAuthentication(null);
    }
}
